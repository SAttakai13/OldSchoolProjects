# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import random
from influxdb import InfluxDBClient
import time

client = InfluxDBClient(host='localhost', port=8086)
def queryinfluxtest():
    # client.create_database('EnergyCards')
    # results = client.get_list_database()
    # print(results)

    client.switch_database('EnergyCards')

    for i in range(20000):
        r = random.random() * 100
        json_body = [
            {
                "measurement": "cardEvents",
                "tags": {
                    "CardType": "Electric",
                    "cardId": "6c89f539-71c6-490d-a28d-6c5d84c0ee2f"
                },
                "fields": {
                    "duration": int(r)
                }
            },
            {
                "measurement": "cardEvents",
                "tags": {
                    "CardType": "Steel",
                    "cardId": "6c831539-71c6-490d-a28d-6c5d2410ee2f"
                },
                "fields": {
                    "duration": int(r)
                }
            },
            {
                "measurement": "cardEvents",
                "tags": {
                    "CardType": "Poison",
                    "cardId": "6c119539-71c6-430d-a28d-6c5d84c0aa2f"
                },
                "fields": {
                    "duration": int(r)
                }
            },
            {
                "measurement": "cardEvents",
                "tags": {
                    "CardType": "Fire",
                    "cardId": "3c831539-71c6-182d-a28d-612aa7e1198d"
                },
                "fields": {
                    "duration": int(r)
                }
            }
        ]
        client.write_points(json_body)




# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    queryinfluxtest()

