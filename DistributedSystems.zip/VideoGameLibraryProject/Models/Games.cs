﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Text.Json.Serialization;

namespace VideoGameLibraryProject.Models
{
  public class Games
  {
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    [BsonElement("Name")]
    [JsonPropertyName("Name")]
    public string GameName { get; set; } = null!;
    public string Description { get; set; } = null!;
    public string Catagory { get; set; } = null!;
    public string Publisher { get; set; } = null!;
    public string ReleaseDate { get; set; } = null!;
    public string Platform { get; set; } = null!;
    public string Condition { get; set; } = null!;

  }
}
