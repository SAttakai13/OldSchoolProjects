﻿namespace VideoGameLibraryProject.Models
{
  public class GameLibraryDatabaseSettings
  {
    public string ConnectionString { get; set; } = null!;
    public string GameDatabaseName { get; set; } = null!;

    public string GameCollectionName { get; set; } = null!;

    public string UserCollectionName { get; set; } = null!;

  }
}
