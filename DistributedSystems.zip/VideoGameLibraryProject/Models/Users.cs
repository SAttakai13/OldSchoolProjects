﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System.Text.Json.Serialization;

namespace VideoGameLibraryProject.Models
{
  public class Users
  {
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    [BsonElement("Name")]
    [JsonPropertyName("Name")]
    public string? UserName { get; set; }

    public string Email { get; set; }

    public string? StreetAddress { get; set; }
  }
}
