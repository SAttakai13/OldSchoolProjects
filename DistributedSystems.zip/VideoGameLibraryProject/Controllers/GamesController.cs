﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VideoGameLibraryProject.Models;

namespace VideoGameLibraryProject.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class GamesController : ControllerBase
  {
    private readonly GamesService _gamesService;

    public GamesController(GamesService gamesService) =>
      _gamesService = gamesService;

    [HttpGet]
    public async Task<List<Games>> Get() =>
        await _gamesService.GetAsync();

    [HttpGet("{id:length(24)}")]
    public async Task<ActionResult<Games>> Get(string id)
    {
      var Games = await _gamesService.GetAsync(id);

      if (Games is null)
      {
        return NotFound();
      }

      return Games;
    }

    [HttpPost]
    public async Task<IActionResult> Post(Games newGame)
    {
      await _gamesService.CreateAsync(newGame);

      return CreatedAtAction(nameof(Get), new { id = newGame.Id }, newGame);
    }

    [HttpPut("{id:length(24)}")]
    public async Task<IActionResult> Update(string id, Games updatedGame)
    {
      var Games = await _gamesService.GetAsync(id);

      if (Games is null)
      {
        return NotFound();
      }

      updatedGame.Id = Games.Id;

      await _gamesService.UpdateAsync(id, updatedGame);

      return NoContent();
    }

    [HttpDelete("{id:length(24)}")]
    public async Task<IActionResult> Delete(string id)
    {
      var Games = await _gamesService.GetAsync(id);

      if (Games is null)
      {
        return NotFound();
      }

      await _gamesService.RemoveAsync(id);

      return NoContent();
    }
  }
}
