﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VideoGameLibraryProject.Models;

namespace VideoGameLibraryProject.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class UsersController : ControllerBase
  {
    private readonly UsersService _usersService;

    public UsersController(UsersService usersService) =>
      _usersService = usersService;

    [HttpGet]
    public async Task<List<Users>> Get() =>
        await _usersService.GetAsync();

    [HttpGet("{id:length(24)}")]
    public async Task<ActionResult<Users>> Get(string id)
    {
      var Users = await _usersService.GetAsync(id);

      if (Users is null)
      {
        return NotFound();
      }

      return Users;
    }

    [HttpPost]
    public async Task<IActionResult> Post(Users newGame)
    {
      await _usersService.CreateAsync(newGame);

      return CreatedAtAction(nameof(Get), new { id = newGame.Id }, newGame);
    }

    [HttpPut("{id:length(24)}")]
    public async Task<IActionResult> Update(string id, Users updatedGame)
    {
      var Users = await _usersService.GetAsync(id);

      if (Users is null)
      {
        return NotFound();
      }

      updatedGame.Id = Users.Id;

      await _usersService.UpdateAsync(id, updatedGame);

      return NoContent();
    }

    [HttpDelete("{id:length(24)}")]
    public async Task<IActionResult> Delete(string id)
    {
      var Users = await _usersService.GetAsync(id);

      if (Users is null)
      {
        return NotFound();
      }

      await _usersService.RemoveAsync(id);

      return NoContent();
    }

  }
}
