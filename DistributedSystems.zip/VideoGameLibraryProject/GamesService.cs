﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using VideoGameLibraryProject.Models;

namespace VideoGameLibraryProject
{
  public class GamesService
  {
    private readonly IMongoCollection<Games> _gamesCollection;

    public GamesService(IOptions<GameLibraryDatabaseSettings> gameDatabaseSettings)
    {
      var mongoClient = new MongoClient(
        gameDatabaseSettings.Value.ConnectionString);
      var mongoDatabase = mongoClient.GetDatabase(
        gameDatabaseSettings.Value.GameDatabaseName);
      _gamesCollection = mongoDatabase.GetCollection<Games>(
        gameDatabaseSettings.Value.GameCollectionName);
    }

    public async Task<List<Games>> GetAsync() =>
        await _gamesCollection.Find(_ => true).ToListAsync();

    public async Task<Games?> GetAsync(string id) =>
        await _gamesCollection.Find(x => x.Id == id).FirstOrDefaultAsync();

    public async Task CreateAsync(Games newGame) =>
        await _gamesCollection.InsertOneAsync(newGame);

    public async Task UpdateAsync(string id, Games updatedGame) =>
        await _gamesCollection.ReplaceOneAsync(x => x.Id == id, updatedGame);

    public async Task RemoveAsync(string id) =>
        await _gamesCollection.DeleteOneAsync(x => x.Id == id);

  }
}
