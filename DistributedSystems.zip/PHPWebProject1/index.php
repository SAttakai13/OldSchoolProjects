﻿<?php

echo 'Hello World!';
