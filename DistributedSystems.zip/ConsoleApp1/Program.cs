﻿using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp1
{
  internal class Program
  {
    static void Main(string[] args)
    {

      Console.WriteLine(LeapYear(2000));
     }

    //determines if a year is a leap year
    //has to be divisble by 4
    //if it is easily by 100, its not a leap year
    //if a year is divisible by 400 it is a leap year
    static bool LeapYear(int year)
    {
      bool isALeapYear = false;

      if (year % 4 == 0)
      {
        isALeapYear = true;

        if (year % 100 == 0)
        {
          isALeapYear = false;

          if (year % 400 == 0)
          {
            isALeapYear = true;
          }
        }
      }
      return isALeapYear;
    }
  }
}
