 'use strict';

var utils = require('../utils/writer.js');
var Games = require('../service/GamesService');

module.exports.createGames = function createGames (req, res, next, body) {
  Games.createGames(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteGameById = function deleteGameById (req, res, next, gameId) {
  Games.deleteGameById(gameId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listGames = function listGames (req, res, next, limit) {
  Games.listGames(limit)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.showGameById = function showGameById (req, res, next, gameId) {
  Games.showGameById(gameId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateGame = function updateGame (req, res, next, body, gameId) {
  Games.updateGame(body, gameId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateGamePartially = function updateGamePartially (req, res, next, body, gameId) {
  Games.updateGamePartially(body, gameId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
