'use strict';
const con = require("../Config.js")


/**
 * Create a game
 *
 * body Game
 * returns Game
 **/
exports.createGames = function(body) {
  return new Promise(function(resolve, reject) {

    resolve();
  });
}


/**
 * Delete a game by ID
 *
 * gameId String ID of the game to delete
 * no response value expected for this operation
 **/
exports.deleteGameById = function(gameId) {
  return new Promise(function(resolve, reject) {

    resolve();
  });
}


/**
 * List all games
 *
 * limit Integer How many items to return at one time (max 100) (optional)
 * returns Games
 **/
exports.listGames = function(limit) {
  return new Promise(function(resolve, reject) {

    resolve();
  });
}


/**
 * Info for a specific game
 *
 * gameId String The id of the game to retrieve
 * returns Game
 **/
exports.showGameById = function(gameId) {
  return new Promise(function(resolve, reject) {
    //SHOW GAME LOGIC. Connect to DB, execute query,return results into Resolve : resolve(results)

    resolve()
  });
}


/**
 * Update an existing game entirely
 * Update an existing game by Id
 *
 * body Game Updated game data
 * gameId String ID of the game to update
 * returns Game
 **/
exports.updateGame = function(body,gameId) {
  return new Promise(function(resolve, reject) {
		
    resolve()
  });
}


/**
 * Update an existing game partially
 * Update an existing game partially by Id
 *
 * body List JSON patch document
 * gameId String ID of the game to update
 * returns Game
 **/
exports.updateGamePartially = function(body,gameId) {
  return new Promise(function(resolve, reject) {

    resolve()
  });
}

