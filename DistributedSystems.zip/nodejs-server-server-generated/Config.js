var mysql = require('mysql');
var con = mysql.createConnection({
	host: "localhost",
	user: "root"
	password: "",
	database: "csc380"
});

con.connect(() => {
  if(err){
    console.warn("connection error")
  }
});

module.exports = con;