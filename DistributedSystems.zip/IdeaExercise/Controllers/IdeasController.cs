﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using IdeaExercise.Models;
using Microsoft.AspNetCore.JsonPatch;

namespace IdeaExercise.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IdeasController : ControllerBase
    {
        private readonly IdeaContext _context;

        public IdeasController(IdeaContext context)
        {
            _context = context;
        }

        // GET: api/Ideas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Idea>>> GetIdeaItems()
        {
            return await _context.IdeaItems.ToListAsync();
        }

        // GET: api/Ideas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Idea>> GetIdea(long id)
        {
            var idea = await _context.IdeaItems.FindAsync(id);

            if (idea == null)
            {
                return NotFound();
            }

            return idea;
        }

        // PUT: api/Ideas/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIdea(long id, Idea idea)
        {
            if (id != idea.Id)
            {
                return BadRequest();
            }

            _context.Entry(idea).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!IdeaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> PatchIdea(long id, [FromBody] JsonPatchDocument<Idea> patchDoc)
        {
            if (patchDoc != null)
            {
                var customer = await _context.IdeaItems.FindAsync(id);

                patchDoc.ApplyTo(customer, ModelState);

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!IdeaExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return NoContent();
            }
            else
            {
                return BadRequest(ModelState);
            }
        }


        // POST: api/Ideas
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Idea>> PostIdea(Idea getIdea)
        {
            _context.IdeaItems.Add(getIdea);
            await _context.SaveChangesAsync();

            //return CreatedAtAction("GetIdea", new { id = idea.Id }, idea);

            return CreatedAtAction(nameof(getIdea), new { id = getIdea.Id }, getIdea);
        }

        // DELETE: api/Ideas/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteIdea(long id)
        {
            var idea = await _context.IdeaItems.FindAsync(id);
            if (idea == null)
            {
                return NotFound();
            }

            _context.IdeaItems.Remove(idea);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool IdeaExists(long id)
        {
            return _context.IdeaItems.Any(e => e.Id == id);
        }
    }
}
