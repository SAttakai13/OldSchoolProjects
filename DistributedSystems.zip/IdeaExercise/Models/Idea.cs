﻿namespace IdeaExercise.Models
{
    public class Idea
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public string? description { get; set; }
    }
}
