﻿namespace VideoGameLibrary
{
  public class ControllerVideoGame
  {
  }
}
