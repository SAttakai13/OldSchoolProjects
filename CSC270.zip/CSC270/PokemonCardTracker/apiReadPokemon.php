<?php
include_once "Header.php";
?>
<p> 
    Input a Pokemon Card Index: &nbsp;
    <input type="text" id="id" value="1"/>
    <button name="a" onclick="myClickEvent()">Submit</button>
    <p id="A"></p>
<p id="jsonData"></p></p>

<script>
   var request = new XMLHttpRequest();

     window.onload = function () {
       // alert("onload() worked")
        
    }
    // ---------------------------------
    // Click event
    function myClickEvent() {
         // alert("my click"); // Use for debugging
         //alert("data: " + document.getElementById("id").value); // Use for debugging

        loadJson(document.getElementById("id").value);
    }
    // ---------------------------------
            // Call the microservice and get the data
    function loadJson(id) {
        // alert("id: " + id); // Use for debugging
        request.open('GET', 'apiSqlRead.php?id=' + id);
        request.onload=loadComplete;
        request.send();
    }

    // Run when the data has been loaded
    function loadComplete(evt) {
        var myResponse;
        var myData;
        var myReturn = "";

        myResponse = request.responseText;
        //alert("A: " + myResponse); // Use for debugging
        //document.getElementById("A").innerHTML = myResponse; // Display the json for debugging

        myData = JSON.parse(myResponse);

        // alert(myResponse);

        // Loop through each json record and create the HTML
        for (index in myData) {
            myReturn += "<tr><td><hr/><h2>" + myData[index].id + ": <a href='PokemonCard.php?id=" + myData[index].id + "'>" +
                myData[index].name + "</a></h2></td></tr><tr><td>" +
                "<img width='100px' src='" + myData[index].url + "'/></td><td><b>" +
                myData[index].type + "<b></td><td>" +
                "|  HP: " + myData[index].hp + "</td></tr>";

        }
        myReturn += "</table>";
        document.getElementById("jsonData").innerHTML = myReturn; 
    }


</script>

<a href="apiReadAllPokemon.php">Read all</a>

<?php
include_once "Footer.php";
?>