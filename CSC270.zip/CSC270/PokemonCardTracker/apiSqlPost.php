<?php
//include_once "dbConnector.php";

//header('Content-Type:application/json');

//$conn = ConnGet();

////if logged in
//if ($_SESSION["currently_logged_in"] == true) {
//    if ($_SERVER["REQUEST_METHOD"] == "POST") {
//        $name = $_POST['name'];
//        $url = $_POST['url'];
//        $type = $_POST['type'];
//        $hp = $_POST['hp'];

//        $sql = "INSERT INTO pokedex (name, url, type, hp) VALUES ('$name', '$url', '$type', '$hp')";

//        if ($conn->query($sql) === TRUE) {
//            echo "New record created successfully";
//            http_response_code(301); //Created
//        } else {
//            echo "Error: " . $sql . "<br>" . $conn->error;
//        }
//    }
//} else {
//    http_response_code(401);
//}

//header('Location: apiCreatePokemon.php');
//exit();
?>

<?php
include_once "dbConnector.php";

header('Content-Type: application/json');

session_start(); // Ensure session is started

$conn = ConnGet();

// Check if logged in
if (isset($_SESSION["currently_logged_in"]) && $_SESSION["currently_logged_in"] == true) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $url = $_POST['url'];
        $type = $_POST['type'];
        $hp = $_POST['hp'];
        $description = $_POST['description'];

        $sql = "INSERT INTO pokedex (name, url, type, hp, description) VALUES ('$name', '$url', '$type', '$hp', '$description')";

        $cardId = 0;
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            $cardId = $conn->insert_id;
            http_response_code(301); //Created
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        //Save card to user
        $user = GetUserByUsername($conn, $_SESSION["current_user"]);
        $userId = $user["user_id"];
        $card_list = $user["saved_cards"];
        if (!$card_list) {
            $card_list = json_decode("[]");
        }
        
        array_push($card_list, $cardId);
        $card_list = json_encode($card_list);
        $sql = "UPDATE users SET saved_cards='$card_list' WHERE user_id=$userId";
        if ($conn->query($sql) === TRUE) {
            echo "New record added to user list successfully";
            http_response_code(301); //Created
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Insert the new card into the user_cards table
        /*$sql = "INSERT INTO user_cards (user_id, name, url, type, hp, description) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            file_put_contents('error_log.txt', "Prepare failed: " . $conn->error . "\n", FILE_APPEND);
            echo json_encode(["error" => "Database prepare failed."]);
            http_response_code(500);
            exit();
        }

        $stmt->bind_param("isssi", $_SESSION['user_id'], $name, $url, $type, $hp);
        if ($stmt->execute() === false) {
            file_put_contents('error_log.txt', "Execute failed: " . $stmt->error . "\n", FILE_APPEND);
            echo json_encode(["error" => "Database execute failed."]);
            http_response_code(500);
            exit();
        }

        $card_id = $stmt->insert_id;
        $stmt->close();

        $new_card = [
            'id' => $card_id,
            'name' => $name,
            'type' => $type,
            'hp' => $hp,
            'url' => $url,
            'description' => $description
        ];

        echo json_encode(["message" => "New record created successfully", "card" => $new_card]);*/
        http_response_code(301); // Created
    }
} else {
    http_response_code(401); // Unauthorized
}

$conn->close();

// Redirect back to the card creation form
header('Location: apiCreatePokemon.php');
exit();
?>



