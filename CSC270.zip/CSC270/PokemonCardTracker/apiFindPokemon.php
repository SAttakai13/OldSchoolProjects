<?php
include_once "Header.php";
?>
<p> </p>
    Search for Pokemon By Name: &nbsp;
    <input type="text" id="GetPokemonName" value=""/>
    <button name="a" onclick="myClickEvent()">Search</button>
<p id="A"></p>
<p id="jsonData"></p>

<script>
   var request = new XMLHttpRequest();

     window.onload = function () {
       // alert("onload() worked")
       loadJson("");
    }
    // ---------------------------------
    // Click event
    function myClickEvent() {
         // alert("my click"); // Use for debugging
         //alert("data: " + document.getElementById("id").value); // Use for debugging

        loadJson(document.getElementById("GetPokemonName").value);
    }
    // ---------------------------------
            // Call the microservice and get the data
    function loadJson(name) {
        // alert("id: " + id); // Use for debugging
        request.open('GET', 'apiSqlFind.php?GetPokemonName=' + name);
        request.onload=loadComplete;
        request.send();
    }

    // Run when the data has been loaded
    function loadComplete(evt) {
        var myResponse;
        var myData;
        var myReturn = "";

        myResponse = request.responseText;
        //alert("A: " + myResponse); // Use for debugging
        //document.getElementById("A").innerHTML = myResponse; // Display the json for debugging

        myData = JSON.parse(myResponse);

        // alert(myResponse);

        myReturn += "<div class='multi-cards'>";

        // Loop through each json record and create the HTML
        for (index in myData) {
            myReturn += "<div class='search-card-container'> <div class='search-card'>" + "<img class='search-card-img' width='100px' src='" + myData[index].url + "'/>" +
                "<div class='search-card-content'><h2 class='search-card-title'>" + myData[index].id + ": <a href='PokemonCard.php?id=" + myData[index].id + "'>" +
                myData[index].name + "</a></h2><p class='search-card-description'> <b>Type: </b>" +
                
                myData[index].type +
                "</br><b>HP: </b> " + myData[index].hp + "</p></div></div></div>";

        }

        myReturn += "</div>";
        document.getElementById("jsonData").innerHTML = myReturn; 
    }


</script>

<?php
include_once "Footer.php";
?>