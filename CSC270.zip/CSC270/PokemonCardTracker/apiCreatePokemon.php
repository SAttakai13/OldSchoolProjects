<?php
include_once 'Header.php';

if ($_SESSION["currently_logged_in"] == false) {
    header("Location: UserLogin.php");
    exit();
}
?>
<h2>Create Pokemon Card</h2>
<form action="apiSqlPost.php" method="post">
    <label for="name">Name: </label><br>
    <input type="text" id="name" name="name"><br>
    <label for="url">Image URL: </label><br>
    <input type="text" id="url" name="url"><br><br>
        <label for="type">Type: </label><br>
    <input type="text" id="type" name="type"><br>
    <label for="hp">HP: </label><br>
    <input type="number" id="hp" name="hp" value="0"><br><br>
    <label for="description">Description: </label><br>
    <textarea type="text" id="description" name="description"></textarea><br>
    <input type="submit" value="Create Pokemon">
</form>
    

<?php
    
include_once 'Footer.php'
?>