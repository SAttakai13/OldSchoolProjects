<?php
include_once "dbConnector.php";
header('Content-Type:application/json');

$myJSON = "";
$row = null;
$myGet = "";
$myDbConn = ConnGet();
// Process if there is a parameter (GetPokemonName)
if (array_key_exists("userId", $_GET) == TRUE) {
    // Get the db connection
    
    $myGet = $_GET["userId"];
    $myJsonResult = GetUserCards($myDbConn, $myGet);

    $myJSON = null;
    $row = null;

    if ($myJsonResult) {
        while ($row = mysqli_fetch_array($myJsonResult)) {
            $rowArray[] = json_decode($row[0]);
        }
        $myJSON = json_encode($rowArray[0]->cards);
    }
}

$pokemon = [];
foreach (json_decode($myJSON) as $_id) {
    $p = GetPokemonById($myDbConn, $_id);
    if ($p) {
        array_push($pokemon, $p);
    }
}
$myJSON = json_encode($pokemon);
mysqli_close($myDbConn);

echo $myJSON;
