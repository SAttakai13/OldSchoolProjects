<?php
session_start();
?>

<html>
<head>
    <title>Pokemon Card Tracker</title>
    <link rel="stylesheet" type="text/css" href="css.php">
    <table>
        <tr style="justify-content:center;">
            <td><img src="country_detail_pokemon.png" style="height: 75px; width:auto;"/></td>
            <td style="justify-content:center; padding:3px; padding-top:15px;"><h1>Pokemon Card Tracker</h1></td>            
        </tr>
    </table> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <?php include_once "Menu.php"?>
</head>
<body>
    

<?php
    
?>