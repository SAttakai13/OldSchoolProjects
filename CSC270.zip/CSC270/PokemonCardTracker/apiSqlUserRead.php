<?php
include_once "dbConnector.php";

header('Content-Type: application/json');

$myJSON = "";
$row = null;
$userId = "";
$myPost = "";

//if logged in AND admin
if ($_SESSION["currently_logged_in"] == true && $_SESSION["current_user_role"] === "admin") {

    // Process if there is a parameter (user_id)
    if (array_key_exists("user_id", $_GET) == TRUE) {
        // Get the db connection
        // Get the data
        $myDbConn = ConnGet();
        $userId = $_GET["user_id"];
        // Get the records
        $dataSet = @mysqli_query($myDbConn, 
            "select json_object(
                'user_id', u.user_id,
                'username', u.username,
                'email', u.email,
                'encrypted_password', u.encrypted_password,
                'role', u.role) as Users
                from users u where u.user_id = " . $userId);

        // If the data exists, format the values
        if ($dataSet) {
            if ($row = mysqli_fetch_array($dataSet)) {
                $myJSON = $row["Users"];
            }
        }
        mysqli_close($myDbConn);
    }

    echo $myJSON;
} else {
    http_response_code(401);
}

?>