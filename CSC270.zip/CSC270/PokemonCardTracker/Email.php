<?php
include_once "Header.php";
?>

<h1>Email</h1>

<?php
include_once "Footer.php";
?>

