<?php
include_once "dbConnector.php";

header('Content-Type: application/json');

//if logged in AND admin
if ($_SESSION["currently_logged_in"] == true && $_SESSION["current_user_role"] === "admin") {
    if (isset($_GET["user_id"])) {

        $conn = ConnGet();

        $userId = $_GET["user_id"];

        $sql = "DELETE FROM users WHERE user_id = $userId";

        if ($conn->query($sql) === TRUE) {
            echo "Record deleted successfully";
            http_response_code(301); //Deleted
        } else {
            echo "Error deleting record: " . $conn->error;
        }
        mysqli_close($conn);
    } else {
        echo json_encode(["error" => "Missing required parameter 'user_id'"]);
    }

} else {
    http_response_code(401);
}

header('Location: index.php');
exit();

?>
