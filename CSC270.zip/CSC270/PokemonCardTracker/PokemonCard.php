<?php
include_once "Header.php";
include_once "dbConnector.php";
?>

<script>
    function deleteRecord(id) {
        var confirmDelete = confirm("Are you sure you want to delete this record?");
        if (confirmDelete) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "apiSqlDelete.php?id=" + id, true);
            xhr.onload = function () {
                if (xhr.status == 200) {
                    alert("Record deleted successfully");
                    window.location.href = "apiFindPokemon.php";
                } else {
                    alert("Failed to delete record");
                }
            };
            xhr.send();
        }
    }
</script>

<?php
    function getCardColor($type) {
        switch (strtolower($type)) {
            case 'fighting': return '#ce3f6b';
            case 'psychic': return '#f97077';
            case 'poison': return '#ab6ac8';
            case 'dragon': return '#096dc3';
            case 'ghost': return '#5269ad';
            case 'dark': return '#5b5265';
            case 'ground': return '#d97746';
            case 'fire': return '#fe9c55';
            case 'fairy': return '#ec90e7';
            case 'water': return '#4d90d6';
            case 'flying': return '#8fa8de';
            case 'rock': return '#c9b68b';
            case 'electric': return '#f4d23b';
            case 'bug': return '#90c02c';
            case 'grass': return '#65bc5e';
            case 'ice': return '#73cebf';
            case 'steel': return '#5b8ea1';
            default:
            case 'normal': return '#9099a2';
        }
    }
?>


<?php
$conn = ConnGet();

$id = -1;
$pokemon;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $pokemon = GetPokemonById($conn, $id);
    ?>
    
    <?php 
    //If user is logged in and is admin or owns this card
    if ($_SESSION["currently_logged_in"] == true &&
        $_SESSION["current_user_role"] == "admin") { ?>

        <form style="width: fit-content" action="apiSqlUpdate.php" method="post">
            <div class="card_container" style="background-color: <?php echo getCardColor($pokemon["type"]) ?>">
                <input name="id" id="id" type="hidden" value="<?php echo $pokemon["id"] ?>"/>
                <input class="poke_name" name="name" id="name" value="<?php echo $pokemon["name"] ?>"/>
                <input class="poke_type" name="type" id="type" value="<?php echo $pokemon["type"] ?>"/>
                <span style="font-size: 8pt">HP<input class="poke_hp" name="hp" id="hp" value="<?php echo $pokemon["hp"] ?>" type="number"/></span>
                <img src="<?php echo $pokemon["url"] ?>" />
                <input class="poke_url" name="url" id="url" value="<?php echo $pokemon["url"] ?>"/>
                <textarea class="poke_desc" name="desc" id="desc" value="<?php echo $pokemon["desc"] ?>"></textarea>
            </div>
            <button class="card_edit_icon" style="float: right" type="submit">
                <i style="color: white" class="fa fa-upload"></i>
            </button>
        </form>
        
        <button class="card_edit_icon" onclick="deleteRecord(<?php echo $id ?>)">
            <i style="color: red" class="fa fa-trash"></i>
        </button>
    <?php 
    } else { ?>
        
        <div class="card_container" style="background-color: <?php echo getCardColor($pokemon["type"]) ?>">
            <div>
                <h1 class="poke_name"><?php echo $pokemon["name"] ?></h1>
                <h3 class="poke_type"><?php echo $pokemon["type"] ?></h3>
                <p class="poke_hp"><span style="font-size: 8pt">HP</span><?php echo $pokemon["hp"] ?></pclass="poke_hp">
            </div>
            <img src="<?php echo $pokemon["url"] ?>" />
            <h4 class="poke_desc"><?php echo $pokemon["desc"] ?></h4>
        </div>
    <?php
    } ?>
    
<?php
} else {
    ?>

    <p>No Card ID Provided</p>

    <?php
}
?>
<?php
include_once "Footer.php";
?>