<?php
include_once "dbConnector.php";
include_once "passwordEncryptor.php";
//session_start();
$conn = ConnGet();
$username = "";
$password = "";
$userId = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $userId = $_POST["user_id"];

    $user = GetUserByUsername($conn, $username);
    if ($user) {
        if (Verify($password, $user["encrypted_password"])) {
            //Login Success
            $_SESSION["user_id"] = $user["user_id"];
            $_SESSION["current_user"] = $user["username"];
            $_SESSION["current_user_role"] = $user["role"];
            $_SESSION["currently_logged_in"] = true;
            http_response_code(301);
        } else {
            echo "Incorrect username or password";
        }
    } else {
        echo "Incorrect username or password";
    }
}

header('Location: index.php');
exit();