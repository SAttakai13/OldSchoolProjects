<?php
include_once "Header.php";
?>

<h2>Login</h2>
<form action="apiUserLogin.php" method="post">
    <label for="username">Username: </label><br>
    <input type="text" id="username" name="username"><br>
    <label for="password">Password: </label><br>
    <input type="password" id="password" name="password"><br><br>
    <input type="submit" value="Login">
</form>
<p>Don't have an account? <a href="UserRegister.php">Register Here!</a></p>

<?php
include_once "Footer.php";
?>