<?php
include_once "dbConnector.php";



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_SESSION["currently_logged_in"] == true) {
        $_SESSION["current_user"] = "";
        $_SESSION["current_user_role"] = "";
        $_SESSION["currently_logged_in"] = false;
        http_response_code(301);
    }
}

header('Location: index.php');
exit();