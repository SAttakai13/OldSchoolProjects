<?php
include_once "dbConnector.php";

header('Content-Type: application/json');

$myDeleteJSON = "";

//If logged in AND admin
if ($_SESSION["currently_logged_in"] == true && $_SESSION["current_user_role"] === "admin") {
    if (isset($_GET["id"])) {

        $myDbConn = ConnGet();

        $id = $_GET["id"];



        if (DeletePokemon($myDbConn, $id)) {
            $myDeleteJSON = json_encode(["success" => "Record deleted successfully"]);
            http_response_code(301); //Deleted
        } else {
            $myDeleteJSON = json_encode(["error" => "Failed to delete record"]);
        }

        mysqli_close($myDbConn);
    } else {
        $myDeleteJSON = json_encode(["error" => "Missing required parameter 'id'"]);
    }

    echo $myDeleteJSON;
} else {
    http_response_code(401);
}

header('Location: apiFindPokemon.php');
exit();

?>
