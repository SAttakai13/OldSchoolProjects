<?php
include_once "Header.php";
?>
<h1>Mission</h1>
<div style="margin:10px; padding:15px;">
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ut tincidunt leo. Curabitur dignissim ante non tortor consequat, ut laoreet lorem rutrum. Mauris vel mi in risus euismod vehicula at id sapien. In ac viverra enim, id scelerisque massa. Donec maximus hendrerit risus interdum pharetra. Suspendisse rutrum, orci non dapibus gravida, quam felis cursus nunc, id mattis orci ante vel nunc. Donec ac tellus vitae lacus pretium dignissim pretium vel ligula. Integer non nulla aliquet, tincidunt sapien non, ullamcorper tortor. Sed dictum sollicitudin dapibus. Phasellus sagittis ornare vestibulum. Etiam id elit nunc. </p>

    <p>Etiam urna ligula, eleifend quis placerat a, aliquet sit amet sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse pulvinar justo id velit pulvinar efficitur. Aenean sem sem, aliquet ac aliquam eu, fringilla vel mi. Etiam sed volutpat augue. Nulla facilisi. Cras blandit justo in nunc posuere scelerisque. Mauris commodo pretium turpis sit amet vehicula.</p>

    <p>Cras sed luctus turpis, ut dictum dui. Nunc tempus eros justo, at convallis eros dapibus vitae. Sed euismod nec massa ut pretium. Phasellus nisl ligula, egestas consequat condimentum eu, euismod fermentum tortor. Maecenas tempor arcu id neque tempus, et viverra nisi pulvinar. Maecenas gravida ultricies dictum. Cras interdum in velit sed lacinia. Integer laoreet varius iaculis. Nam et est sit amet neque convallis posuere ultricies id nisi. Nam euismod pulvinar nunc. Maecenas rhoncus, tortor vel dignissim hendrerit, orci est mollis lacus, at interdum leo leo vel nibh. Pellentesque ultrices suscipit enim, eu hendrerit urna tincidunt a. Aliquam pellentesque magna magna, at sollicitudin nulla dictum id. Quisque at maximus mauris.</p>
</div>
<?php
include_once "Footer.php";
?>

