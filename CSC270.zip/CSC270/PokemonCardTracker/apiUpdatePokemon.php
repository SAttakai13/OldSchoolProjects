<?php

include_once 'Header.php';

?>

<html>
<body>
    <h2>Update Pokemon Card</h2>
    <form action="apiSqlUpdate.php" method="post">
        <label for="id">Pokemon Card ID: </label><br>
        <input type="number" id="id" name="id"><br>
        <label for="name">Name: </label><br>
        <input type="text" id="name" name="name"><br>
        <label for="url">Image URL: </label><br>
        <input type="text" id="url" name="url"><br><br>
         <label for="type">Type: </label><br>
        <input type="text" id="type" name="type"><br>
        <label for="hp">HP: </label><br>
        <input type="number" id="hp" name="hp" value="0"><br><br>
        <button type="submit">Update Pokemon</button>
    </form>
</body>
</html>
<?php
include_once 'Footer.php';
?>