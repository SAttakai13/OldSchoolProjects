<?php
include_once "dbConnector.php";

header('Content-Type: application/json');
$conn = ConnGet();
$id = -1;

//If logged in AND admin
if ($_SESSION["currently_logged_in"] == true && $_SESSION["current_user_role"] === "admin") {

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $url = $_POST['url'];
        $type = $_POST['type'];
        $hp = $_POST['hp'];

        $sql = "UPDATE pokedex SET name='$name', url='$url', type='$type', hp='$hp' WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
            http_response_code(301);
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
}

header("Location: PokemonCard.php?id=" . $id);
exit();
?>