<?php
include_once "Header.php";
include_once "dbConnector.php";
?>
<?php
$conn = ConnGet();

if ($_SESSION["currently_logged_in"] == false) {
    http_response_code(301);
    header("Location: UserLogin.php");
    exit();
}
?>

<script>
   var request = new XMLHttpRequest();

     window.onload = function () {
         // alert("onload() worked")
         loadJson();
    }
    // ---------------------------------
            // Call the microservice and get the data
    function loadJson() {
        // alert("id: " + id); // Use for debugging
        request.open('GET', 'apiSqlFindUserCards.php?userId=' + <?php
            $user = GetUserByUsername($conn, $_SESSION["current_user"]);
            $id = $user["user_id"];
            echo $id;
        ?>);
        request.onload=loadComplete;
        request.send();
    }

    // Run when the data has been loaded
    function loadComplete(evt) {
        var myResponse;
        var myData;
        var myReturn = "";

        myResponse = request.responseText;
        //alert("A: " + myResponse); // Use for debugging
        //document.getElementById("A").innerHTML = myResponse; // Display the json for debugging

        myData = JSON.parse(myResponse);

        // alert(myData);
        myReturn += "<div class='multi-cards'>";

        // Loop through each json record and create the HTML
        for (index in myData) {
            myReturn += "<div class='search-card-container'> <div class='search-card'>" + "<img class='search-card-img' width='100px' src='" + myData[index].url + "'/>" +
                "<div class='search-card-content'><h2 class='search-card-title'>" + myData[index].id + ": <a href='PokemonCard.php?id=" + myData[index].id + "'>" +
                myData[index].name + "</a></h2><p class='search-card-description'> <b>Type: </b>" +
                myData[index].type +
                "<br><b>HP: </b> " + myData[index].hp + "</p></div></div></div>";

        }

        myReturn += "</div>";
        document.getElementById("jsonData").innerHTML = myReturn; 
    }


</script>


<p id="jsonData"></p>

<?php
include_once "Footer.php";
?>