<?php
session_start();
//if (!isset($_SESSION['user_id'])) {
//    header('Location: UserLogin.php');
//    exit();
//}
$pdo = new PDO('mysql:host=localhost;dbname=pokemoncards', 'root', 'OnyxPassword1!');
$stmt = $pdo->prepare("SELECT * FROM user_cards WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$saved_cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Your Cards</h1>
<ul>
    <?php if ($saved_cards): ?>
        <?php foreach ($saved_cards as $card): ?>
            <li>
                <h2><?php echo htmlspecialchars($card['name']); ?></h2> 
                <p>Type: <?php echo htmlspecialchars($card['type']); ?></p>
                <p>HP: <?php echo htmlspecialchars($card['hp']); ?></p>
                <!-- Include any other relevant card details -->
                <?php if ($card['url']): ?>
                    <img src="<?php echo htmlspecialchars($card['url']); ?>" alt="<?php echo htmlspecialchars($card['name']); ?>">
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    <?php else: ?>
        <li>No cards found.</li>
    <?php endif; ?>
</ul>
