<br/>
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="apiCreatePokemon.php">Create Pokemon</a></li>
  <li><a href="apiFindPokemon.php">Browse Pokemon</a></li>
  <li class="dropdown">
    <a href="Contact.php" class="dropbtn">Contact</a>
    <div class="dropdown-content">
        <a href="Locations.php">Locations</a>
        <a href="Email.php">Email</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="About.php" class="dropbtn">About</a>
    <div class="dropdown-content">
        <a href="History.php">History</a>
        <a href="Mission.php">Mission</a>
    </div>
  </li>
  <li class="dropdown">
        <a href="javascript:void(0)" class="dropbtn">Account</a>
        <div class="dropdown-content">
            <?php
            if ($_SESSION["currently_logged_in"] == true) {
                ?>
                <a href="apiFindUserPokemon.php">My Pokemon Cards</a>
                <form action="apiUserLogout.php" method="post">
                    <input type="submit" value="Logout">
                </form>
            <?php
            } else {
                ?>
                <a href="UserLogin.php">Login</a>
                <a href="UserRegister.php">Register</a>
            <?php
            }
            ?>
        </div>
  </li>
</ul>
    
    
    
    
    

    
    
</div>