<?php
include_once "dbConnector.php";
header('Content-Type:application/json');

$myJSON = "";
$row = null;
$myGet = "";

// Process if there is a parameter (GetPokemonName)
if (array_key_exists("GetPokemonName", $_GET) == TRUE) {
    // Get the db connection
    $myDbConn = ConnGet();
    $myGet = $_GET["GetPokemonName"];
    $myJsonResult = MyJoinFind($myDbConn, $myGet);

    $myJSON = null;
    $row = null;

    if ($myJsonResult) {
        while ($row = mysqli_fetch_array($myJsonResult)) {
            $rowArray[] = json_decode($row[0]);
        }
        $myJSON = json_encode($rowArray);
    }
    mysqli_close($myDbConn);
}

echo $myJSON;
