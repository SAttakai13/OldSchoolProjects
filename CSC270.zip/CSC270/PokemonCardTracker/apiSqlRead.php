<?php
include_once "dbConnector.php";

header('Content-Type: application/json');

$myJSON = "";
$row = null;
$myGet = "";
$myPost = "";

// Process if there is a parameter (id)
if (array_key_exists("id", $_GET) == TRUE)
{
    // Get the db connection
    // Get the data
    $myDbConn = ConnGet();
    $myGet = $_GET["id"];
    // Get the records
    $dataSet = MyJoinWhereGet($myDbConn, $myGet);

    // If the data exists, format the values
    if ($dataSet){
        // $myJSON = "[";
        if($row = mysqli_fetch_array($dataSet)) {
            $myJSON = '[{"name":"' . $row['name'] . '","url":"' . $row['url'] . '","type":"' . $row['type'] . '","hp":"' . $row['hp'] . '"}]';
        }
    } else {
        http_response_code(404); //Not Found
    }

    mysqli_close($myDbConn);
}

echo $myJSON;




?>