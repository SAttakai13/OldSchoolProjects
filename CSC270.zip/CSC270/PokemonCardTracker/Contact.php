<?php
include_once "Header.php";
?>

<h1>Contact</h1>
<div style="margin:10px; padding:15px;">
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ut tincidunt leo. Curabitur dignissim ante non tortor consequat, ut laoreet lorem rutrum. Mauris vel mi in risus euismod vehicula at id sapien. In ac viverra enim, id scelerisque massa. Donec maximus hendrerit risus interdum pharetra. Suspendisse rutrum, orci non dapibus gravida, quam felis cursus nunc, id mattis orci ante vel nunc. Donec ac tellus vitae lacus pretium dignissim pretium vel ligula. Integer non nulla aliquet, tincidunt sapien non, ullamcorper tortor. Sed dictum sollicitudin dapibus. Phasellus sagittis ornare vestibulum. Etiam id elit nunc. </p>
</div>
<?php
include_once "Footer.php";
?>