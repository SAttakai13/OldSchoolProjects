<?php
session_start();
?>
<?php
define('DB_USER', 'root');
define('DB_PSWD', 'Primeaux!07113');
define('DB_SERVER', 'localhost');
define('DB_NAME', 'pokemoncards');

function ConnGet(){
    $dbConn = @mysqli_connect(DB_SERVER, DB_USER, DB_PSWD, DB_NAME)
        or die('Failed to connect to db '. DB_SERVER . ' :: ' . DB_NAME . ' :: ' . DB_USER . ' :: ' . DB_PSWD);

    return $dbConn;
}

function MyJoinJsonGet($dbConn){
    $query = "select json_object(
              'id', pok.id,
              'name', pok.name,
              'url',pok.url,
              'hp', pok.hp,
              'type', pok.type) as Json1
              from pokedex pok;";

    return @mysqli_query($dbConn, $query);
}
function MyJoinWhereGet($dbConn, $id)
{

    $query = "SELECT pok.name, pok.url, pok.type, pok.hp
   FROM pokedex pok
   where pok.id = " . $id . " limit 1;";

    return @mysqli_query($dbConn, $query);
}

function MyJoinFind($dbConn, $search){
    $query = "select json_object(
              'id', pok.id,
              'name', pok.name,
              'url',pok.url,
              'hp', pok.hp,
              'type', pok.type) as Json1
              from pokedex pok where pok.name like '%" . $search . "%'";
    return @mysqli_query($dbConn, $query);
}

function GetUserCards($dbConn, $id)
{
    $query = "select json_object('cards', saved_cards) as Cards from users where user_id = " . $id;
    return @mysqli_query($dbConn, $query);
}


function InsertPokemon($dbConn, $name, $url, $type, $hp)
{
    $name = mysqli_real_escape_string($dbConn, $name);
    $url = mysqli_real_escape_string($dbConn, $url);
    $type = mysqli_real_escape_string($dbConn, $type);
    $hp = mysqli_real_escape_string($dbConn, $hp);

    $query = "INSERT INTO pokedex (name, url, type, hp) VALUES ('$name', '$url', '$type', '$hp')";
    $result = mysqli_query($dbConn, $query);

    return $result ? true : false;
}
function DeletePokemon($dbConn, $id)
{
    $id = mysqli_real_escape_string($dbConn, $id);

    $query = "DELETE FROM pokedex WHERE id = '$id'";

    $result = mysqli_query($dbConn, $query);

    //Get user that owns card
    $user = GetUserByContainsCard($dbConn, $id);
    if ($user) {
        $userId = $user["user_id"];
        $card_list = $user["saved_cards"];
        if ($card_list) {
            if (($key = array_search($id, $card_list)) !== false) {
                unset($card_list[$key]);
            }

            $card_list = json_encode($card_list);
            $sql = "UPDATE users SET saved_cards='$card_list' WHERE user_id=$userId";
            if ($dbConn->query($sql) === TRUE) {
                echo "New record added to user list successfully";
                http_response_code(301); //Created
            } else {
                echo "Error: " . $sql . "<br>" . $dbConn->error;
            }
        }
    }

    if ($result) {
        return true; 
    } else {
        return false; 
    }

    //
}

function UpdateRecord($dbConn, $table, $id, $data)
{
    $setClause = "";
    foreach ($data as $key => $value) {
        $setClause .= "$key='$value', ";
    }
    $setClause = rtrim($setClause, ", ");

    $query = "UPDATE $table SET $setClause WHERE id='$id'";

    $result = mysqli_query($dbConn, $query);

    if ($result) {
        return true;
    } else {
        return false;
    }
}


function GetUserByUsername($dbConn, $username)
{
    // Get the user
    $dataSet = @mysqli_query(
        $dbConn,
        "select json_object(
            'user_id', u.user_id,
            'username', u.username,
            'encrypted_password', u.encrypted_password,
            'role', u.role,
            'saved_cards', u.saved_cards) as Users
            from users u where u.username = '" . $username . "'"
    );

    // If the data exists, format the values
    if ($dataSet) {
        if ($row = mysqli_fetch_array($dataSet)) {
            $data = $row["Users"];
            if ($data === "")
                return null;
            else
                return json_decode($data, true);
        }
    }
    return null;
}

function GetUserByContainsCard($dbConn, $cardId)
{
    // Get the user
    $dataSet = @mysqli_query(
        $dbConn,
        "select json_object(
            'user_id', u.user_id,
            'username', u.username,
            'encrypted_password', u.encrypted_password,
            'role', u.role,
            'saved_cards', u.saved_cards) as Users
            from users u where json_contains(saved_cards, '$cardId')"
    );

    // If the data exists, format the values
    if ($dataSet) {
        if ($row = mysqli_fetch_array($dataSet)) {
            $data = $row["Users"];
            if ($data === "")
                return null;
            else
                return json_decode($data, true);
        }
    }
    return null;
}

function GetPokemonById($dbConn, $id)
{
    // Get the user
    $dataSet = @mysqli_query(
        $dbConn,
        "select json_object(
              'id', pok.id,
              'name', pok.name,
              'url',pok.url,
              'hp', pok.hp,
              'type', pok.type) as Poke
              from pokedex pok where pok.id = " . $id
    );

    // If the data exists, format the values
    if ($dataSet) {
        if ($row = mysqli_fetch_array($dataSet)) {
            $data = $row["Poke"];
            if ($data === "")
                return null;
            else
                return json_decode($data, true);
        }
    }
    return null;
}

function GetUserById($dbConn, $id)
{
    // Get the user
    $dataSet = @mysqli_query(
        $dbConn,
        "select json_object(
            'user_id', u.user_id,
            'username', u.username,
            'encrypted_password', u.encrypted_password,
            'role', u.role) as Users
            from users u where u.user_id = " . $id
    );

    // If the data exists, format the values
    if ($dataSet) {
        if ($row = mysqli_fetch_array($dataSet)) {
            $data = $row["Users"];
            if ($data === "")
                return null;
            else
                return json_decode($data, true);
        }
    }
    return null;
}


?>