<?php
include_once 'Header.php';
?>


Input a Pokemon Card Index: &nbsp;
<input type="number" id="id" value="1"/>
<button name="submit" onclick="fetchRecord()">Submit</button>
<p id="A"></p>
<p id="jsonData"></p>

<script>
   var request = new XMLHttpRequest();

    function fetchRecord() {
        var id = document.getElementById("id").value;
        loadJson(id);
    }

    function loadJson(id) {
        request.open('GET', 'apiSqlDelete.php?id=' + id);
        request.onload = loadComplete;
        request.send();
    }

    function loadComplete(evt) {
        var myResponse;
        var myData;
        var myReturn = "<table><tr><td>name &nbsp;  &nbsp; </td><td>url &nbsp;  &nbsp; </td><td>type &nbsp;  &nbsp; </td><td>hp &nbsp;  &nbsp; </td><td>Action</td></tr>";

        myResponse = request.responseText;
        myData = JSON.parse(myResponse);

        for (index in myData) {
            myReturn += "<tr><td>" + myData[index].name + "</td><td>" +
                myData[index].url + "</td><td>" +
                myData[index].type + "</td><td>" +
                myData[index].hp + "</td><td><button onclick='deleteRecord(" + myData[index].id + ")'>Delete</button></td></tr>";
        }
        myReturn += "</table>";
        document.getElementById("jsonData").innerHTML = myReturn;
    }

    function deleteRecord(id) {
        var confirmDelete = confirm("Are you sure you want to delete this record?");
        if (confirmDelete) {
            var xhr = new XMLHttpRequest();
            xhr.open("DELETE", "apiDeletePokemon.php?id=" + this.id.value, true);
            xhr.onload = function () {
                if (xhr.status == 200) {
                    alert("Record deleted successfully");
                    fetchRecord();
                } else {
                    alert("Failed to delete record");
                }
            };
            xhr.send();
        }
    }
</script>

<a href="apiReadAll.php">Read all</a>

<?php
include_once "Footer.php";
?>
