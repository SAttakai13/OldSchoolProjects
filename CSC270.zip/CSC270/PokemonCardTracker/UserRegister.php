<?php
include_once "Header.php";
?>

<h2>Register</h2>
<form action="apiSqlUserPost.php" method="post">
    <label for="username">Username: </label><br>
    <input type="text" id="username" name="username"><br>
    <label for="email">Email: </label><br>
    <input type="text" id="email" name="email"><br>
    <label for="password">Password: </label><br>
    <input type="password" id="password" name="password"><br>

    <!--Replace with hidden input later-->
    <!--<label for="role">Role: </label><br>
    <input type="text" id="role" name="role"><br>-->
    <input type="hidden" id="role" name="role" value="admin">
    <input type="submit" value="Create Account">
</form>

<?php
include_once "Footer.php";
?>