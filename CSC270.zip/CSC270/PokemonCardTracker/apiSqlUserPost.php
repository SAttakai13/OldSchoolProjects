<?php
include_once "dbConnector.php";
include_once "passwordEncryptor.php";

header('Content-Type: application/json');

$conn = ConnGet();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (GetUserByUsername($conn, $username) == null) {
        $encryptedPassword = Encrypt($password);
        $sql = "INSERT INTO users (username, email, encrypted_password, role) VALUES ('$username', '$email', '$encryptedPassword', '$role')";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            http_response_code(301); //Created
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Username already exists";
    }
}

header('Location: UserLogin.php');
exit();
?>