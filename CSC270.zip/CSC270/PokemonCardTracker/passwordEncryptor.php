<?php

function Encrypt($pass) {
    if ($pass === null)
        return "";
    return password_hash($pass, PASSWORD_BCRYPT);
}

function Verify($pass, $hash) {
    return password_verify($pass, $hash);
}