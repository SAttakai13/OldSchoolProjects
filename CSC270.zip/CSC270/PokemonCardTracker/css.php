<?php
header("Content-type: text/css; charset: UTF-8");

$myColor = "";

if (strlen($myColor) < 1) {
    $myColor = "#e42d2f";
}

// Define your CSS styles here
$styles = "
html {
    background-color: #CCC;
    font-family: system-ui;
}

.multi-cards {
  display: flex;

}

.search-card-container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 30px;
  padding: 20px;
}

.search-card {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  Height: 300px;
  width:fit-content;
  margin: 20px;
  transition: transform 0.2s;
}

.search-card:hover {
  transform: translateY(-10px);
}

.search-card-img {
  display: block;
  margin-left:auto;
  margin-right:auto;
  width: 100px;
  height: fit-content;
  object-fit: cover;
}

.search-card-content {
  padding: 20px;
}

.search-card-title {
  font-size: 1.5em;
  margin: 0 0 10px 0;
}

.search-card-description {
  font-size: 1em;
  color: #555;
}

.search-card-footer {
  padding: 20px;
  background-color: #f7f7f7;
  text-align: center;
}

.search-card-button {
  background-color: #007bff;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  text-decoration: none;
  font-size: 1em;
  transition: background-color 0.3s;
}

.search-card-button:hover {
  background-color: #0056b3;
}

h1 {
    color: $myColor
}
ul {
  justify-content:center;
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: $myColor;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a, .dropdown-content input {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.card_container {
    margin: 20px 5vw;
    width: 20vw;
    display: block;
    aspect-ratio: 4 / 6;
    border: 5px solid #fee167;
    font-family: system-ui;
    border-radius: 10px;
    box-shadow: 8px 8px 20px 5px black;
}
.card_container div {
    display: grid;
    margin: 0;
    width: 100%;
}
.card_container .poke_name {
    float: left;
    color: black;
    font-weight: 900;
    font-size: 18pt;
    margin: 0;
    grid-row: 1;
    width: inherit;
}
.card_container .poke_type {
    text-align: right;
    float: right;
    margin: 0;
    font-size: 14pt;
    grid-row: 1;
    width: inherit;
}
.card_container .poke_desc {
    text-align: center;
    margin: 0;
    font-size: 12pt;
    width: 100%;
    max-width: 100%;
    min-width: 100%;
}
.card_container .poke_url {
    width: 100%;
}
.card_container .poke_hp {
    text-align: right;
    float: right;
    margin: 0;
    font-size: 14pt;
    grid-row: 2 / 1;
    width: inherit;
}
.card_container img {
    width: calc(100% - 8px);
    border-image: linear-gradient(#D3D3D3, #2D3436) 30;
    border-width: 4px;
    border-style: solid;
}
.card_edit_icon {
    width: 50px;
    height: 50px;
    font-size: 20pt;
    background: none;
    border: none;
    cursor: hand;
}

";

// Output the CSS styles
echo $styles;
?>
