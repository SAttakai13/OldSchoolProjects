<?php
include_once "dbConnector.php";
include_once "passwordEncryptor.php";

header('Content-Type: application/json');
$conn = ConnGet();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];

    //if logged in AND updating user is logged in OR user is admin
    if ($_SESSION["currently_logged_in"] == true && ($_SESSION["current_user"] === $username || $_SESSION["current_user_role"] === "admin")) {
        
        $userId = $_POST["user_id"];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $role = $_POST['role'];

        $encryptedPassword = Encrypt($password);
        $sql = "UPDATE users SET username='$username', email='$email', encrypted_password='$encryptedPassword', role='$role' WHERE user_id=$userId";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
            http_response_code(301);
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        http_response_code(401);
    }
    
}

header('Location: index.php');
exit();
