
<?php

echo 'Hello World!';

?>

<br/> Outside of server

 <?php
 echo 'Hello inside server again UwU';
 ?>