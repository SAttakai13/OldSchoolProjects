<?php
include_once "MyHeader.php";
?>


Home page

<?php
include_once "MyFooter.php";
?>
