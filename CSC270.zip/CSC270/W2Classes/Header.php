<?php
?>
<html>
    <body>
        <h1>Put site menu here</h1>

<br/>
<a href="GetSample.php?MyParam1=1234&MyParam2=asdf">Get Sample</a>
<br/>
<a href="ClassSample.php">Class Sample</a>
<br/>