<?php
require "Header.php"
?>

<?php
$myval = "qwerty";
echo "<br/> My value = " . $myval;

$myval = 1 + 2;
echo "<br/> My value = " . $myval;

$Param1 = "";
$Param2 = "";

if(array_key_exists('MyParam1', $_GET)){
    $Param1 = $_GET['MyParam1'];
    echo "<br/><br/> MyParam1 = " . $Param1; 
}

if (array_key_exists('MyParam2', $_GET)) {
    $Param2 = $_GET['MyParam2'];
    echo "<br/><br/> MyParam2 = " . $Param2;
}
?>

<br/>
<br/>
Some Simple text
<br/>

<?php
require "Footer.php"
?>
