<?php
include_once "SamplePersonClass.php";

/*
* Sample Student class to do something (idk)
* @version 1.0
* @author definitelynotme
* 
*/

class SampleStudentClass extends SamplePersonClass
{
    public $GPA= "1.0";

    public function _construct()
    {
        
    }
}
?>