<?php
require "Header.php";
?>


<?php

include_once "SamplePersonClass.php";
include_once "SampleStudentClass.php";

$Person = new SamplePersonClass();
$Person->FirstName = "Arch";
$Person->LastName = "Archerson";

echo "<br/> Person current age is: " . $Person->HaveBirthday();
echo "<br/>";

var_dump($Person); //Use for debugging variable-values
echo "<br/>";
echo "<br/>";

$Student = new SampleStudentClass();
$Student->FirstName = "Dave";
$Student->LastName = "Davidson";
$Student->Age = 27;
$Student->GPA = 3.99;
var_dump($Student);


?>



<?php
require "Footer.php"
?>
