<?php

echo 'Hello World!';
require "Header.php";
?>

<br/>

My Index Page

<?php
require "Footer.php";
?>