<?php
/*
 * Sample class for demo stuff
 * @version 1.0
 * @author <Put your name here>
 * 
 */


    class SamplePersonClass
    {
        public $FirstName = "";
        public $LastName = "";
        private $Age = 0;
        public $MyInt = 0;

        ////////
        //Incrament age by one
        public function HaveBirthday()
        {
            $this->Age++; //$this->Age+1;
            return $this->Age;
        }
    }

?>