<?php

?>
<html>
<head>
    <title>My title</title>
    <link rel="stylesheet" type="text/css" href="/CalcStyle"/>
</head>

<body>
    <h1>My calc header with standard menus</h1>
<?php
$myVal = "Html Value";    
?>