<?php

function WriteButton($name, $value, $text)
{
    echo "<button name='" . $name . "' value='" . $value . "' >" . $text . "</button>";
    return 1;
}
?>
