<?php
use UI\Controls\Form;
include_once "Util.php";
require_once "CalcHeader.php";

//echo 'Hello World!';

/*
//sample try/catch
try{
    $zero = 0;
    //if($zero == 0)
    //    throw new Exception("");

    echo "inside the try" . (1 / $zero);
} catch (Exception $e) {
    echo "<br> I caught something";
} finally {
    echo "<br> Final code <br>";
}
*/

$fNum = ""; // First number
$sNum = ""; // Second number
$op = ""; //Op Like: +, -, *, /
$eql = "";

$total = "";
$nbsp = "&nbsp;";

//Get the hidden value
if(array_key_exists('firstNum', $_POST))
{
    $fNum = $_POST['firstNum']; // this is how we get parameters
}

if (array_key_exists('secondNum', $_POST))
{
    $sNum = $_POST['secondNum']; // this is how we get parameters
}

if (array_key_exists('opButton', $_POST))
{
    $op = $_POST['opButton']; // this is how we get parameters
}

if (array_key_exists('eqlButton', $_POST))
{
    $eql = $_POST['eqlButton'];
}

if (array_key_exists('total', $_POST)){
    $total = $_POST['total'];
}

if (array_key_exists('numButton', $_POST))
{
    if (strlen($op) < 1)
        $fNum = $fNum . $_POST['numButton'];
    else
        $sNum = $sNum . $_POST['numButton'];
}
//Put you logic code here for processing calculator

if (array_key_exists('eqlButton', $_POST)){
    if($_POST['eqlButton'] == '='){
        switch($op)
        {
            case '+':
                $total = (intval($fNum) + intval($sNum));
                break;
            case '-':
                $total = (intval($fNum) - intval($sNum));
                break;
            case '*':
                $total = (intval($fNum) * intval($sNum));
                break;
            case '/':
                $total = (intval($fNum) / intval($sNum));
                break;
        }
    }
}

echo "<br><br>" . $fNum . $nbsp . $op . $nbsp . $sNum . $nbsp . $eql . $nbsp . $total;
?>

<br/>

<form method="post">
    <input type="hidden" name="firstNum" value="<?php echo $fNum?>"/>
    <input type="hidden" name="secondNum" value="<?php echo $sNum?>" />
    <input type="hidden" name="opButton" value="<?php echo $op?>"/>
    <input type="hidden" name="eqlButton" value="<?php echo $eql?>"/>
    <input type="hidden" name="total" value="<?php echo $total?>"/>

    <table>
      <tr>
        <th><?php WriteButton("numButton", "1", "1"); ?></th>
        <th><?php WriteButton("numButton", "2", "2"); ?></th>
        <th><?php WriteButton("numButton", "3", "3"); ?></th>
        <th><?php WriteButton("opButton", "+", "+"); ?></th>
      </tr>
      <tr>
        <th><?php WriteButton("numButton", "4", "4"); ?></th>
        <th><?php WriteButton("numButton", "5", "5"); ?></th>
        <th><?php WriteButton("numButton", "6", "6"); ?></th>
        <th><?php WriteButton("opButton", "-", "-"); ?></th>
      </tr>
      <tr>
        <th><?php WriteButton("numButton", "7", "7"); ?></th>
        <th><?php WriteButton("numButton", "8", "8"); ?></th>
        <th><?php WriteButton("numButton", "9", "9"); ?></th>
        <th><?php WriteButton("opButton", "*", "*"); ?></th>
      </tr>
      <tr>
        <th></th>
        <th><?php WriteButton("numButton", "0", "0"); ?></th>
        <th><?php WriteButton("opButton", "/", "/"); ?></th>
        <th><?php WriteButton("eqlButton", "=", "="); ?></th>
      </tr>
    </table>
</form>

<?php
echo $myVal;
require "CalcFooter.php";
?>


