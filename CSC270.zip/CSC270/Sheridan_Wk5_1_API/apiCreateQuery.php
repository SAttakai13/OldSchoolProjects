<?php
include_once "DBFunctions.php";

header('Content-Type: application/json');


$myDbConn = ConnectGet();

// Process if there is a parameter (id)
$getBody = file_get_contents('php://input');
$seecontent = json_decode($getBody);

$BookTitle = $seecontent -> Title;
$BookAuthor = $seecontent -> Author;
$BookCover = $seecontent -> Cover;
$BookGenre = $seecontent -> Genre;
$BookPrice = $seecontent -> Price;

$myJsonSend = MyCreateJSONPost($myDbConn, $BookTitle, $BookAuthor, $BookCover, $BookGenre, $BookPrice);

mysqli_close($myDbConn);
?>