<?php
include_once "Header.php";
// given an id, read record
// read all
?>

Input a person index (int): &nbsp;
<input type="text" id="GetRecordId" value="1"/>
<button name="a" onclick="myClickEvent()">Submit</button>

<p id="jsonData"></p>
<br/>


<script>
    var request = new XMLHttpRequest();
    // ---------------------------------
    //// Click event
    function myClickEvent() {
         // alert("my click"); // Use for debugging
        //alert("data: " + document.getElementById("Id").value); // Use for debugging
        loadJson(document.getElementById("GetRecordId").value);
    }

     
    function loadJson(id) {
        //alert("id: " + id); // Use for debugging
        request.open('DELETE', 'apiDeleteQuery.php?GetRecordId=' + id);
        request.onload=loadComplete;
        request.send();
    }

</script>


<?php
include_once "Footer.php";
?>