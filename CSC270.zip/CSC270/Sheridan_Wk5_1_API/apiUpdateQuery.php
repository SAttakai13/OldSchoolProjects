<?php
include_once "DBFunctions.php";

header('Content-Type: application/json');

// Get the connection
// Set the data
$myDbConn = ConnectGet();
$getBody = file_get_contents('php://input');
$seecontent = json_decode($getBody);

$BookId = $seecontent->Id;
$BookTitle = $seecontent->Title;
$BookAuthor = $seecontent->Author;
$BookCover = $seecontent->Cover;
$BookGenre = $seecontent->Genre;
$BookPrice = $seecontent->Price;

MYUpdateJSONPost($myDbConn, $BookId, $BookTitle, $BookAuthor, $BookCover, $BookGenre, $BookPrice);

mysqli_close($myDbConn);

?>
