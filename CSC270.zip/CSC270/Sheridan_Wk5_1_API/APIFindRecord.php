<?php
include_once "Header.php";
// given an id, read record
// read all
?>

Input a person index (int): &nbsp;
<input type="text" id="GetRecordId" value="1"/>
<button name="a" onclick="myClickEvent()">Submit</button>

<p id="jsonData"></p>
<br/>


<script>
    var request = new XMLHttpRequest();
    // ---------------------------------
    //// Click event
    function myClickEvent() {
         // alert("my click"); // Use for debugging
        //alert("data: " + document.getElementById("Id").value); // Use for debugging
        loadJson(document.getElementById("GetRecordId").value);
    }

     
    function loadJson(id) {
        //alert("id: " + id); // Use for debugging
        request.open('GET', 'apiSqlQuery.php?GetRecordId=' + id);
        request.onload=loadComplete;
        request.send();
    }

    
    // ////
    function loadComplete(evt) {
        var myResponse = null;
        var myData = null;
        var myReturn = "<table><tr><td>Title &nbsp;  &nbsp; </td><td>Author &nbsp; &nbsp; </td><td>Cover &nbsp;  &nbsp; </td><td>Genre &nbsp;  &nbsp; </td><td>Price &nbsp;  &nbsp; </td></tr>";
        /// alert("Load complete...");

        myResponse = request.responseText;
        myData = JSON.parse(myResponse);

        for (index in myData) {
            myReturn += "<tr><td>" + myData[index].Title
                + "</td><td>" +
                myData[index].Author + "</td><td>" + 
                myData[index].Cover + "</td><td>" +
                myData[index].Genre + "</td><td>" +
                myData[index].Price + "</td></tr>";
        }
        myReturn += "</table>";
        document.getElementById("jsonData").innerHTML = myReturn;
    }
</script>


<?php
include_once "Footer.php";
?>
