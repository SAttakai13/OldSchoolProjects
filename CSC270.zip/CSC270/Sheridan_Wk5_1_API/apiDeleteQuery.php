<?php
include_once "DBFunctions.php";

header('Content-Type: application/json');

$myJSON = "";
$row = null;
$myGet = "";

// Process if there is a parameter (id)
if (array_key_exists("GetRecordId", $_DELETE) == TRUE) {
    // Get the db connection
    // Get the data
    $myDbConn = ConnectGet();
    $myGet = $_DELETE["GetRecordId"];
    // Get the records
    MYDeleteJSONPost($myDbConn, $myGet);
    mysqli_close($myDbConn);
}

echo $myJSON;

?>
