<br/>
<div class="topnav">
    <a href="index.php">Home</a>&nbsp;
    <a href="APIReadAllRecord.php">All Books</a>&nbsp;
    <a href="APIFindRecord.php">Search Books</a>&nbsp;
    <a href="APICreateRecord.php">Add Book</a>&nbsp;
    <a href="APIUpdateRecord.php">Update Book</a>&nbsp;
    <a href="APIDeleteRecord.php">Delete Book</a>&nbsp;
</div>
