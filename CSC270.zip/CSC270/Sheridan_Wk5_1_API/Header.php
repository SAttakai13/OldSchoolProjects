<html>
<head>
    <title>Bookstore</title>
    <h1>Bookstore Bookstuff</h1>
    <link rel="stylesheet" type="text/css" href="PatchCSS.php"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <?php include_once "Menu.php" ?>
    <br/>
</head>
<body>