<?php
include_once "Header.php";
//copy code from previous modules for api
//create a new record
?>

<form>
    <input type="text" id="RecordId" placeholder="Id"/>
    <br/>
    <input type="text" id="Title" placeholder="Title"/>
    <br/>
    <input type="text" id="Author" placeholder="Author"/>
    <br/>
    <input type="text" id="Cover" placeholder="Cover"/>
    <br/>
    <input type="text" id="Genre" placeholder="Genre"/>
    <br/>
    <input type="text" id="Price" placeholder="Price"/>
    <br/>
    <button name="UpdateBook" onclick="GrabInfo()">Update Book</button>
</form>

<script>
    var request = new XMLHttpRequest();
    // ---------------------------------
    function GrabInfo() {
        const Book = JSON.stringify(
            {   
                "Id": document.getElementById("RecordId").value,
                "Title": document.getElementById("Title").value,
                "Author": document.getElementById("Author").value,
                "Cover": document.getElementById("Cover").value,
                "Genre": document.getElementById("Genre").value,
                "Price": document.getElementById("Price").value
            });
        UpdateBook(Book);
    }

    function UpdateBook(Body) {
        //alert("This is the body:" + Body)
        request.open('POST', 'apiUpdateQuery.php");
        request.send(Body);
    }
</script>


<?php
include_once "Footer.php";
?>