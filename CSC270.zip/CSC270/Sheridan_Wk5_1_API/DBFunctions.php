<?php
define("DB_USER", "root");
define("DB_PSWB", "Primeaux!07113");
define("DB_SERVER", "localhost");
define("DB_NAME", "csc270bookstore");

// /////////////////////////////
function ConnectGet()
{
    $dbConn = @mysqli_connect(DB_SERVER, DB_USER, DB_PSWB, DB_NAME)
        or die("Failed to connect" . DB_SERVER . " :: " . DB_NAME . " :: " . DB_USER . " :: " . DB_PSWB);

    return $dbConn;

}

// /////////////////////////////
function MyJoinJSONGet($dbConn)
{
    //Create a query
    $query = "select json_object
            ('Title', b.BookName, 
               'Author', b.Author, 
               'Cover', b.BookImage,
               'Genre', b.Genre, 
               'Price', b.Price) as Json1 from books b;";

    return @mysqli_query($dbConn, $query);
}

// /////////////////////////////
function MyJoinWhereGet($dbConn, $id)
{
    $query = "select b.BookName, b.Author, 
                b.BookImage, b.Genre, b.Price 
                from books b where b.id = " . $id . " limit 1;";

    return @mysqli_query($dbConn, $query);
}

// /////////////////////////////

function MyCreateJSONPost($dbConn, $name, $author, $image, $genre, $price)
{
    $query = "Insert into books(BookName, Author, BookImage, Genre, Price) 
                values ('" . $name . "', '" . $author . "', '" . $image . "', '" . $genre . "', " . $price . ");";
    return @mysqli_query($dbConn, $query);
}


// /////////////////////////////
function MYUpdateJSONPost($dbConn, $id, $name, $author, $image, $genre, $price)
{
    $query = "UPDATE books SET BookName = '$name', Author = '$author', BookImage = '$image', Genre='$genre', Price= $price WHERE id = $id ;";
    return @mysqli_query($dbConn, $query);
}

// /////////////////////////////
function MYDeleteJSONPost($dbConn, $id)
{
    $query = "Delete from books where id = " . $id . ";";
    return @mysqli_query($dbConn, $query);
}

?>

