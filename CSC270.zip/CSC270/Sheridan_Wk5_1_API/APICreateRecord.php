<?php
include_once "Header.php";
//copy code from previous modules for api
//create a new record
?>

<form>
    <input type="text" id="Title" placeholder="Title"/>
    <br/>
    <input type="text" id="Author" placeholder="Author"/>
    <br/>
    <input type="text" id="Cover" placeholder="Cover"/>
    <br/>
    <input type="text" id="Genre" placeholder="Genre"/>
    <br/>
    <input type="text" id="Price" placeholder="Price"/>
    <br/>
    <button name="CreateBook" onclick="GrabBookInfo()">Add to Store</button>
</form>

<script>
    var request = new XMLHttpRequest();
    // ---------------------------------
    function GrabBookInfo() {
        const Book = JSON.stringify(
            {
                "Title": document.getElementById("Title").value,
                "Author": document.getElementById("Author").value,
                "Cover": document.getElementById("Cover").value,
                "Genre": document.getElementById("Genre").value,
                "Price": document.getElementById("Price").value
            });
        CreateBook(Book);
    }

    function CreateBook(Body) {
        alert("This is the body:" + Body)
        request.open('POST', 'apiCreateQuery.php');
        request.send(Body);
    }
</script>


<?php
include_once "Footer.php";
?>

