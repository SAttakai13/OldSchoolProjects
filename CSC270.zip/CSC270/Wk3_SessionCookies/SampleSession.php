<?php
include_once "header.php";

?>

<?php
if(!isset($_SESSION["MySession"])){
    $_SESSION['MySession'] = '';
}

if(session_status() == PHP_SESSION_ACTIVE){
    echo "<br/> <br/> Browser has an active session";
} else {
    echo "<br/> <br/> Browser deos not have an active session";
}

$_SESSION['MySession'] .= "2";

?>

<form method="post">
    <button type="submit" name="MyButton">Reprint Page</button>
</form>

My session value = <?php echo $_SESSION["MySession"]; ?>



<?php
include_once "footer.php";

?>



