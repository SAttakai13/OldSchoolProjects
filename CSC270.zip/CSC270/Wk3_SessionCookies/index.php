<?php

include_once "header.php";

?>

<br/>

Some index page

<?php
include_once "footer.php";    
?>