<?php
include_once "header.php";
?>

<?php
//unset($_SESSION["MySession"]); //remove single session value

session_destroy();//destroy all session values and session itself
?>

<?php
include_once "footer.php";    
?>