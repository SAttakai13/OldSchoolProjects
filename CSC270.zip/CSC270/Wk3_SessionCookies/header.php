<?php
session_start();
?>

<html>
<body>
    <br/>
    Put menus here
    <br/>
    <a href="SampleCookie.php">Cookie Time</a>&nbsp;
    &nbsp;
    <a href="RipCookie.php">Kill Cookie (Noooooo!)</a>&nbsp;
    &nbsp;
    <a href="SampleSession.php">Sample Session, what it do?</a>&nbsp;
    &nbsp;
    <a href="MurderSession.php">Rip Session, pour one out to for the homies x-x</a>&nbsp;
    &nbsp;
    <a href="KeyPairSample.php">Key Pair Sample</a>&nbsp;
