<?php
$cookie = "";

if(!isset($_COOKIE['MyCookie'])){
    $cookie = 1;
    setcookie("MyCookie", $cookie, time() + 3600,);
} 
else {
    $cookie = $_COOKIE["MyCookie"] . "1";
    setcookie("MyCookie", $cookie, time() + 3600, );
}

include_once "header.php";

?>


<?php 
echo "<br/> <br/> My cookie time is: ". $cookie
?>


<?php
include_once "footer.php"    
?>