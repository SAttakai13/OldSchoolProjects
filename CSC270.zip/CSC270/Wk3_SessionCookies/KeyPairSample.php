<?php
include_once "header.php"    
?>

<?php
$MyOtherKeyArray = array('Student1' => 'A', 'Student2' => 'B+', 'Student3' => 'F');
$MyOtherArray = array('a', 'b', 'c', 'd');

foreach($MyOtherKeyArray as $Student => $Grade){
    echo '<br/> Student: ' . $Student . ' has the grade ' . $Grade;
}

echo "<br/> <br/> Direct access: Student 1 grade: " . $MyOtherKeyArray['Student1'];

?>


<?php
include_once "footer.php"
?>


