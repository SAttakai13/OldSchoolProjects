<?php
include_once "header.php";
if (isset($_COOKIE["MyCookie"])){
    setcookie("MyCookie", $_COOKIE[""], time() + -100000);
}
?>



<br/>
Kill cookie page

<?php
include_once "footer.php";
?>
