use csc270bookstore;
Insert into books(BookName, Author, BookImage, Genre, Price) values ("jerky", "Quin Quinsel", "./../OhNotTheMeat.png", "Non-Fiction", 19.99);