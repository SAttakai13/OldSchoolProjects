<?php
include_once "DBConnector.php";
header('Content-Type: application/json');

$myDbConn = ConnectGet();
$myJsonResult = MyJoinJSONGet($myDbConn);

$myJSON = null;
$row = null;

if ($myJsonResult){
    while($row = mysqli_fetch_array($myJsonResult)){
        $rowArray[] = json_decode($row[0]);
    }
    $myJSON = json_encode($rowArray);
}
mysqli_close($myDbConn);
//$myDbConn->close();

echo $myJSON;

?>

