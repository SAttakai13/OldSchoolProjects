<?php
define("DB_USER", "root");
define("DB_PSWB", "Primeaux!07113");
define("DB_SERVER", "localhost");
define("DB_NAME", "csc270db");

// /////////////////////////////

function ConnectGet(){
    $dbConn = @mysqli_connect(DB_SERVER, DB_USER, DB_PSWB, DB_NAME)
        or die("Failed to connect" . DB_SERVER . " :: " . DB_NAME . " :: " . DB_USER . " :: " . DB_PSWB);

    return $dbConn;

}

// /////////////////////////////
function MyJoinJSONGet($dbConn){
    //Create a query
    $query = "select json_object(
                'jFname', per.FName,
                'jLname', per.LName,
                'jCell_id', cel.Cell_Id,
                'jCellNumber', cel.CellNumber) as Json1
                from Person per left join Cell cel
                on per.Cell_Id = cel.Cell_Id;";

    return @mysqli_query($dbConn, $query);
}

function MyJoinWhereGet($dbConn, $id)
{

    $query = "SELECT per.FName, per.LName, cel.Cell_Id, cel.CellNumber
   FROM Person per LEFT JOIN Cell cel
   ON per.Cell_Id = cel.Cell_Id where per.id = " . $id . " limit 1;";

    return @mysqli_query($dbConn, $query);
}




?>