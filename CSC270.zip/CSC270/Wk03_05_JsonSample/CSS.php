<?php
//We can make a dynamic stylesheet
header('Content-Type: text/css; charset:UTF-8;');

$myColor = "";

// Make db call
// Pretend we did a call

// Set default if no color

if(strlen($myColor) < 1){
    $myColor = "Green";
}

//Created style stuff below
?>

h1 {
    color: <?php echo $myColor?>;
}



