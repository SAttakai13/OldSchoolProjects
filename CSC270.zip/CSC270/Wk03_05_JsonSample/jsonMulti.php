<?php
include_once "Header.php";
?>

<p id="jsonData">No Data</p>
<br/>

<script>
    var request = new XMLHttpRequest();
     ////
    // onLoad() function
    window.onload = function () {
       //alert("Loading..")
       loadJson();
    };

    // ////
    function loadJson() {
        request.open('GET', "apiJsonQuery.php"); // Call endpoint
        request.onload = loadComplete;
        request.send();
    }
    // ////
    function loadComplete(evt) {
        var myResponse = null;
        var myData = null;
        var myReturn = "<table><tr><td>First Name &nbsp;  &nbsp; </td><td>Last Name &nbsp; &nbsp; </td><td>Cell Number &nbsp;  &nbsp; </td></tr>";
        /// alert("Load complete...");

        myResponse = request.responseText;
        myData = JSON.parse(myResponse);

        for (index in myData) {
            myReturn += "<tr><td>" + myData[index].jFname
                + "</td><td>" +
                myData[index].jLname + "</td><td>" + myData[index].jCellNumber;
        }
        myReturn += "</table>";
        document.getElementById("jsonData").innerHTML = myReturn;
    }
</script>


<?php
include_once "Footer.php";
?>
