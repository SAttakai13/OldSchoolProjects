<?php
//We can make a dynamic stylesheet
header('Content-Type: text/css; charset:UTF-8;');

$myColor = "";

// Make db call
// Pretend we did a call

// Set default if no color

if (strlen($myColor) < 1) {
    $myColor = "Green";
}

//Created style stuff below
?>

h1 {
    color: <?php echo $myColor ?>;
}
{
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.content {
  background-color: #ddd;
  padding: 10px;
}

.footer {
  background-color: #f1f1f1;
  padding: 10px;
}