<?php
?>
<br/>
<br/>
<div class="footer">
    <p>Copyright stuff 2024</p>
</div>

</body>
</html>