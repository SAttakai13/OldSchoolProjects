<?php
$TitleName = "";
?>

<html>
<head>
    <title>Sheri's Website<?php $TitleName?></title>
    <h1>Sheri's Website</h1>
    <link rel="stylesheet" type="text/css" href="PatchCSS.php"/>
    <?php include_once "Menu.php"?>
</head>
<body>