# This is a sample Python script.
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import psycopg2
from psycopg2 import Error
import pandas as pd

# Initial Set up to Read file


def print_dfile(name):
    # print(name)
    df = pd.read_parquet(name)
    df.reset_index()
    for index, row in df.iterrows():
        #print(col)
        print(row["passenger_count"]) #key value
        #print(row);


# Connect to Postgres
connection = psycopg2.connect(user="postgres", host="localhost", port="5432", database="postgres",
                              password="Primeaux!07113")


# def PostGresConnect():
#     try:
#         cursor = connection.cursor()
#         cursor.execute("drop table if exists taxi_data;")
#         cursor.execute("create table if not exists taxi_data(id bigserial, name varchar(500));")
#         cursor.execute("insert into taxi_data(name) values ('awesome class pro335');")
#         connection.commit()
#         print("inserted data into taxi_data table.")
#     except (Exception, Error) as error:
#         print("Error while connecting to PostgresSQL", error)
#     finally:
#         if (connection):
#             cursor.close()
#             connection.close()
#             print("PostgreSQL connection is Closed")
#

def ConvertAndInsertFromCSV():
    try:
        cursor = connection.cursor()
        cursor.execute("drop table if exists taxi_area_codes;")
        cursor.execute(
            "create table if not exists taxi_area_codes(LocationID int NOT NULL, Borough char(20), Zone varchar(200), service_zone varchar(200));")
        cursor.execute(
            "copy taxi_area_codes(LocationID, Borough, Zone, service_zone) from 'C:\\Users\\Public\\taxi_zone_lookup.csv' delimiter ',' csv header;")
        connection.commit()
        print("inserted data into taxi_area_code table.")
    except (Exception, Error) as error:
        print("Error while connecting to PostgresSQL", error)
    finally:
        if (connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is Closed")


def PostGresConnectAndInsert(name, month):
    df = pd.read_parquet(name)
    df.reset_index()
    try:
        cursor = connection.cursor()

        if month == 1:
            cursor.execute("drop table if exists taxi_data_2016;")
            cursor.execute("create table if not exists taxi_data_2016(id bigserial, MonthID int not null, VendorID bigint null, tpep_pickup_datetime timestamp, tpep_dropoff_datetime timestamp, passenger_count integer null, trip_distance double precision null, RatecodeID double precision null, store_and_fwd_flag varchar(15) null, PULocationID bigint null, DOLocationID bigint null, payment_type bigint, fare_amount double precision, extra double precision null, mta_tax double precision null, tip_amount double precision null, tolls_amount double precision null, improvement_surcharge double precision null, total_amount double precision null, congestion_surcharge double precision null, airport_fee double precision null);")
        print("starting the data insertion for " + str(month))

        num = 0;
        for index, row in df.iterrows():
            sqlcommand = (
                "insert into taxi_data_2016(MonthID, VendorID, tpep_pickup_datetime, tpep_dropoff_datetime, passenger_count, trip_distance, RatecodeID, store_and_fwd_flag, PULocationID, DOLocationID, payment_type, fare_amount, extra, mta_tax, tip_amount, tolls_amount, improvement_surcharge, total_amount, congestion_surcharge, airport_fee) values ({MonthID}, {VendorID}, '{tpep_pickup_datetime}', '{tpep_dropoff_datetime}', {passenger_count}, {trip_distance}, {RatecodeID}, '{store_and_fwd_flag}', "
                .format(
                    MonthID=month,
                    VendorID=row["VendorID"],
                    tpep_pickup_datetime=row["tpep_pickup_datetime"],
                    tpep_dropoff_datetime=row["tpep_dropoff_datetime"],
                    passenger_count=row["passenger_count"],
                    trip_distance=row["trip_distance"],
                    RatecodeID=row["RatecodeID"],
                    store_and_fwd_flag=row["store_and_fwd_flag"])
                );

            sqlcommand2 = (
                "{PULocationID}, {DOLocationID}, {payment_type}, {fare_amount}, {extra}, {mta_tax}, {tip_amount}, {tolls_amount}, {improvement_surcharge}, {total_amount}, {congestion_surcharge}, {airport_fee});"
                .format(
                    PULocationID=row["PULocationID"],
                    DOLocationID=row["DOLocationID"],
                    payment_type=row["payment_type"],
                    fare_amount=row["fare_amount"],
                    extra=row["extra"],
                    mta_tax=row["mta_tax"],
                    tip_amount=row["tip_amount"],
                    tolls_amount=row["tolls_amount"],
                    improvement_surcharge=row["improvement_surcharge"],
                    total_amount=row["total_amount"],
                    congestion_surcharge=(row["congestion_surcharge"] if row["congestion_surcharge"] == "nan" else "null"),
                    airport_fee=(row["airport_fee"] if row["airport_fee"] == "nan" else "null")).replace("'", "''"));

            commandcombine = (sqlcommand + sqlcommand2);
            num += 1;
            print(num)
            cursor.execute(commandcombine)
            connection.commit()
        print("inserted data into taxi_data table..")
    except (Exception, Error) as error:
        print("Error while connecting to PostgresSQL", error)
    finally:
        if (connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is Closed")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    #print("Starting november")
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-01.parquet", 1)

    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-02.parquet", 2)
    #print_dfile("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-02.parquet");

    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-03.parquet", 3)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-04.parquet", 4)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-05.parquet", 5)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-06.parquet", 6)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-07.parquet",7)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-08.parquet",8)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-09.parquet", 9)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-10.parquet", 10)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-11.parquet", 11)
    #PostGresConnectAndInsert("C:\\Users\\Sheridan Attakai\\Downloads\\yellow_tripdata_2016-12.parquet", 12)
