select count(*) from taxi_data_all_col;
select * from taxi_data_all_col limit 1000;

create table payment_types(
    id int, name varchar(20)
);

-- insert into payment_types (id, name) values (1, 'Credit Card');
-- insert into payment_types (id, name) values (2, 'No Charge');
-- insert into payment_types (id, name) values (3, 'Dispute');
-- insert into payment_types (id, name) values (4, 'Unknown');
-- insert into payment_types (id, name) values (5, 'Voided Trip');

select vendorid, tpep_pickup_datetime, tpep_dropoff_datetime, pt.name
from taxi_data_all_col td
    inner join payment_types pt on td.payment_type = pt.id
limit 100;