package attakai.sheridan.SEN300_BookService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sen300BookServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sen300BookServiceApplication.class, args);
	}

}
