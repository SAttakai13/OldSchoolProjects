
using System.ComponentModel.DataAnnotations;

public class BookDTO
{    
    public Guid BookGuid { get; set; } 
    public String Title { get; set; }    
    public String Description { get; set; }    
    public DateTime PublishedDate { get; set; }
    public DateTime CreatedDate { get; set; }

}