import PersonClass as pc


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    p = pc.Person()
    p.CommandNDemandData()
