import json
from os import path
import sys

global _dictload



class Person:
    __filename = "PeopleList.json"
    _dictload = []

    def __init__(self, fname="", lname="", pnumber=""):
        self.fname = fname
        self.lname = lname
        self.pnumber = pnumber

    def list(per):
        with open(per.__filename) as f:
            inputdiction = f.read()
            _dictload = json.loads(inputdiction)
            return _dictload

    def InputLengthCheck(per, inputarray, length):
        if len(inputarray) == length:
            return True
        else:
            return False

    def __find(per, name):
        for peopleindex in per.list():
            for person in peopleindex:
                if peopleindex[person] == name:
                    return peopleindex
        return f"{name} not found"

    def __addperson(per,  fname, lname, pnumber):
        initialList = []
        dictionary = {}
        dictionary["First_Name"] = fname
        dictionary["Last_Name"] = lname
        dictionary["Phone_Number"] = pnumber

        if path.exists(per.__filename):
            initialList = per.list()
            initialList.append(dictionary)
            with open(per.__filename,'w') as f:
                f.write(json.dumps(initialList, indent=4))
        else:
            initialList.append(dictionary)
            with open(per.__filename,'w') as f:
                f.write(json.dumps(initialList, indent=4))


    def __deleteperson(per, name):
        Person = per.__find(name)
        PersonList = per.list()
        PersonList.remove(Person)
        with open(per.__filename, 'w') as f:
            f.write(json.dumps(PersonList, indent=4))

    #Start application here
    def CommandNDemandData(self):
        while True:
            print(
                "Input person to logs, to add: (add [fname] [lname] [phone]) \n to list all records: (list) \nto delete a person: (delete [name]) \nto find a person: (find [name]) \nto quit: (quit)")
            command = input()
            userinput = command.lower()
            while True:
                peopleArray = command.split(" ")
                if "add" in userinput:  # works
                    try:
                        if self.InputLengthCheck(peopleArray, 4):
                            self.__addperson(peopleArray[1], peopleArray[2], peopleArray[3])
                            print(f"{peopleArray[1]} {peopleArray[2]} was added")
                            break
                        else:
                            raise Exception()
                    except:
                        print("Input invalid.")
                        break  # something has gone wrong here
                elif "list" in userinput:  # works
                    try:
                        if self.InputLengthCheck(peopleArray, 1):
                            print(self.list())
                            break
                        else:
                            raise Exception()
                    except:
                        print("Input invalid.")
                        break  # something has gone wrong here
                elif "find" in userinput:
                    try:
                        if self.InputLengthCheck(peopleArray, 2):
                            print(self.__find(peopleArray[1]))
                            break
                        else:
                            raise Exception()
                    except:
                        print("Input Invalid")
                        break  # something has gone wrong here
                elif "delete" in userinput:
                    try:
                        if self.InputLengthCheck(peopleArray, 2):
                            self.__deleteperson(peopleArray[1])
                            print(f"{peopleArray[1]} removed")
                            break
                            # delete method
                        else:
                            raise Exception()
                    except:
                        print("Input Invalid")
                        break  # something has gone wrong here
                elif "quit" in userinput:  # works
                    if self.InputLengthCheck(peopleArray, 1):
                        sys.exit(0)
                else:
                    continue

