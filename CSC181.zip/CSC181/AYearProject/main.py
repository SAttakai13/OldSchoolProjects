import GUIToRemember

if __name__ == '__main__':
    GUIToRemember.GUISetUp()
