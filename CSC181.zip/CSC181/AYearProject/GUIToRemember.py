import tkinter as tk
import random

QuestionsList = []
userquest = ""

idx = 0

totalPoints = 0
year = 0
questionnumber = 0
user_responce = ''
EventList = []
form = tk.Tk()
form.title("Years in History Test")
form.geometry("600x700")

labelUserQuestion = tk.Label(form, height=2, width=75)
labelUserQuestion.grid(column=0, row=0)

UserResponcetxt = tk.Text(form, height=1, width=20)
UserResponcetxt.grid(column=0, row=1)

labelUserResponce = tk.Label(form, height=2, width=30)
labelUserResponce.grid(column=0, row=7)
def setup():
    revolution = ("The start of the Revolutionary War", 1775)
    constitution = ("The United States Constitution signed", 1783)
    assassination = ("President Lincoln assassinated", 1865)
    roosevelt = ("Theodore Roosevelt's first day in office as President of the United States", 1901)
    war = ("The beginning of World War II", 1939)
    computer = ("The first personal computer introduced", 1975)
    wall = ("The Berlin Wall taken down", 1989)
    clone = ("Dolly the Sheep born", 1996)
    towers = ("the World Trade Center destroyed", 2001)
    iphone = ("the first IPhone released", 2007)

    QuestionsList.append(revolution)
    QuestionsList.append(constitution)
    QuestionsList.append(assassination)
    QuestionsList.append(roosevelt)
    QuestionsList.append(war)
    QuestionsList.append(computer)
    QuestionsList.append(wall)
    QuestionsList.append(clone)
    QuestionsList.append(towers)
    QuestionsList.append(iphone)

    random.shuffle(QuestionsList)
    return QuestionsList


def RangeFinder(input, eventyear,  rangeNumber, points, totalpoints):
    if input - rangeNumber <= eventyear <= input + rangeNumber:
        totalpoints += points



def btnSubmit_click():
    global idx
    idx += 1
    print(f' {EventList[idx][0]}')
    labelUserQuestion.config(text=f"In what year was {EventList[1][0]}?")
    form.update()

def CheckYear(input, year):
    if input.isdigit():
        int_year = int(input)
        if 999 < int_year < 10000:
            if int_year == year:
                totalPoints += 10
                respond = f"Correct! Did you google this? lol ----- Points:{totalPoints}"
                questionnumber += 1
            elif RangeFinder(int_year, year, 5, 5, totalPoints):
                totalPoints += 5
                respond = f"Close, but off around 5 years or so, the correct answer was: {year} --------- Points: {totalPoints}"
                questionnumber += 1
            elif RangeFinder(int_year, year, 10, 2, totalPoints):
                totalPoints += 2
                respond = f"Close, but off around 10 years or so, the correct answer was: {year} --------- Points: {totalPoints}"
                questionnumber += 1
            elif RangeFinder(int_year, year, 20, 1, totalPoints):
                totalPoints += 1
                respond = f"Close, but off around 20 years or so, the correct answer was: {year} --------- Points: {totalPoints}"
                questionnumber += 1
            else:
                totalPoints += 0
                respond = f"Wow you need to retake history, the correct answer was: {year} ----- Points:{totalPoints}"
                questionnumber += 1
            return respond
        else:
            labelUserResponce.config(text="Invalid Input, retype again in 4 digit years")
    else:
        labelUserResponce.config(text="Invalid Input, only put in numbers")

def responceSet():
    user_responce = UserResponcetxt.get(1.0, "end-1c")

def GUISetUp():
    global totalPoints
    global year
    global questionnumber
    global user_responce
    global EventList

    EventList = setup()
    user_responce = ""
    questionnumber = 0
    year = 0
    totalPoints = 0





    def StartGame(List):

        labelUserQuestion.config(text=f"In what year was {List[0][0]}?")
        '''
        while questionnumber < len(List):
            year = List[questionnumber]
            labelUserQuestion.config(text=f"In what year was {year[0]}?")
            CheckYear(user_responce, year[1])
        '''


    btnClick = tk.Button(form, text='Check', command=responceSet())
    btnClick.grid(column=0, row=4)


    btnSubmit = tk.Button(form, text='Submit', command=btnSubmit_click())
    btnSubmit.grid(column=0, row=5)

    StartGame(EventList)


    labelUserResponce.config(text=f"Final score: {totalPoints} out of 100 possible points. Start again? Y/N")

    form.mainloop()

