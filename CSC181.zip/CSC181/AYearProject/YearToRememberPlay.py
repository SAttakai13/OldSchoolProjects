# can create a list of tuples that holds the event and the date.
import random
import sys

QuestionsList = []


def SetUpList():
    revolution = ("The start of the Revolutionary War", 1775)
    constitution = ("The United States Constitution signed", 1783)
    assassination = ("President Lincoln assassinated", 1865)
    roosevelt = ("Theodore Roosevelt's first day in office as President of the United States", 1901)
    war = ("The beginning of World War II", 1939)
    computer = ("The first personal computer introduced", 1975)
    wall = ("The Berlin Wall taken down", 1989)
    clone = ("Dolly the Sheep born", 1996)
    towers = ("World Trade destroyed", 2001)
    iphone = ("the first IPhone released", 2007)

    QuestionsList.append(revolution)
    QuestionsList.append(constitution)
    QuestionsList.append(assassination)
    QuestionsList.append(roosevelt)
    QuestionsList.append(war)
    QuestionsList.append(computer)
    QuestionsList.append(wall)
    QuestionsList.append(clone)
    QuestionsList.append(towers)
    QuestionsList.append(iphone)

    random.shuffle(QuestionsList)


# you are completing the point distribution system

def YearToRemember():
    SetUpList()
    totalpoints = 0
    print("Lets Play a year to remember!")
    for event in QuestionsList:
        print(f"In what year was {event[0]}?")
        while True:
            year = input()

            # checks if the year is a number
            if year.isdigit():
                int_year = int(year)
                print(int_year)

                # checks if the year is within the 4 digit range
                if 999 < int_year < 10000:

                    # checks if the date picked is correct
                    if int_year == event[1]:
                        totalpoints += 10
                        print(f"Correct! Did you google this? lol ----- Points:{totalpoints}")
                        break
                    elif int_year-5 <= event[1] <= int_year + 5:
                        totalpoints += 5
                        print(f"Close, but off around 5 years or so, the correct answer was: {event[1]} ----- Points:{totalpoints}")
                        break
                    elif int_year - 10 <= event[1] <= int_year + 10:
                        totalpoints += 2
                        print(f"Close, but off around 10 years or so, the correct answer was: {event[1]} ----- Points:{totalpoints}")
                        break
                    elif int_year - 20 <= event[1] <= int_year + 20:
                        totalpoints += 1
                        print(f"Close, but off around 20 years or so, the correct answer was: {event[1]} ----- Points:{totalpoints}")
                        break
                    else:
                        totalpoints += 0
                        print(f"Wow you need to retake history, the correct answer was: {event[1]} ----- Points:{totalpoints}")
                        break
                else:
                    print('invalid')
                    continue
            else:
                print('error')
    print(f"Final score: {totalpoints} out of 100 possible points. Start again? Y/N")

    inputuser = input()
    UserResponse = str(inputuser)
    if UserResponse.upper() == 'Y':
        YearToRemember()
    else:
        sys.exit(0)



