import Corrector as correct
if __name__ == '__main__':
    correct.retrieverenameimages("C:\\Users\\Sheridan Attakai\\Documents\\Quarter 11\\images\\images")

