import sys, os
from PIL import Image

def retrieverenameimages(filepath):
    # images should be grabbed here from the file
    print("retrieving images")
    folder = filepath
    for count, filename in enumerate(os.listdir(folder)):
        if count<10:
            dst = f"pic000{str(count)}.jpg"
        elif count<100:
            dst = f"pic00{str(count)}.jpg"
        elif count<1000:
            dst = f"pic0{str(count)}.jpg"
        src = f"{folder}/{filename}"
        dst = f"{folder}/{dst}"
        os.rename(src, dst)
    print("Now Converting to png")
    ConvertJPGToPNG(filepath)


def ConvertJPGToPNG(folder): #fixed
    global newFilePath
    print("Conversion began")
    for filename in enumerate(os.listdir(folder)):
        f, e = os.path.splitext(filename[1])
        outfile = f + ".png"
        if filename[1] != outfile:
            try:
                setFilePath = folder+"\\"+filename[1]
                newFilePath = "new_images"
                if os.path.exists(newFilePath) == False:
                    os.mkdir(newFilePath)
                sendFileTo = f"{newFilePath}\\{outfile}"
                with Image.open(setFilePath, 'r') as im:
                    im.save(sendFileTo)
            except OSError:
                print("cannot convert", filename)
    print("Conversion complete")
    RotatePic(newFilePath)


def RotatePic(folder): # Rotate so the faces of the people are oriented correctly, there should be no black edges showing
    print("Images rotation begin")
    for filename in enumerate(os.listdir(folder)):
        setPath = folder + "\\" + filename[1]
        try:
            with Image.open(setPath, 'r') as im:
                im = im.convert('RGBA')
                im = im.rotate(-90)
                im.save(setPath)
        except OSError:
            print("Cannot convert")
    print("Finished images rotation")
    ThumbnailResize(folder)


def ThumbnailResize(folder): #thumbnails resize 75x75 pixels
    print("Resize Thumbnail")
    size = (75, 75)
    for filename in enumerate(os.listdir(folder)):
        f, e = os.path.splitext(filename[1])
        setPath = folder + "\\" + filename[1]
        try:
            with Image.open(setPath, 'r') as im:
                im.convert('RGBA')
                im.thumbnail(size)
                im.save(setPath)
        except OSError:
            print("Cannot convert")
    ConvertGreyScale(folder)
    print("Thumbnail resize complete")


def ConvertGreyScale(folder):
    print("Convert to greyscale")
    for filename in enumerate(os.listdir(folder)):
        setPath = folder + "\\" + filename[1]
        try:
            with Image.open(setPath, 'r') as im:
                im = im.convert('L')
                im.save(setPath)
        except OSError:
            print("Cannot convert")
    print("Greyscale conversion complete")
