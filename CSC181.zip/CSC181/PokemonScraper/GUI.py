import PySimpleGUI as sg
import requests as req
from bs4 import BeautifulSoup as soup

def retrieveAPI():
    Links = []
    resp = req.get("https://www.mtgpics.com/set?set=441")
    html = resp.text
    SoupParse = soup(html, "html.parser")
    for imageLinks in SoupParse.find_all('img'):
        Links.append(f"{imageLinks.get('src')}")
    return Links

def filterCards():
    TextboxStuff = ""
    NewListImages = []
    ListImages = retrieveAPI()
    for link in ListImages:
        if "pics/reg/otj/" in link:
            NewListImages.append(link)

    for img in NewListImages:
        TextboxStuff += f"{img}\n"

    return TextboxStuff



def SetUpGUI():
    # All the stuff inside your window.
    imagelisttext = ""
    layout = [[sg.Text('Retrieve Cards')],
              [sg.Button('Retrieve'), sg.Button('Cancel')],
              [sg.Multiline(imagelisttext, key='-imagetext-', size=(None, 4))]]

    # Create the Window
    window = sg.Window('MTG Card Scraper', layout, size=(400, 250))

    # Event Loop to process "events" and get the "values" of the inputs
    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Cancel':  # if user closes window or clicks cancel
            break
        if event == 'Retrieve':
            def SetImagesList(window, text, imagelisttext, text_colour='black'):
                imagelisttext += text
                window['-imagetext-'].update(imagelisttext)
                window.refresh()
                return imagelisttext
            SetImagesList(window, filterCards(), imagelisttext)
            # window['-imagetext-'].update(imagelisttext)

    window.close()
