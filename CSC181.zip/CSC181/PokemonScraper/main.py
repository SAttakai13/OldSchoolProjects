import GUI as g


if __name__ == '__main__':
    g.SetUpGUI()
