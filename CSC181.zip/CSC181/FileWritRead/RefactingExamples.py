events = [
    {'A', 1000},
    {'B', 2000},
    {'C', 3000},
    {'D', 4000}
]

def AskQuestion(event):
    print(f"What is {event[0]}")
    answer = input()
    print(answer)