import tkinter as tk
import json
import PersonClass as pc
global p
global FirstName
global LastName
global PhoneNumber
global search
global labelPeopleFound


p = pc.Person()
def SetUpGUI():

    form = tk.Tk()
    form.title("Company Record Keeper")
    form.geometry("500x600")


    pc._filename = "PeopleList.json"

    labelFirstName = tk.Label(form, text="First Name:")
    labelFirstName.grid(column=0, row=0)
    personFirstNametxt = tk.Text(form, height=1, width=20)
    personFirstNametxt.grid(column=0, row=1)

    labelLastName = tk.Label(form, text="Last Name:")
    labelLastName.grid(column=0, row=4)
    personLastNametxt = tk.Text(form, height=1, width=20)
    personLastNametxt.grid(column=0, row=5)

    labelPhoneNumber = tk.Label(form, text="Phone Number:")
    labelPhoneNumber.grid(column=0, row=7)
    personPhoneNumbertxt = tk.Text(form, height=1, width=20)
    personPhoneNumbertxt.grid(column=0, row=8)

    labelNameSearch = tk.Label(form, text="Search:")
    labelNameSearch.grid(column=0, row=11)
    labelNameSearchTxt = tk.Text(form, height=1, width=20)
    labelNameSearchTxt.grid(column=0, row=12)

    labelPeopleFound = tk.Label(form, height=10, width=20)
    labelPeopleFound.grid(column=1, row=17)


    def additemtodictionary():
        firstName = personFirstNametxt.get(1.0, "end-1c")
        lastName = personLastNametxt.get(1.0, "end-1c")
        phoneNumber = personPhoneNumbertxt.get(1.0, "end-1c")
        p._addperson(firstName, lastName, phoneNumber)

    def Delete():
        search = labelNameSearchTxt.get(1.0, "end-1c")
        p._deleteperson(search)
        labelPeopleFound.config(text=f"{search} was deleted")

    def Find():
        search = labelNameSearchTxt.get(1.0, "end-1c")
        labelPeopleFound.config(text=f"{p._find(search)}")

    def AllPeopleInRecord():
        labelPeopleFound.config(text=f"{pc.list()}")

    btnClick = tk.Button(form, text='Add Person', command=additemtodictionary)
    btnClick.grid(column=1, row=0)

    btnClick = tk.Button(form, text='Delete Person', command=Delete)
    btnClick.grid(column=1, row=14)
    btnClick = tk.Button(form, text='Find Person', command=Find)
    btnClick.grid(column=2, row=14)

    btnClick = tk.Button(form, text='List All People', command=AllPeopleInRecord)
    btnClick.grid(column=0, row=16)

    form.mainloop()




