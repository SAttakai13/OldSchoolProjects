import json
from os import path
import mysql.connector as sqlconn

global _filename
global _dictload
global _localhost
global _username
global _password
global _database
global db



#
# def InputLengthCheck(inputarray, length):
#     if len(inputarray) == length:
#         return True
#     else:
#         return False

class Person:
    _filename = ""
    _dictload = []
    _localhost = ""
    _username = ""
    _password = ""
    _database = ""


    def __init__(self, fname="", lname="", pnumber=""):
        self.fname = fname
        self.lname = lname
        self.pnumber = pnumber

    def _CreateDatabaseIfNotExists(self): # exists
        db = sqlconn.connect(
            host=_localhost,
            user=_username,
            password=_password
        )
        try:
            mycursor = db.cursor()
            query = '''CREATE DATABASE IF NOT EXISTS peoplecompany'''
            mycursor.execute(query)
            print("Database exists")
        except sqlconn.Error:
            print(Exception)

    def _CreateTableIfNotExists(self):
        _database = "peoplecompany"
        db = sqlconn.connect(
            host=_localhost,
            user=_username,
            password=_password,
            database=_database
        )
        try:
            self._database = "peoplecompany"
            mycursor = db.cursor()
            query = '''CREATE TABLE IF NOT EXISTS PeopleList
                        (id int primary key AUTO_INCREMENT, FirstName VARCHAR(100), LastName VARCHAR(100), PhoneNumber VARCHAR(100))'''
            mycursor.execute(query)
            print("Table created")
        except sqlconn.Error:
            print(Exception)

    def _list(per):
        stringresp = ""
        _database = "peoplecompany"
        global pers
        db = sqlconn.connect(
            host=_localhost,
            user=_username,
            password=_password,
            database=_database
        )
        try:
            pers = ()
            mycursor = db.cursor()
            query = f'''SELECT * FROM peoplelist'''
            mycursor.execute(query)
            results = mycursor.fetchall()
            for person in results:
                if len(results) != 0:
                    stringresp += f"{person[1]} - {person[2]} - {person[3]}\n"
                else:
                    return f"List is empty"
            return stringresp
        except sqlconn.Error:
            print(Exception)

    def _find(per, name):
        _database = "peoplecompany"

        global pers
        db = sqlconn.connect(
            host=_localhost,
            user=_username,
            password=_password,
            database=_database
        )
        try:
            pers = ()
            mycursor = db.cursor()
            query = f'''SELECT * FROM peoplelist WHERE FirstName ='{name}' OR LastName='{name}';'''
            mycursor.execute(query)
            results = mycursor.fetchall()
            if len(results) != 0:
                pers = results[0]
                return f"{pers[1]} - {pers[2]} - {pers[3]}"
            else:
                return f"{name} not found"
        except sqlconn.Error:
            print(Exception)

        return f"{name} not found"

    def _addperson(per,  fname, lname, pnumber):
        _database = "peoplecompany"
        db = sqlconn.connect(
            host=_localhost,
            user=_username,
            password=_password,
            database=_database
        )
        try:
            mycursor = db.cursor()
            query = f'''INSERT INTO peoplelist
                        (FirstName, LastName, PhoneNumber) VALUES ('{fname}', '{lname}', '{pnumber}')'''
            mycursor.execute(query)
            db.commit()
            print("Person created")
        except sqlconn.Error:
            print(Exception)

    def _deleteperson(per, name):
        _database = "peoplecompany"
        global pers
        db = sqlconn.connect(
            host=_localhost,
            user=_username,
            password=_password,
            database=_database
        )
        try:
            pers = ()
            mycursor = db.cursor()
            query = f'''DELETE FROM peoplelist WHERE FirstName ='{name}' OR LastName='{name}';'''
            mycursor.execute(query)
            db.commit()
        except sqlconn.Error:
            print(Exception)




