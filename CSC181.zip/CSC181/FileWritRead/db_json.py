import json

def additemtodictionary(dictionary, key, value): #rename to add to a dictionary for people
    dictionary[key] = value

d = {}
additemtodictionary(d, "name","jake")


def writetojsonfile(filename, dictionary): #this can be the add to the file
    with open(filename, 'w') as f:
        f.write(json.dumps(dictionary, indent=4))

def readfromfile(filename):
    with open(filename, 'r') as f:
        input = f.read()
        dictionary = json.loads(input)
        return dictionary

jsonfiledictionary = readfromfile('db.json')

print(jsonfiledictionary)
jsonfiledictionary["name"] = "Tom"
writetojsonfile()

print('json');
###
# {
#     "name": "Robin"
# }
###

dictionary = {}
dictionary["name"] = "Shelly"

print(dictionary)
json_dictionary = json.dumps(dictionary)
print(json_dictionary)

with open('db.json', 'w') as f:
    f.write(json.dumps(dictionary, indent=4))

with open('db.json', 'r') as f:
    input = f.read()
    print(input)

    json_dictionary = json.loads(input)
    print(json_dictionary["name"])

db = []

db.append({"name":"sheri0", "eye_color": "brown"})
db.append({"name":"sheri1", "eye_color": "blue"})
db.append({"name":"sheri2", "eye_color": "black"})
db.append({"name":"sheri3", "eye_color": "yellow"})

print(json.dumps(db))

command = input()
print(command)

match command:
    case 'list':
        print("printing all records")
    case 'del':
        print("deleting record")

if command == 'list':
    print('printing')
elif command == 'del':
    print('delete')