import tkinter as tk

x = 0
def btnClicked():
    global x
    print('Button was clicked')
    labelInfo.configure(text=f'Button Clicked:{x}')
    x += 1

form = tk.Tk()
form.title('TKinter')
form.geometry('500x600')


labelMainTitle = tk.Label(form, text='This is a label')
# labelMainTitle.pack()
labelMainTitle.grid(column=1, row=0)
#labelMainTitle.place(relx=0.5, rely=0.75)


labelInfo = tk.Label(form, text='This is a information')
# labelInfo.pack()
labelInfo.grid(column=0, row=1)
#labelInfo.place(relx=0.5, rely=0.75)

btnClick = tk.Button(form, text='Click me', command=btnClicked)
# btnClick.pack()
btnClick.grid(column=1, row=1)
#btnClick.place(relx=0.5, rely=0.75)

txtEntry = tk.Entry(form)
#txtEntry.pack()
btnClick.grid(column=1, row=2)
#txtEntry.place(relx=0.5, rely=0.75)

form.mainloop()