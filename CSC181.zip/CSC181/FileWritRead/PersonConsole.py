import PersonClass as pc
import sys


def CommandNDemandData():
    p = pc.Person()
    # if statements because you can search through the substrings for commands
    # you can break up the command into arrays and then toss the indexes to fill fields
    # to check this you can check against certain commands that if they have all of their fields filled
    #           or throw an error that says hey recheck your field input.
    pc._filename = "PeopleList.json"
    while True:
        print(
            "Input person to logs, to add: (add [fname] [lname] [phone]) \n to list all records: (list) \nto delete a person: (delete [name]) \nto find a person: (find [name]) \nto quit: (quit)")
        command = input()
        userinput = command.lower()
        while True:
            peopleArray = command.split(" ")
            if "add" in userinput: #works
                try:
                    if pc.InputLengthCheck(peopleArray, 4):
                        p._addperson(peopleArray[1], peopleArray[2], peopleArray[3])
                        print(f"{peopleArray[1]} {peopleArray[2]} was added")
                        break
                    else:
                        raise Exception()
                except:
                    print("Input invalid.")
                    break #something has gone wrong here
            elif "list" in userinput: # works
                try:
                    if pc.InputLengthCheck(peopleArray, 1):
                        print(pc.list())
                        break
                    else:
                        raise Exception()
                except:
                    print("Input invalid.")
                    break # something has gone wrong here
            elif "find" in userinput:
                try:
                    if pc.InputLengthCheck(peopleArray, 2):
                        print(p._find(peopleArray[1]))
                        break
                    else:
                        raise Exception()
                except:
                    print("Input Invalid")
                    break # something has gone wrong here
            elif "delete" in userinput:
                try:
                    if pc.InputLengthCheck(peopleArray, 2):
                        p._deleteperson(peopleArray[1])
                        print(f"{peopleArray[1]} removed")
                        break
                        #delete method
                    else:
                        raise Exception()
                except:
                    print("Input Invalid")
                    break #something has gone wrong here
            elif "quit" in userinput: # works
                if pc.InputLengthCheck(peopleArray, 1):
                    sys.exit(0)
            else:
                continue