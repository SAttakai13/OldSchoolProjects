import json
import re
import sys
from os import path

dictionaryload = []
def AddPerson(filename, diction):
    initiallist = []
    # Reference adding items to dictionary
    # Write list to json file
    if path.exists(filename):
        initiallist = List(filename)
        initiallist.append(diction)
        with open(filename, 'w') as f:
            f.write(json.dumps(initiallist, indent=4))
    else:
        initiallist.append(diction)
        with open(filename, 'w') as f:
            f.write(json.dumps(initiallist, indent=4))

def List(filename): #converted to a list
    with open(filename) as f:
        inputdiction = f.read()
        dictionaryload = json.loads(inputdiction)
        return dictionaryload

#Delete still needs to be done
def DeletePerson(name, fileName):
    personlist = []
    Person = FindPerson(name, fileName)
    personlist = List(fileName)
    personlist.remove(Person)
    with open(fileName, 'w') as f:
        f.write(json.dumps(personlist, indent=4))

#something wrong here
def FindPerson(name, fileName):
    dictionaryFind = List(fileName)

    for peopleindex in dictionaryFind:
        for person in peopleindex:
            if peopleindex[person] == name:
                return peopleindex
    return f"{name} not found"

def additemtodictionary(fname, lname, phoneNumber):  # rename to add to a dictionary for people
    dictionary = {}
    dictionary["First_Name"] = fname
    dictionary["Last_Name"] = lname
    dictionary["Phone_Number"] = phoneNumber
    return dictionary

def InputLengthCheck(inputarray, length):
    if len(inputarray) == length:
        return True
    else:
        return False

def CommandNDemandData():

    # if statements because you can search through the substrings for commands
    # you can break up the command into arrays and then toss the indexes to fill fields
    # to check this you can check against certain commands that if they have all of their fields filled
    #           or throw an error that says hey recheck your field input.
    while True:
        print(
            "Input person to logs, to add: (add [fname] [lname] [phone]) \n to list all records: (list) \nto delete a person: (delete [name]) \nto find a person: (find [name]) \nto quit: (quit)")
        command = input()
        userinput = command.lower()
        while True:
            peopleArray = command.split(" ")
            if "add" in userinput: #works
                try:
                    if InputLengthCheck(peopleArray, 4):
                        NewPersonDictionary = additemtodictionary(peopleArray[1], peopleArray[2], peopleArray[3])
                        AddPerson("PeopleList.json", NewPersonDictionary)
                        print(f"{peopleArray[1]} {peopleArray[2]} was added")
                        break
                    else:
                        raise Exception()
                except:
                    print("Input invalid.")
                    break
                break #something has gone wrong here
            elif "list" in userinput: # works
                try:
                    if InputLengthCheck(peopleArray, 1):
                        print(List("PeopleList.json"))
                        break
                    else:
                        raise Exception()
                except:
                    print("Input invalid.")
                    break
                break # something has gone wrong here
            elif "find" in userinput:
                try:
                    if InputLengthCheck(peopleArray, 2):
                        print(FindPerson(peopleArray[1],"PeopleList.Json"))
                        break
                    else:
                        raise Exception()
                except:
                    print("Input Invalid")
                    break
                break # something has gone wrong here
            elif "delete" in userinput:
                try:
                    if InputLengthCheck(peopleArray, 2):
                        DeletePerson(peopleArray[1], "PeopleList.json")
                        print(f"{peopleArray[1]} removed")
                        break
                        #delete method
                    else:
                        raise Exception()
                except:
                    print("Input Invalid")
                    break
                break #something has gone wrong here
            elif "quit" in userinput: # works
                if InputLengthCheck(peopleArray, 1):
                    sys.exit(0)
            else:
                continue
