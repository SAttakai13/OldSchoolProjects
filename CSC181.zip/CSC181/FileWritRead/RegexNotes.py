import re
phone = "123-456-7890"
phone = "abc"
match = re.search(r"(\d{3})-(\d{3})-(\d{4})", phone)

