import datetime

def print_hi(name):
    print(f'Hello world, {name}')
    print('it is',  datetime.datetime.now())

def SwitchExample(num):
    match num:
        case 1:
            print('equals 1')
        case 2:
            print('equals 2')

def ifelseState(num):
    if num == 1:
        print('11111111111111')
    else:
        print('not 1')

def forloopexample(num):
    for num in range(0, 10):
        print(num)

def arrayindexexample():
    classes = ['csc181', 'csc270']

    for c in classes:
        print(c)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('my name is Sheridan')
