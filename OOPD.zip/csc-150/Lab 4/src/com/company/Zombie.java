package com.company;

abstract class Zombie {
    //Properties
    protected String name;
    protected int BaseHP;
    protected int Arms;
    protected int legs;
    protected int Speed;


    //Constructors
    public Zombie(){
        //Set defaults or random values
        //or
        Base("Walker", 15, 2, 1, 6, 14);
    }
    public Zombie(String name, int BaseHP, int legs, int arms, int speed, int attack){
        // Call getter/setters
        // Call GenCon
        Base(name, BaseHP, legs, arms, speed, attack);
    }
    public void Base(String name, int BaseHP, int legs, int arms, int speed, int attack){
        this.setName(name);
        this.setBaseHP(BaseHP);
        this.setLegs(legs);
        this.setArms(arms);
        this.setSpeed(speed);
        this.Attack(attack);
    }

    //Methods and abstract methods
    public int Roll(int numDice, int range){
        Dice newDie = new Dice();
        return newDie.MultiRoll(numDice, range);
    }
    abstract int Attack(int UserIntNum);
    abstract void setBaseHP(int baseHP);
    abstract void setSpeed(int speed);
    abstract void setName(String name);

    //Getters and Setters
    public int getSpeed() {return Speed;}

    public int getArms() {return Arms;}
    public void setArms(int arms) {Arms = arms;}

    public int getLegs() {return legs;}
    public void setLegs(int legs) {this.legs = legs;}


    //toString
    @Override
    public String toString() {
        return "Zombie:" +
                "\nName = " + name +
                "\nBaseHP =" + BaseHP +
                "\nArms = " + Arms +
                "\nlegs = " + legs +
                "\nspeed = " + Speed;
    }
}
