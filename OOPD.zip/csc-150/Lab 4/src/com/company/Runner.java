package com.company;

public class Runner extends Zombie {
    //Properties
    protected int climbspeed;

    //Constructors and Overflow Constructors
    public Runner(){}
    public Runner(String name, int BaseHP, int legs, int arms, int speed){
        this.setName(name);
        this.setBaseHP(BaseHP);
        super.setLegs(legs);
        super.setArms(arms);
        this.setSpeed(speed);
        setClimbspeed(climbspeed());
    }

    //Getters and Setters
    public int getClimbspeed() {return climbspeed;}
    public void setClimbspeed(int climbspeed) {this.climbspeed = climbspeed;}

    //Method
    public int climbspeed(){return getSpeed()/3;}

    //Overridden Methods from the abstract parent class Zombie
    @Override
    int Attack(int UserIntNum) {
        Dice DamDie = new Dice();
        if (UserIntNum < 5){
            return 0;
        } else if((UserIntNum >= 5) && (UserIntNum <= 18)){
            return DamDie.MultiRoll(2, 8);
        } else if(UserIntNum >= 19){
            return DamDie.MultiRoll(2,8) * 2;
        }
        return 0;
    }

    @Override
    public void setBaseHP(int baseHP) {
        if ((baseHP >= 10) && (baseHP <= 22)) {
            this.BaseHP = baseHP;
        } else {
            BaseHP = 16;
        }
    }

    @Override
    public void setName(String name) {this.name = name;}

    @Override
    public void setSpeed(int speed) {
        if ((speed >= 15) && (speed <= 25)) {
            this.Speed = speed;
        } else {
            Speed = 20;
        }
    }

    //toString
    @Override
    public String toString() {
        return "Type: Runner" +
                "\nName = " + name +
                "\nBase HP = " + BaseHP +
                "\nArms = " + Arms +
                "\nlegs = " + legs +
                "\nspeed = " + Speed +
                "\nClimb speed = " + climbspeed + "\n";
    }
}
