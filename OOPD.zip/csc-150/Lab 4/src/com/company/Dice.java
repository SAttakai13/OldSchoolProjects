package com.company;

import java.util.Random;

public class Dice {
    //Random
    Random rnd = new Random();
    //Rolls one dice
    public int RollOnce(int sides){
        if (sides >= 1 && sides <= 20){
            return rnd.nextInt(sides) + 1;
        } else {
            throw new RuntimeException("Invalid input");
        }
    }
    //rolls multiple dice
    public int MultiRoll(int numDice, int sides){
        if (numDice > 0){
            int totalDieNum = 0;
            for (int i = 0; i <= numDice; i++){
                totalDieNum += RollOnce(sides);
            }
            return totalDieNum;
        } else {
            throw new RuntimeException("Invalid input");
        }

    }

}
