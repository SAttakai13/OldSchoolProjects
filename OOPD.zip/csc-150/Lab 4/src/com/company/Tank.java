package com.company;

public class Tank extends Zombie{
    //properties
    protected int DamageModifier;

    //Constructors and overloaded constructors
    public Tank(){}
    public Tank(String name, int BaseHP, int legs, int arms, int speed){
        this.setName(name);
        this.setBaseHP(BaseHP);
        super.setLegs(legs);
        super.setArms(arms);
        this.setSpeed(speed);
    }

    //getters and setters
    public int getDamageModifier() {return DamageModifier;}
    public void setDamageModifier(int damageModifier) {DamageModifier = damageModifier;}

    //Methods
    public int DamageModifier(){
        setDamageModifier(15);
        return getDamageModifier();
    }

    //Overridden Methods from the abstract parent class Zombie
    @Override
    int Attack(int UserIntNum) {
        Dice DamDie = new Dice();
        if (UserIntNum < 10){
            return 0;
        } else if((UserIntNum >= 10) && (UserIntNum <= 19)){
            return DamDie.MultiRoll(3, 6) + DamageModifier();
        } else if(UserIntNum == 20){
            return DamDie.MultiRoll(3,6) + DamageModifier() * 3;
        }
        return 0;
    }

    @Override
    public void setBaseHP(int baseHP) {
        if ((baseHP >= 45) && (baseHP <= 70)) {
            this.BaseHP = baseHP;
        } else {
            BaseHP = 57;
        }
    }

    @Override
    public void setName(String name) { this.name = name;}

    @Override
    public void setSpeed(int speed) {
        if ((speed >= 4) && (speed <= 8)) {
            this.Speed = speed;
        } else {
            Speed = 6;
        }
    }

    //toString
    @Override
    public String toString() {
        return "Type: 'Tank'" +
                "\nName = " + name +
                "\nBase HP = " + BaseHP +
                "\nArms = " + Arms +
                "\nlegs = " + legs +
                "\nspeed = " + Speed +
                "\nDamage Modifier = " + DamageModifier + "\n";
    }
}
