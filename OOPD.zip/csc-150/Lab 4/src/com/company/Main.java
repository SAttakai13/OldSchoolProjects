package com.company;

public class Main {
    public static void main(String[] args) {
	    //new instance of the factory
        ZombieFactory factory = new ZombieFactory();
        //Work area of zombie
        factory.workArea();
        System.out.print("Good-bye");
    }
}
