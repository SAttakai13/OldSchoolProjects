package com.company;
import java.util.ArrayList;
import java.util.Random;

public class ZombieFactory {
    private ArrayList<Zombie> zed = new ArrayList<>();
    MyInput get = new MyInput();

    public void workArea(){
        int UserNum = 0;
        while (UserNum != 4){
            zed.clear();
            UserNum = get.GetUserInt("Zombie: \n1. Create 1 zed\n2. Generate some zeds\n3. Generate a certain number of zeds\n4. Exit\nChoose one of the options above: ");
            switch (UserNum){
                case 1:
                    OneZed();
                    break;
                case 2:
                    rndZed();
                    break;
                case 3:
                    numZed();
                    break;
            }
            zedList();
        }
    }

    public void OneZed(){
        //Creates one zed
        int randZed = random(1, 3);
        switch (randZed){
            case 1:
                walker();
                break;
            case 2:
                runner();
                break;
            case 3:
                tank();
                break;
        }
    }

    public void rndZed(){
        //Create Random Number of zombies
        int randZed = random(1, 10);
        System.out.println(randZed + " zombie(s) have been generated.");
        for (int i = 0; i < randZed; i++ ){
            OneZed();
        }

    }

    public void numZed(){
        //Generate n number of zombies
        int numGen = get.GetUserInt("How many zombies do you want to make? ");
        for (int i = 0; i < numGen; i++){
            OneZed();
        }
    }

    //Random method
    public int random(int min, int max) {
        Random random = new Random();
        Integer randInt = random.nextInt((max - min) + 1) + min;
        return randInt;
    }


    public void walker(){
        //Creates a walker and adds to zed arraylist
        Walker walker = new Walker();
        walker.setName(get.GetUserStr("Name this zombie :D.... Hurry before it bites me ._. : "));
        walker.setBaseHP(random(15, 30));
        walker.setLegs(random(1, 2));
        walker.setArms(random(1, 2));
        walker.setSpeed(random(6, 10));
        zed.add(walker);
    }

    public void runner(){
        //Creates a runner and adds to zed arraylist
        Runner runner = new Runner();
        runner.setName(get.GetUserStr("Name this zombie :D.... Hurry before it bites me ._. : "));
        runner.setBaseHP(random(10, 22));
        runner.setLegs(random(1, 2));
        runner.setArms(random(1, 2));
        runner.setSpeed(random(15, 25));
        runner.setClimbspeed(runner.climbspeed());
        zed.add(runner);
    }
    public void tank(){
        //Creates a tank and adds to zed arraylist
        Tank tank = new Tank();
        tank.setName(get.GetUserStr("Name this zombie :D.... Hurry before it bites me ._. : "));
        tank.setBaseHP(random(45, 70));
        tank.setLegs(random(1, 2));
        tank.setArms(random(1, 2));
        tank.setSpeed(random(4, 8));
        tank.setDamageModifier(random(10,20));
        zed.add(tank);
    }
    public void zedList(){
        //prints zed list and the damage rolls
        for (int i = 0; i < zed.size(); i++){
            System.out.println(i + ". " + zed.get(i));
            int roll = zed.get(i).Roll(1, 20);
            int damage = zed.get(i).Attack(roll);
            System.out.println(zed.get(i).name + " attacked you! Ouch, you receive " + damage + " damage.\n");
        }
    }

}
