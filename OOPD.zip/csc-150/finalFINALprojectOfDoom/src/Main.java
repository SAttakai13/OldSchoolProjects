import Controller.BattlePlay;
import Controller.MainMenuSystem;
import View.Trophy;

import java.io.IOException;

public class Main {
    //Main
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        MainMenuSystem work = new MainMenuSystem();
        work.StartGame();
        System.out.println("See ya later nerd :P");
    }
}
