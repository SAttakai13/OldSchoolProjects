package Controller;

import DAL.PlayerDAL;
import Model.PlayerStats;
import View.Title;
import View.UserInput;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class MainMenuSystem {

    public static final String RED_BOLD = "\033[1;31m";    // RED
    public static final String RESET = "\033[0m";  // Text Reset

    PlayerDAL dal = new PlayerDAL();
    UserInput get = new UserInput();
    BattlePlay game = new BattlePlay();
    Random rnd = new Random();
    public ArrayList<PlayerStats> players = new ArrayList<PlayerStats>();

    //Game Start Menu
    public void StartGame() throws IOException, ClassNotFoundException{
        players = dal.load();
        int option = 0;
        while (option != 5 && option >= 0){
            Title title = new Title();
            title.title();
            switch (option = get.GetUserInt(1,5,"\n=-=----~<("+ RED_BOLD + "O" + RESET + ")>~----=-=\n"+ RED_BOLD + "1.)" + RESET + " New Player\n"+ RED_BOLD + "2.)" + RESET + " Returning Player\n"+ RED_BOLD + "3.)" + RESET + " Play as Guest\n"+ RED_BOLD + "4.)" + RESET + " Delete a player\n" + RED_BOLD + "5.)" + RESET + " Exit")) {
                case 1:
                    newPlayer();
                    break;
                case 2:
                    choosePlayer();
                    break;
                case 3:
                    guestPlay();
                    break;
                case 4:
                    deletePlayer();
                    break;
            }
        }
    }

    //Creates a New Player
    public void newPlayer(){
        try {
            players = dal.load();
        } catch (Exception e){
            get.display(e.getMessage());
            e.printStackTrace();
        }
        PlayerStats newPlayer = new PlayerStats(get.GetUserStr("Enter your name:",true), 100 + rnd.nextInt(21),20 + rnd.nextInt(11), 5 + rnd.nextInt(6));
        players.add(newPlayer);
        try {
            dal.save(players);
            get.display("Player saved :)");
        } catch (Exception e){
            get.display("Didn't save player :(");
            e.printStackTrace();
        }
    }

    //Choosing players
    public void choosePlayer(){
        try {
            players = dal.load();
        }
        catch (Exception e){
            get.display("Can't find any players.");
            e.printStackTrace();
        }
        if (players.size() != 0) {
            for (int i = 0; i < players.size(); i++) {
                get.display(RED_BOLD+ i + ".) " + RESET + players.get(i).getPlayerName());
            }
            int choice = get.GetUserInt(0, players.size()-1, "Choose a character.");
            PlayerStats player = players.get(choice);
            try {
                game.StartBattle(player);
            } catch (Exception ex){
                ex.printStackTrace();
                ex.getMessage();
            }
        } else {
            get.display("No players stats at all :/");
        }
    }

    //New Guest
    public void guestPlay(){
        //creates new player but does not save them to the player array.
        PlayerStats newPlayer = new PlayerStats(get.GetUserStr("Enter your name:",true), 100 + rnd.nextInt(21),20 + rnd.nextInt(11), 5 + rnd.nextInt(6));
        try {
            game.StartBattle(newPlayer);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //Delete Player
    public void deletePlayer(){
        try {
            players = dal.load();
        }
        catch (Exception e){
            get.display("Can't find any players.");
            e.printStackTrace();
        }
        if (players.size() != 0) {
            for (int i = 0; i < players.size(); i++) {
                get.display(RED_BOLD + i + ".) " + RESET + players.get(i).getPlayerName());
            }
            try{
                int choice = get.GetUserInt(0, players.size()-1, "Choose a character.");
                players.remove(choice);
                dal.save(players);
                get.display("Player deleted.");
            } catch ( IOException e){
                e.printStackTrace();
                get.display("Error deleting player :/");
            }
        } else {
            get.display("No players to delete :/");
        }
    }
}
