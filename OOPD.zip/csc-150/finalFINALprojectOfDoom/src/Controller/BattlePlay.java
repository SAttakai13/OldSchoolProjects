package Controller;

import Model.Monsters.*;
import Model.PlayerStats;
import View.HealthBar;
import View.Trophy;
import View.UserInput;

import java.io.IOException;

public class BattlePlay {
    //New Instantations
    UserInput get = new UserInput();
    BattleSystem battle = new BattleSystem();
    Trophy trophy = new Trophy();
    boolean alive;

    //Battle simulations
    public void StartBattle(PlayerStats player) throws IOException, ClassNotFoundException {
        //the alive boolean is used to see if the player is alive to determine if the next battle will be played.
        alive = levelOne(player);
        if (alive) {
            alive = levelTwo(player);
        }
        if (alive) {
            alive = levelThree(player);
        }
        if (alive){
            alive = levelFour(player);
        }
        if (alive){
            alive = levelFive(player);
        }
        if (alive){
            trophy.WinnersTrophy();
        }
        //if the player dies the game skips all the battles and displays that they lost.
        if (!alive){
            gameOver();
        }
    }

    //starts level one with player and a new creature Poppy Pop'n'Lock
    private boolean levelOne(PlayerStats player) throws IOException, ClassNotFoundException {
        PoppyPopnLock poppyPopnLock = new PoppyPopnLock();
        vsText(poppyPopnLock);
        return battle.start(poppyPopnLock, player);
    }

    //Level two creature Hydro-dog
    private boolean levelTwo(PlayerStats player) throws IOException, ClassNotFoundException {
        HydroDog dawg = new HydroDog();
        vsText(dawg);
        return battle.start(dawg, player);
    }

    //Level three Wispy Willy
    private boolean levelThree(PlayerStats player) throws IOException, ClassNotFoundException {
        WispyWilly wispyWilly = new WispyWilly();
        vsText(wispyWilly);
        return battle.start(wispyWilly, player);
    }

    //Level four Mighty Bright Sprite
    private boolean levelFour(PlayerStats player) throws IOException, ClassNotFoundException {
        MightyBrightSprite mightyBrightSprite = new MightyBrightSprite();
        vsText(mightyBrightSprite);
        return battle.start(mightyBrightSprite, player);
    }

    //Level five Midnight Bat Cat
    private boolean levelFive(PlayerStats player) throws IOException, ClassNotFoundException {
        MidnightBatCat midnightBatCat = new MidnightBatCat();
        vsText(midnightBatCat);
        return battle.start(midnightBatCat, player);
    }

    //Game-over if the player is ded
    private void gameOver() throws IOException{
        get.display("\n\n\n\n\n"+ RED_BOLD + "You died!" + RESET + "\n\n\n\n");
        get.next();
    }
    //shows who you are fighting next
    public static final String RED_BOLD = "\033[1;31m";    // RED
    public static final String RESET = "\033[0m";  // Text Reset
    private void vsText(Creature creature) throws IOException{
        get.display("\n\n\n\n=-=----~<("+ RED_BOLD + "0" + RESET + ")>~----=-=\n"+ RED_BOLD + "\t\tFIGHT" + RESET + "\n=-=----~<("+ RED_BOLD + "0" + RESET + ")>~----=-=\n\n"+ creature.getName() + "\n\n\n\n");
        get.next();
    }
}
