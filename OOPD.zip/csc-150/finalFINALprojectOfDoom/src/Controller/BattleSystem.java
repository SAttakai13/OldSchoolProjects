package Controller;

import DAL.PlayerDAL;
import Model.Monsters.Creature;
import Model.PlayerStats;
import View.HealthBar;
import View.UserInput;

import java.io.IOException;
import java.util.Random;

public class BattleSystem {
    //Colors
    public static final String RED_BOLD = "\033[1;31m";    // RED
    public static final String RESET = "\033[0m";  // Text Reset

    //Functions
    UserInput get = new UserInput();
    HealthBar bar = new HealthBar();
    Random rnd = new Random();
    Creature creature;
    PlayerStats player;
    int roundDef;
    int playerStatus = 0;
    int creatureStatus = 0; //0 = normal; 1 = burned; 2 = poisoned

    //Methods
    public boolean start(Creature creature, PlayerStats player) throws IOException, ClassNotFoundException{
        this.creature = creature;
        this.player = player;
        while ((creature.getHealth()>0) && (player.getPlayerHP()>0)){
            battle();
        }
        //if the player died then it skips the rest of the battles, and they lose.
        if(player.getPlayerHP()<=0){
            return false;
        }
        playerStatus = 0;
        creatureStatus = 0;
        return true;
    }
    //Battle frame
    public void battle() throws IOException, ClassNotFoundException{
        menu();
        //creature now attacks! (if it isn't dead)
        if (creature.getHealth() > 0) {
            int dmg = creature.getAttack() - this.roundDef - player.getPlayerDef() + rnd.nextInt(3);
            if(creatureStatus == 3){
                dmg -= (5+rnd.nextInt(5));
            }
            if (dmg < 0){
                dmg = 1;
            }
            get.display("The creature attacked you for " + dmg + " damage!");
            player.setPlayerHP(player.getPlayerHP() - dmg);
        }
        statusConditions();

        if (player.getManaPoints() < 100) {
            player.setManaPoints(player.getManaPoints() + 5);
        }
        if (player.getManaPoints() > 100){
            player.setManaPoints(100);
        }
    }
    //Creature health when player choose attack
    public void attack(){
        creature.setHealth(creature.getHealth()-(player.getPlayerAtk()-creature.getDefence()+rnd.nextInt(5)));
    }
    //Defence for the player
    public void defense() {
        this.roundDef = 10;
    }
    //Magic menu with their own special attacks and health recovery
    //Depends on the type of creature your fighting is how effective the magic is
    public boolean magic() {
        float[] typing = creature.getType();
        boolean exit = false;
        switch(get.GetUserInt(1,7,RED_BOLD + "1.)" + RESET + " Fireball\n" + RED_BOLD + "2.)" + RESET + " Death Bubble\n" + RED_BOLD + "3.)" + RESET + " Poison Spore\n" + RED_BOLD + "4.)" + RESET + " Shadow Orb\n" + RED_BOLD + "5.)" + RESET + " Light Beam\n"+RED_BOLD+"6.)" + RESET + " Healing Prayer\n" + RED_BOLD + "7.)" + RESET + " Return")){
            case 1://fireball
                if(player.getManaPoints() >= 10){
                    creature.setHealth(Math.round(creature.getHealth()-(typing[0]*player.getPlayerAtk())-creature.getDefence()));
                    player.setManaPoints(player.getManaPoints()-10);
                    creatureStatus = 1;
                }
                else{
                    get.display("You don't have enough mana!");
                    exit = true;
                }
                break;
            case 2://death bubble
                if (player.getManaPoints() >= 10){
                    creature.setHealth(Math.round(creature.getHealth()-(typing[1]*player.getPlayerAtk())-creature.getDefence()));
                    player.setManaPoints(player.getManaPoints()-10);
                    creatureStatus = 3;
                }
                else {
                    get.display("You don't have enough mana!");
                    exit = true;
                }
                break;
            case 3://Poison Spore
                if (player.getManaPoints() >= 10) {
                    creature.setHealth(Math.round(creature.getHealth() - (typing[2] * player.getPlayerAtk()) - creature.getDefence()));
                    player.setManaPoints(player.getManaPoints()-10);
                    creatureStatus = 2;
                } else {
                    get.display("You don't have enough mana!");
                    exit = true;
                }
                break;
            case 4://shadow orb
                if (player.getManaPoints() >= 10) {
                    creature.setHealth(20 + Math.round(creature.getHealth() - (typing[3] * player.getPlayerAtk()) - creature.getDefence()));
                    player.setManaPoints(player.getManaPoints()-20);
                    break;
                } else {
                    get.display("You don't have enough mana!");
                    exit = true;
                }
            case 5://Light Beam
                if (player.getManaPoints() >= 10) {
                    creature.setHealth(20 + Math.round(creature.getHealth() - (typing[4] * player.getPlayerAtk()) - creature.getDefence()));
                    player.setManaPoints(player.getManaPoints()-20);
                    break;
                } else {
                    get.display("You don't have enough mana!");
                    exit = true;
                }
            case 6://healing prayer
                if(player.getManaPoints() >= 30){
                    player.setPlayerHP(player.getPlayerHP() + player.getPlayerMaxHP()/2);
                    player.setManaPoints(player.getManaPoints()-30);
                } else {
                    get.display("You don't have enough mana!");
                    exit = true;
                }
                if (player.getPlayerHP() >= player.getPlayerMaxHP()) {
                    player.setPlayerHP(player.getPlayerMaxHP());
                }
                break;
            case 7://Return
                exit = true;
        }
        return exit;
    }
    private void menu(){
        this.roundDef = 0;
        get.display( RED_BOLD + "O" + RESET + ">~~~~--=--=--~~~~<(" + RED_BOLD + "0" + RESET + ")>~~~~--=--=--~~~~<" + RED_BOLD + "O" + RESET);
        get.display(creature.getName());
        bar.hpBar(creature.getMaxHP(), creature.getHealth(),creatureStatus,0);
        get.display("\n" + creature.getHealth() + " HP \n\n\n\n\t\t\t" + player.getPlayerName());
        bar.hpBar(player.getPlayerMaxHP(), player.getPlayerHP(),playerStatus,1);
        get.display("\n\t\t\t\t\t\t\t\t\t" + player.getPlayerHP() + " HP" + "\n\t\t\t\t\t\t\t\t\t" + player.getManaPoints() + " MP");
        get.display( RED_BOLD + "O" + RESET + ">~~~~--=--=--~~~~<(" + RED_BOLD + "0" + RESET + ")>~~~~--=--=--~~~~<" + RED_BOLD + "O" + RESET);
        boolean loop = true;
        while (loop){
            switch(get.GetUserInt(1,3,RED_BOLD +"1.)" + RESET + " Attack\n" + RED_BOLD + "2.)" + RESET + " Defend\n" + RED_BOLD + "3.)" + RESET + " Magic")){
                case 1: attack(); loop = false; break;
                case 2: defense(); loop = false; break;
                case 3: loop = magic(); break;
            }
        }
    }
    private void statusConditions(){
        //handles burn condition for player
        float[] creatureType = creature.getType();

        if (creatureType[5] == 0 && roundDef == 0) {
            player.setPlayerHP(player.getPlayerHP() - (2 + rnd.nextInt(5)));
            get.display("You were burned!");
            playerStatus = 1;
        }

        //status condition for creatures
        if (creatureStatus > 0) {
            creature.setHealth(creature.getHealth() - (2 + rnd.nextInt(5)));
        }
    }
}
