package DAL;

import Model.PlayerStats;

import java.io.*;
import java.util.ArrayList;

public class PlayerDAL {
    //File
    String fileName = "playerList.xjson";
    //saves arraylist to the xjson file.
    public void save(ArrayList<PlayerStats> playerStats) throws IOException {
        FileOutputStream fileStream = new FileOutputStream(fileName);
        ObjectOutputStream outStream = new ObjectOutputStream(fileStream);
        outStream.writeObject(playerStats);
        outStream.close();
    }
    //returns arraylist of entries from the xjson file.
    public ArrayList<PlayerStats> load() throws IOException, ClassNotFoundException {
        ArrayList<PlayerStats> tempPS;
        FileInputStream fileStream = new FileInputStream(fileName);
        ObjectInputStream inStream = new ObjectInputStream(fileStream);

        tempPS = (ArrayList<PlayerStats>) inStream.readObject();
        inStream.close();

        return tempPS;
    }
}