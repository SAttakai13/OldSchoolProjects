package View;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Objects;

public class UserInput {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));
    //gets user input and sets it to a string
    //does not save anything for a string- just used, so you have to hit enter to continue
    public void next() throws IOException{
        display("Press enter to continue...");
        String next = bread.readLine();
    }
    public String GetUserStr(String prompt, boolean check) {
        String sReturn = "";
        boolean bLoop = true;
        while (bLoop == true){
            if (prompt != null)
                System.out.println(prompt);
            try {
                sReturn = bread.readLine();
                bLoop = (check && (sReturn.length() < 1));
            } catch (Exception ex) {
                sReturn = ex.getMessage();
                System.out.println("Error - " + ex.getMessage());
            }
        }
        return sReturn;
    }
    //requires user to input a number between the provided min and max
    public int GetUserInt(int min, int max, String prompt){
        System.out.println(prompt);
        int input = min - 1;
        while((input < min) || (input > max)){
            try {
                input = Integer.parseInt(bread.readLine());
            } catch (Exception ioe){
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            }

            if (input < min || input > max) {
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            }
        }
        return input;
    }
    //Display
    public String display(String prompt){
        System.out.println(prompt);
        return prompt;
    }
}