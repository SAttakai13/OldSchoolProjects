package View;

public class Trophy {
    //Well it's a trophy for the winner
    public static final String RESET = "\033[0m";  // Text Reset
    public static final String YELLOW_BOLD_BRIGHT = "\033[1;93m";// YELLOW
    public void WinnersTrophy(){
        System.out.println(YELLOW_BOLD_BRIGHT +
                "\t    |||||||||||||||||||||||    \n"+
                "\t     |||||||||||||||||||||     \n"+
                "\t |||||||||||||   ||||||||||||| \n"+
                "\t||  |||||||  ||  ||||||||||  ||\n"+
                "\t||  |||||||||||  ||||||||||  ||\n"+
                "\t||  |||||||||||  ||||||||||  ||\n"+
                "\t||  |||||||||||  ||||||||||  ||\n"+
                "\t  || |||||||       ||||||| ||  \n"+
                "\t    |||||||||||||||||||||||    \n"+
                "\t       ||||||||||||||||||      \n"+
                "\t         ||||||||||||||        \n"+
                "\t            |||||||            \n"+
                "\t            |||||||            \n"+
                "\t         |||||||||||||         \n"+
                "\t       |||||||||||||||||       \n"+
                "\t     |||||||||||||||||||||     \n" + RESET);
    }
}
