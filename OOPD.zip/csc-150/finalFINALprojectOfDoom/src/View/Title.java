package View;

public class Title {
    public static final String RED_BOLD_BRIGHT = "\033[1;91m";   // RED
    public static final String RESET = "\033[0m";  // Text Reset
    public void title(){
        System.out.println( RED_BOLD_BRIGHT + "  __  __             _             __  __   _   ___ _  _   " + RESET);
        System.out.println( RED_BOLD_BRIGHT + " |  \\/  |___ _ _  __| |_ ___ _ _  |  \\/  | /_\\ / __| || |  " + RESET);
        System.out.println( RED_BOLD_BRIGHT + " | |\\/| / _ \\ ' \\(_-<  _/ -_) '_| | |\\/| |/ _ \\\\__ \\ __ |  " + RESET);
        System.out.println( RED_BOLD_BRIGHT + " |_|  |_\\___/_||_/__/\\__\\___|_|   |_|  |_/_/ \\_\\___/_||_|  "+RESET);
        System.out.println( RED_BOLD_BRIGHT + "                                                           "+RESET);
    }
}
