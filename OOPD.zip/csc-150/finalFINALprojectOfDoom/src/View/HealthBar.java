package View;

public class HealthBar {

    public static final String RESET = "\033[0m";  // Text Reset
    public static final String RED_BACKGROUND = "\033[41m";    // RED
    public static final String YELLOW_BACKGROUND_BRIGHT = "\033[0;103m";// BRIGHT YELLOW
    public static final String BLACK_BACKGROUND_BRIGHT = "\033[0;100m";// BLACK
    public static final String PURPLE_BACKGROUND = "\033[45m"; // PURPLE
    public static final String BLUE_BACKGROUND = "\033[44m";   // BLUE

    public void hpBar(int maxHP, int HP, int status, int id){
        double dMaxHP = maxHP;
        double DHP = HP;
        double percent = DHP / dMaxHP * 30;
        double dif = 30-percent;
        if (id == 1){
            System.out.print("\t\t\t");
        }
        if(status == 0){
            for (int j = 0; j < percent; j++) {
                System.out.print(YELLOW_BACKGROUND_BRIGHT + " " + RESET);
            }
        }
        if(status == 1){
            for (int j = 0; j < percent; j++) {
                System.out.print(RED_BACKGROUND + " " + RESET);
            }
        }
        if(status == 2){
            for (int j = 0; j < percent; j++) {
                System.out.print(PURPLE_BACKGROUND + " " + RESET);
            }
        }
        if(status == 3){
            for (int j = 0; j < percent; j++) {
                System.out.print(BLUE_BACKGROUND + " " + RESET);
            }
        }
        for(int i = 0; i < dif; i++){
            System.out.print(BLACK_BACKGROUND_BRIGHT + " " + RESET);
        }
    }
}
