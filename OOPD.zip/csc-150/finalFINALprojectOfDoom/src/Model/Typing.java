package Model;

public class Typing {

    //these are all the resistance stats based on their typing.
    //used to calculate damage taken from magic attacks.

    //{Fire,Water,Flora,Shadow,Light,Type ID}
    float[] resistances = {1,1,1,1,1,1};
    public float[] Fire(){
        resistances = new float[]{.5f, 2, .5f, .5f, 1, 0};
        return resistances;
    }
    public float[] Water(){
        resistances = new float[]{.5f, .5f, 2, 1, .5f, 1};
        return resistances;
    }
    public float[] Flora(){
        resistances = new float[]{2, .5f, .5f, 2, .5f, 2};
        return resistances;
    }
    public float[] Shadow(){
        resistances = new float[]{2, 1, .5f, .5f, 2, 3};
        return resistances;
    }
    public float[] Light(){
        resistances = new float[]{1, .5f, 1, 2, .5f, 4};
        return resistances;
    }
}
