package Model.Monsters;

import Model.Typing;

import java.util.Random;

public class WispyWilly extends Creature {
    //Instantiations
    Typing type = new Typing();
    Random rnd = new Random();
    public static final String RESET = "\033[0m";  // Text Reset
    public static final String RED_BOLD = "\033[1;31m";    // RED
    //Constructors
    public WispyWilly() {
        super.name = RED_BOLD+"Wispy Willy"+RESET;
        super.attack = rnd.nextInt(3)+25;
        super.health = 150;
        super.maxHP = 150;
        super.defence = rnd.nextInt(1)+20;
        super.type = type.Fire();
    }
    //toString
    @Override
    public String toString() {
        return "willy{" +
                "name='" + super.name + '\'' +
                ", health=" + super.health +
                ", attack=" + super.attack +
                ", defence=" + super.defence +
                ", type=" + super.type +
                '}';
    }
}
