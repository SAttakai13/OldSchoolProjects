package Model.Monsters;

import Model.Typing;

import java.util.Random;


public class MightyBrightSprite extends Creature{
    //Instantiations
    Typing type = new Typing();
    Random rnd = new Random();
    public static final String YELLOW_BOLD_BRIGHT = "\033[1;93m";// YELLOW
    public static final String RESET = "\033[0m";  // Text Reset

    //Constructors
    public MightyBrightSprite(){
        super.name = YELLOW_BOLD_BRIGHT+"Mighty Bright Sprite"+RESET;
        super.attack = rnd.nextInt(3) + 15;
        super.health = 200;
        super.maxHP = 200;
        super.defence = rnd.nextInt(1) + 20;
        super.type = type.Light();
    }
    //toString
    @Override
    public String toString() {
        return "MightyBrightSprite{" +
                "name='" + name + '\'' +
                ", health=" + health +
                ", attack=" + attack +
                ", defence=" + defence +
                ", type=" + type +
                '}';
    }
}
