package Model.Monsters;

public abstract class Creature {
    //Functions
    protected String name;
    protected int health;
    protected int maxHP;
    protected int attack;
    protected int defence;
    protected float[] type;

    //Overloaded and Reg Constructors
    public Creature() {
    }
    public Creature(String name, int health, int attack, int defence, float[] type) {
        this.name = name;
        this.health = health;
        this.maxHP = health;
        this.attack = attack;
        this.defence = defence;
        this.type = type;
    }

    //Getters and Setters
    public void setName(String name){
        this.name = name;
    }
    public void setHealth(int health){
        this.health = health;
    }
    public void setMaxHP(int maxHP){
        this.maxHP = maxHP;
    }
    public void setAttack(int attack){
        this.attack = attack;
    }
    public void setDefence(int defence){
        this.defence = defence;
    }
    public void setType(float[] type){
        this.type = type;
    }

    public String getName() {return name;}
    public int getHealth() {return health;}
    public int getMaxHP() {return maxHP;}
    public int getAttack() {return attack;}
    public int getDefence() {return defence;}
    public float[] getType() {return type;}

    //toString
    @Override
    public String toString() {
        return "Creature{" +
                "name= " + name +
                ", health = " + health +
                ", attack = " + attack +
                ", defence = " + defence +
                ", type = " + type +
                '}';
    }
}
