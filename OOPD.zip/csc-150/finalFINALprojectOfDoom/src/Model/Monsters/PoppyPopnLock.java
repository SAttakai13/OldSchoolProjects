package Model.Monsters;

import Model.Typing;

import java.util.Arrays;
import java.util.Random;

public class PoppyPopnLock extends Creature{
    //Instantiations
    Typing type = new Typing();
    Random rnd = new Random();
    public static final String GREEN_BOLD = "\033[1;32m";  // GREEN
    public static final String RESET = "\033[0m";  // Text Reset

    //Constructors
    public PoppyPopnLock(){
        super.name = GREEN_BOLD+"Poppy Pop 'n' Lock"+RESET;
        super.attack = rnd.nextInt(3) + 20;
        super.health = 75;
        super.maxHP = 75;
        super.defence = rnd.nextInt(1) + 10;
        super.type = type.Flora();
    }
    //toString
    @Override
    public String toString() {
        return "PoppyPopnLock{" +
                "name='" + name + '\'' +
                ", health=" + health +
                ", attack=" + attack +
                ", defence=" + defence +
                ", type=" + type +
                '}';
    }
}
