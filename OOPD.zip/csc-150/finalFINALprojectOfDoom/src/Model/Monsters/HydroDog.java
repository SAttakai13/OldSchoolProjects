package Model.Monsters;
import Model.Typing;

import java.util.Arrays;
import java.util.Random;

public class HydroDog extends Creature{
    //Instantiations
    Typing type = new Typing();
    Random rnd = new Random();
    public static final String RESET = "\033[0m";  // Text Reset
    public static final String BLUE_BOLD = "\033[1;34m";   // BLUE

    //Constructors
    public HydroDog(){
        super.name = BLUE_BOLD+"Harley Hydro Dog"+RESET;
        super.health = 125;
        super.maxHP = 125;
        super.attack = rnd.nextInt(3) + 10;
        super.defence = rnd.nextInt(1) + 15;
        super.type = type.Water();
    }
    //toString
    @Override
    public String toString() {
        return "HydroDog{" +
                "name='" + name + '\'' +
                ", health=" + health +
                ", attack=" + attack +
                ", defence=" + defence +
                ", type=" + type +
                '}';
    }
}
