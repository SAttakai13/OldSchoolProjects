package Model.Monsters;
import Model.Typing;

import java.util.Arrays;
import java.util.Random;

public class MidnightBatCat extends Creature{
    //Instantiations
    Typing type = new Typing();
    Random rnd = new Random();
    public static final String BLACK = "\033[0;30m";   // BLACK
    public static final String RESET = "\033[0m";  // Text Reset

    //constructor
    public MidnightBatCat(){
        super.name = BLACK+"Midnight Bat Cat"+RESET;
        super.attack = rnd.nextInt(3)+30;
        super.health = 400;
        super.maxHP = 400;
        super.defence = rnd.nextInt(1)+25;
        super.type = type.Shadow();
    }
    //toString
    @Override
    public String toString() {
        return "MidnightBatCat{" +
                "name='" + name + '\'' +
                ", health=" + health +
                ", attack=" + attack +
                ", defence=" + defence +
                ", type=" + type +
                '}';
    }
}
