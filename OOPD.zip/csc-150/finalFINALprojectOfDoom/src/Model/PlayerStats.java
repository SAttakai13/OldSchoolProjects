package Model;

import View.UserInput;

import java.io.IOException;
import java.io.Serializable;
import java.util.Random;

public class PlayerStats implements Serializable {
    //functions
    protected String playerName;
    protected int playerHP;
    protected int playerMaxHP;
    protected int playerAtk;
    protected int playerDef;
    protected int manaPoints;

    //Constructors and overloaded constructors
    public PlayerStats(){}
    public PlayerStats(String name, int playerMaxHP, int playerAtk, int playerDef){
        setPlayerName(name);
        setPlayerHP(playerMaxHP);
        setPlayerMaxHP(playerMaxHP);
        setPlayerAtk(playerAtk);
        setPlayerDef(playerDef);
        setManaPoints(100);
    }

    //Getters and setters for this class
    public void setPlayerName(String playerName){
        this.playerName = playerName;
    };
    public void setPlayerHP(int playerHP) {
        this.playerHP = playerHP;
    }
    public void setPlayerMaxHP(int playerMaxHP) {
        this.playerMaxHP = playerMaxHP;
    }
    public void setPlayerAtk(int playerAtk) {
        this.playerAtk = playerAtk;
    }
    public void setPlayerDef(int playerDef) {
        this.playerDef = playerDef;
    }
    public void setManaPoints(int playerMana) { this.manaPoints = playerMana;}

    public String getPlayerName() {
        return playerName;
    }
    public int getPlayerHP() {
        return playerHP;
    }
    public int getPlayerMaxHP() { return playerMaxHP;}
    public int getPlayerAtk() { return playerAtk;}
    public int getPlayerDef() {return playerDef;}
    public int getManaPoints() {
        return manaPoints;
    }

    //toString
    @Override
    public String toString() {
        return "PlayerStats{" +
                "playerName='" + playerName + '\'' +
                ", playerHP=" + playerHP +
                ", playerMaxHP=" + playerMaxHP +
                ", playerAtk=" + playerAtk +
                ", playerDef=" + playerDef +
                '}';
    }
}
