package edu.neumont.oop.DAL;

import edu.neumont.oop.Model.JournalEntry;
import java.io.*;
import java.util.ArrayList;

public class JournalDAL {
    String fileName = "C:\\JE\\my.notes";

    public void save(ArrayList<JournalEntry> entries) throws IOException{

        FileOutputStream fileStream = new FileOutputStream(fileName);
        ObjectOutputStream outputStream = new ObjectOutputStream(fileStream);
        outputStream.writeObject(entries);
        outputStream.close();

    }
    public ArrayList<JournalEntry> load() throws IOException, ClassNotFoundException {
        //Read file?
        ArrayList<JournalEntry> JEArray = null;

        FileInputStream fileStream = new FileInputStream(fileName);
        ObjectInputStream inStream = new ObjectInputStream(fileStream);
        // --------------------------------------------------------------
        JEArray = (ArrayList<JournalEntry>) inStream.readObject();
        inStream.close();
        return JEArray;

    }
    ////////////////////////////////////////////
    public String getFileName(){return fileName;}
}
