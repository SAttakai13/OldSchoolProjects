package edu.neumont.oop.Controller;

import edu.neumont.oop.DAL.JournalDAL;
import edu.neumont.oop.Model.JournalEntry;
import edu.neumont.oop.View.MyInput;

import java.time.LocalDate;
import java.util.ArrayList;

public class L7Menu {
    MyInput get = new MyInput();
    JournalDAL dal = new JournalDAL();

    ArrayList<JournalEntry> entries = new ArrayList<JournalEntry>();
    ArrayList<JournalEntry> readArray = null;


    //Option menu
    public void StartJournalApp(){
        try {
            readArray = dal.load();
        } catch (Exception e) {
            get.display("Didn't load, ha get shit on >:D");
            e.printStackTrace();
        }
        int option = 0;
        while (option != 4) {
            switch (option = get.GetUserInt("Daily Journal:\n1.) Create and save new text\n2.) Search old text\n3.) Edit a entry\n4.) Exit")){
                case 1:
                    createNewText();
                    break;
                case 2:
                    SearchOldText();
                    break;
                case 3:
                    EditDay();
                    break;
            }
        }
    }

    public void createNewText(){
        int choose = 0;
        while(choose != 3){
            switch (choose = get.GetUserInt("Create new text:\n1.) Create new for today\n2.) Create new for a certain day\n3.) Exit\n")){
                case 1:
                    entries.add(new JournalEntry(LocalDate.now(),get.GetUserStr("Write something you weirdo: ")));
                    break;
                case 2:
                    entries.add(new JournalEntry(LocalDate.of(get.GetUserInt(1999,2022,"Enter year between 1999 - present year: "), get.GetUserInt(1, 12, "Enter Month: "), get.GetUserInt(1, 31, "Enter day:")), get.GetUserStr("Write something you weirdo:")));
                    break;
            }
        }

        //Save file
        try{
            dal.save(entries);
        } catch (Exception e){
            get.display("Didn't save, ha get shit on >:D");
            e.printStackTrace();
        }
    }

    public void SearchOldText() {
        try {
            readArray = dal.load();
        } catch (Exception e) {
            get.display("Didn't load, ha get shit on >:D");
            e.printStackTrace();
        }
        int choose = 0;
        while (choose != 4){
            switch (choose = get.GetUserInt("Search old text:\n1.) Search for today's entry\n2.) Search for a specified date\n3.) Search Entries for a range of dates\n4.) Exit")){
                case 1:
                    SearchToday();
                    break;
                case 2:
                    SearchSpecific();
                    break;
                case 3:
                    SearchRangeDates();
                    break;
            }
        }
    }

    public void EditDay(){
        try {
            readArray = dal.load();
        } catch (Exception e) {
            get.display("Didn't load, ha get shit on >:D");
            e.printStackTrace();
        }
        LocalDate specificDate = LocalDate.of(get.GetUserInt(1999,2022,"Enter specific year format (yyyy): "),get.GetUserInt(1,12,"Enter specific month format (MM)"), get.GetUserInt(1,31,"Enter beginning Day format (DD)"));
        for (int i = 0; i < readArray.size(); i++){
            if (readArray.get(i).getEntryLocalDate().isEqual(specificDate)){
                entries.get(i).setEntry(get.GetUserStr("Edit this text: "));
            }
        }
        try{
            dal.save(entries);
        } catch (Exception e){
            get.display("Didn't save, ha get shit on >:D");
            e.printStackTrace();
        }
    }

    public void SearchToday(){
        for (int i = 0; i < readArray.size(); i++){
            if (readArray.get(i).getEntryLocalDate().isEqual(LocalDate.now())){
                if (readArray.get(i).getEntry().length() >= 45){
                    get.display(readArray.get(i).getEntryLocalDate()+"\n"+readArray.get(i).getEntry().substring(0,45) + "...");
                } else {
                    get.display(readArray.get(i).getEntryLocalDate()+"\n"+readArray.get(i).getEntry());
                }
            }
        }
    }

    public void SearchSpecific(){
        LocalDate specificDate = LocalDate.of(get.GetUserInt(1999,2022,"Enter specific year format (yyyy): "),get.GetUserInt(1,12,"Enter specific month format (MM)"), get.GetUserInt(1,31,"Enter beginning Day format (DD)"));
        for (int i = 0; i < readArray.size(); i++){
            if (readArray.get(i).getEntryLocalDate().isEqual(specificDate)){
                if (readArray.get(i).getEntry().length() >= 45){
                    get.display(readArray.get(i).getEntryLocalDate()+"\n"+readArray.get(i).getEntry().substring(0,45) + "...");
                } else {
                    get.display(readArray.get(i).getEntryLocalDate()+"\n"+readArray.get(i).getEntry());
                }
            }
        }
    }

    public void SearchRangeDates(){
        LocalDate beginningDate = LocalDate.of(get.GetUserInt(1999,2022,"Enter beginning year format (yyyy): "),get.GetUserInt(1,12,"Enter beginning month format (MM)"), get.GetUserInt(1,31,"Enter beginning Day format (DD)"));
        LocalDate endDate = LocalDate.of(get.GetUserInt(1999,2022,"Enter end of range year, format (yyyy): "),get.GetUserInt(1,12,"Enter end month format (MM)"), get.GetUserInt(1,31,"Enter end Day format (DD)"));
        for (int date = 0; date < readArray.size(); date++){
            if ((readArray.get(date).getEntryLocalDate().isAfter(beginningDate)) && (readArray.get(date).getEntryLocalDate().isBefore(endDate)) || (readArray.get(date).getEntryLocalDate().isEqual(beginningDate)) || (readArray.get(date).getEntryLocalDate().isEqual(endDate))){
                if (readArray.get(date).getEntry().length() >= 45){
                    get.display(readArray.get(date).getEntryLocalDate() + "\n" + readArray.get(date).getEntry().substring(0, 45) + "...");
                } else {
                    get.display(readArray.get(date).getEntryLocalDate() + "\n" +readArray.get(date).getEntry());
                }
            }
        }
    }
}




















