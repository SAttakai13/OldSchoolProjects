package edu.neumont.oop.View;

import edu.neumont.oop.Controller.L7Menu;

public class L7Main {
    public static void main(String[] args) {
        L7Menu menu = new L7Menu();
        menu.StartJournalApp();
        System.out.println("Good-bye");
    }
}
