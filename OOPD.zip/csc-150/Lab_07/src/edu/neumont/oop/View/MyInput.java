package edu.neumont.oop.View;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MyInput {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));

    //String input and prompts the user for a string input
    public String GetUserStr(String prompt) {
        System.out.println(prompt);
        String sReturn = "";
        try {
            sReturn = bread.readLine();
        } catch (Exception ex) {
            sReturn = ex.getMessage();
            System.out.println("What are you doing? Put in a entry >:(");
        }
        return sReturn;
    }

    //Prompt user for int input
    public int GetUserInt(String prompt) {
        int iReturn = -1;
        while ((iReturn < 0))
            try {
                iReturn = Integer.parseInt(GetUserStr(prompt));
            } catch (Exception ex) {
                // TODO
                System.out.println("Invalid value, re-enter value.");
            }
        return iReturn;
    }

    //This is a User int that has a set boundaries to make sure the user doesn't go out of bounds.
    //Sets up boundaries to make sure it doesn't go out of the month, date and, month ranges
    public int GetUserInt(int min, int max, String prompt) {
        boolean bLoop = true;
        int iReturn = 0;
        while (bLoop == true) {
            iReturn = GetUserInt(prompt);
            if ((iReturn >= min) && (iReturn <= max))
                bLoop = false;
            else
                System.out.println("Input value between " + min + " and " + max);
        }
        return iReturn;
    }

    public String display(String sDisplay){
        System.out.println(sDisplay);
        return sDisplay;
    }
}
