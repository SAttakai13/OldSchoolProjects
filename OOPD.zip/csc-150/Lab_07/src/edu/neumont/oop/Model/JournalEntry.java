package edu.neumont.oop.Model;

import java.io.Serializable;
import java.time.LocalDate;

public class JournalEntry implements Serializable {
    LocalDate entryLocalDate;
    String entry;

    public JournalEntry(){}
    public JournalEntry(LocalDate entryDate, String entry){
        this.entryLocalDate = entryDate;
        this.entry = entry;
    }

    public LocalDate getEntryLocalDate() {
        return entryLocalDate;
    }

    public void setEntryLocalDate(LocalDate entryLocalDate) {
        this.entryLocalDate = entryLocalDate;
    }

    public String getEntry() {
        return entry;
    }

    public void setEntry(String entry) {
        this.entry = entry;
    }

    @Override
    public String toString() {
        return "JournalEntry: " +
                "\nEntry Date (" + entryLocalDate +
                ")\nEntry= " + entry;
    }
}
