import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PersonFactory {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));


    public Person promptPerson(){
        Person per = new Person();
        String name = "";

        System.out.println("Name: ");
        name = GetString();
        while(name.equals("")){
            System.out.println("Enter missing field");
            name = GetString();
        }
        per.setName(name);

        System.out.println("Prefix (optional): ");
        per.setPrefix(GetString());

        System.out.println("Suffix (optional): ");
        per.setSuffix(GetString());

        System.out.println("Age: ");

        per.setAge(GetInt());

        return per;
    }

    public String GetString() {
        try {
            return bread.readLine();
        }
        catch (Exception ex) {
            System.out.println("Enter the required field");
        }
        return null;
    }

    public void WelcomeMsg(Person per){
        System.out.println(per.toString());
        System.out.println("Welcome " + per.getPrefix() + " " + per.getName() + " " + per.getSuffix() + " (" + per.getAge() + ")");
        per.compAge(per.getAge());

    }

    // ///////////////////////////////////////
    private int GetInt() {
        try {
            return Integer.parseInt(GetString());
        }
        catch (Exception ex) {
            System.out.println("Enter Age");
            Integer.parseInt(GetString());
        }
        // Failed
        return -1;
    }

}
