import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class L1Main {

    public static void main(String[] args) {

        Person per = null;
        PersonFactory personFact = new PersonFactory();
        ArrayList<Person> people = new ArrayList<Person>();
        boolean addMore = true;
        // ---------------------------------------
        per = personFact.promptPerson();

        personFact.WelcomeMsg(per);

        people.add(per);

        do  {
            System.out.println("Add more people? Y/N: ");
            if (personFact.GetString().toUpperCase(Locale.ROOT).equals("N")){
                addMore = false;
            } else if (personFact.GetString().toUpperCase(Locale.ROOT).equals("Y")){
                per = personFact.promptPerson(); // Get another person
                people.add(per); // Add to the list
            }
        } while (addMore);
    }
}