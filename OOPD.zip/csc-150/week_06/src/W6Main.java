public class W6Main {
    public static void main(String[] args) {
        MyWork work = new MyWork();
        work.StartHere();
    }
}
