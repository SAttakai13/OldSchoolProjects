import java.util.Random;

public class MyWork {
    public void StartHere() {
//        int array1[] = {1, 2, 3, 4};
//        int array2[][] = {
//                {1, 2, 3},
//                {4, 5, 6},
//                {7, 8, 9}};
//
//        int myInt = array1[1];
//        int myInt2 = array2[2][1]
//        int array4[][] = new int[8][8]; //Heap
//        Truck[] garage = new Truck[10];
//        garage[2] = new Truck();
//        garage[2].setSpeed(25);

        int array1[][] = {
                {5, 3, 0, 0, 7, 0, 0, 0, 0},
                {6, 0, 0, 1, 9, 5, 0, 0, 0},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}

        };

        displayArray(array1);


    }
    public void displayArray(int[][] array){
        for (int i = 0; i < array.length; i++){
            for (int crap = 0; crap < array[i].length; crap++){
                System.out.print(array[i][crap] + " | ");
            }
            System.out.println("\n");
        }
    }
    //------
//        int array3[] = new int[100];
//
//        //loop here to initialize random number
//        for (int i = 0; i < array3.length; i++){
//            array3[i] = random(1, 10);
//        }
//
//        System.out.println("Max value in list is: " + MyMax(array3));
//        System.out.println("Min value in list is: " + MyMin(array3));
//        System.out.println("Mode value in list is: " + MyMode(array3));
//        System.out.println("Mean value in list is: " + MyMean(array3));


//    public int random(int min, int max) {
//        Random random = new Random();
//        Integer randInt = random.nextInt((max - min) + 1) + min;
//        return randInt;
//    }
//
//    public int MyMax(int[] list){
//        int max = 0;
//        for (int counter = 0; counter < list.length; counter++){
//            if (list[counter] > max){
//                max = list[counter];
//            }
//        }
//        return max;
//    }
//
//    public int MyMin(int[] list){
//        int min = 0;
//        for (int counter = 0; counter < list.length; counter++){
//            if (list[counter] < min){
//                min = list[counter];
//            }
//        }
//        return min;
//    }
//
//    public float MyMean(int[] list){
//        float mean = 0;
//        for (int i = 0; i < list.length; i++){
//            mean += list[i];
//        }
//        return mean/list.length;
//    }
//
//    private int MyMode(int[] list){
//        int max = 0;
//        int countList[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//        for( int counter = 0; counter < list.length; counter++){
//        countList[list[counter] - 1]++;
//        }
//        for (int i = 0; i < countList.length; i++){
//            if (countList[i] > max){
//                max = list[i];
//            }
//        }
//        return max;
//    }
}