public class Skunk extends Animal{
    protected String spray;
    public Skunk(String name, String species, String gender, Double weight, String habitat, String danger, String spray){
        super(name, species,gender, weight, habitat, danger);
        setSpray(spray);
    }

    public String getSpray() {
        return spray;
    }

    public void setSpray(String spray) {
        this.spray = spray;
    }

    boolean Feed() {
        return true;
    }

    @Override
    String Speak() {
        return "Squeak, squeak. oh no are you gonna get sprayed? " + getSpray() + "\nWas it fed? " + Feed();
    }


}
