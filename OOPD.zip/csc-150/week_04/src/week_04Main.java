import java.util.ArrayList;

public class week_04Main {
    public static void main(String[] args) {
        Penguin geralt = new Penguin("Geralt", "Bird", "Male", 250.7, "South Pole", "Not really", "Yes");
        //System.out.println(geralt.Speak());

        Squirrel bessie = new Squirrel("Bessie", "Rodent", "female", 5.3, "Forest", "Pretty medium, it hurts to get hit by a nut", "nope");
        //System.out.println(bessie.Speak());

        Skunk James = new Skunk("James", "Feline", "Male", 15.7, "Anywhere", "You're fine if you dont mess with them.", "Nope, its got better things to do than to spray you.");

        Dog Roofus = new Dog("Roofus", "Canine", "Male", 50.3, "Domestic", "Screw around and find out", "Yes, its a good doggo");


        ArrayList<Animal> house = new ArrayList<>();
        house.add(geralt);
        house.add(bessie);
        house.add(James);
        house.add(Roofus);

        for(int iCount = 0; iCount < house.size(); iCount++){
            System.out.println("Speak: " + house.get(iCount).Speak());
            System.out.println(house.get(iCount).Feed());
        }

    }
}
