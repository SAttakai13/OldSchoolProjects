public class Dog extends Animal{
    protected String fetch;
    public Dog(String name, String species, String gender, Double weight, String habitat, String danger, String fetch){
        super(name, species, gender, weight, habitat, danger);
        setFetch(fetch);
    }

    public String getFetch() {
        return fetch;
    }

    public void setFetch(String fetch) {
        this.fetch = fetch;
    }

    @Override
    String Speak() {
        return "Ohh look its so cute, can it play fetch? " + getFetch() + "\nWas it fed? " + Feed();
    }

    @Override
    boolean Feed() {
        return true;
    }
}
