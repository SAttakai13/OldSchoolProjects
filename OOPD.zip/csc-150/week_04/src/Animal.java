abstract class Animal {
    private String name;
    private String species;
    protected String habitat;
    protected String gender;
    private double weight;
    private String dangerous;

    public Animal(){}

    public Animal (String name, String species, String gender, Double weight, String habitat, String danger){
        setName(name);
        setSpecies(species);
        setGender(gender);
        setWeight(weight);
        setHabitat(habitat);
        setDangerous(danger);
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getSpecies() {return species;}
    public void setSpecies(String species) {this.species = species;}

    public String getHabitat() {
        return habitat;
    }
    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }

    public double getWeight() {
        return weight;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getDangerous() {
        return dangerous;
    }
    public void setDangerous(String dangerous) {
        this.dangerous = dangerous;
    }


    abstract String Speak();

    abstract boolean Feed();




    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                ", habitat='" + habitat + '\'' +
                ", gender='" + gender + '\'' +
                ", weight = " + weight + " lbs" +
                ", dangerous = '" + dangerous + '\'' +
                '}';
    }
}
