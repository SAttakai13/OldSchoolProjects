public class Penguin extends Animal{
    protected String hasEgg;
    public Penguin(String name, String species, String gender, Double weight, String habitat, String danger, String hasEgg){
        super(name, species, gender, weight, habitat, danger);
        setHasEgg(hasEgg);
    }

    public String getHasEgg() {return hasEgg;}
    public void setHasEgg(String hasEgg) {this.hasEgg = hasEgg;}


    boolean Feed() {
        return true;
    }

    @Override
    String Speak(){
        return "Bird noises ._., does " + getName() + " have ze egg? " + getHasEgg() + "\nWas it fed? " + Feed();
    }

    @Override
    public String toString() {
        return "My penguin " + super.toString();
    }
}
