public class Squirrel extends Animal{
    protected String hasAcorn;
    public Squirrel(String name, String species, String gender, Double weight, String habitat, String danger, String acorn){
        super(name, species,gender, weight, habitat, danger);
        setHasAcorn(acorn);
    }

    boolean Feed() {
        return true;
    }

    public String getHasAcorn() {return hasAcorn;}
    public void setHasAcorn(String hasAcorn) {this.hasAcorn = hasAcorn;}

    @Override
    String Speak(){
        return "Squirrel noises (Ahhh!!!!!!!!!!! Squirrel!). Its mad, does it have an acorn? " + getHasAcorn() + "\nWas it fed? " + Feed();
    }

    @Override
    public String toString() {
        return "My squirrel " + super.toString();
    }
}
