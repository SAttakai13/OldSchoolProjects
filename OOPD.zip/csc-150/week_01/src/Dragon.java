public class Dragon {
    private String color;
    private int age;
    private String type;
    private int length;

    public Dragon(String color, int age, String type, int length) {
       setAge(age);
       this.color = color;
       this.type = type;
       setLength(length);

    }

    //-----------------------
    public int getAge() {
        return age;
    }
    public void setAge(int age){
        if (age < 0){
            this.age = 0;
        } else {
            this.age = age;
        }
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        if (length < 0){
            this.length = 0;
        } else {
            this.length = length;
        }
    }
    //-----------------------

    @Override
    public String toString() {
        return "Dragon{" + "color='" + color + '\'' + ", age=" + age + ", type=" + type + ", Length=" + length + "}";
    }
}
