public class WK01 {
    public static void main(String[] args) {
        System.out.println("hello world");

        Dragon myDragon = new Dragon("Purple", 5, "Lightfury", 30);

        System.out.println("My dragon = " + myDragon.toString());
    }
}
