public class StrawberryCake extends CakeMain{
    //variables
    public String strawberry;
    public String strawberryFrosting;
    private int numofslicedberries;
    private String sprinkles;

    ///Getters and setters for variables
    public int getNumofslicedberries() {
        return numofslicedberries;
    }
    public void setNumofslicedberries(int numofslicedberries) {
        this.numofslicedberries = numofslicedberries;
    }
    public String getSprinkles() {
        return sprinkles;
    }
    public void setSprinkles(String sprinkles) {
        this.sprinkles = sprinkles;
    }

    //Setters from parent class cake main
    @Override
    public void setFlavor(String flavor) {
        super.setFlavor(strawberry);
    }
    @Override
    public void setToppings(String toppings) {
        super.setToppings(strawberryFrosting);
    }
}
