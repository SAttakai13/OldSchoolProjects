public class CakeMain {
    //Variables in Cake main
    private String flavor;
    private String toppings;
    public static void main(String[] args) {
        //making it chocolate cake and strawberry cake objects
        ChocolateCake chocolateCake = new ChocolateCake();
        StrawberryCake strawberryCake = new StrawberryCake();

        // setting certain variables from their classes
        strawberryCake.setNumofslicedberries(6);
        strawberryCake.setSprinkles("Red Sprinkles");
        chocolateCake.setChocolateType("Milk Chocolate");
        chocolateCake.setMarshmellows(17);
    }
    //Getters and Setters for toppings and flavors
    public String getToppings() {
        return toppings;
    }
    public void setToppings(String toppings) {
        this.toppings = toppings;
    }
    public String getFlavor() {
        return flavor;
    }
    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }
}
