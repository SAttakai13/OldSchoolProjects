public class ChocolateCake extends CakeMain{
    //Variables
    public String chocolate;
    public String chocolateFrosting;
    private String chocolateType;
    private int marshmellows;

    ///Variables getters and setters
    public String getChocolateType() {
        return chocolateType;
    }
    public void setChocolateType(String chocolateType) {
        this.chocolateType = chocolateType;
    }
    public int getMarshmellows() {
        return marshmellows;
    }
    public void setMarshmellows(int marshmellows) {
        this.marshmellows = marshmellows;
    }

    //Setters from parent class cake main
    @Override
    public void setFlavor(String flavor) {
        super.setFlavor(chocolate);
    }
    @Override
    public void setToppings(String toppings) {
        super.setToppings(chocolateFrosting);
    }
}
