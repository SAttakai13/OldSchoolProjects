public class Main {
    public static void main(String[] args) {
        //Look the objects are accessible from here!
        ChocolateCake chocolateCake = new ChocolateCake();
        chocolateCake.setMarshmellows(42);
        StrawberryCake strawberryCake = new StrawberryCake();
        strawberryCake.setNumofslicedberries(20);
    }
}
