package Controller;

import Model.*;
import View.MyInput;

import java.util.Random;


public class GamePlay {
    GameBoard board = new GameBoard();

    //start game
    public void StartGame(MyInput input, AbsPlayer Player1, AbsPlayer Player2) {
        System.out.println("*** Push - GamePlay::StartGame()");
        //Check if player is human, if so then it prompts them, but otherwise the token and name are set up already
        if (Player1.getHuman() == true) {
            Player1.setName(input.GetUserStr("Input player 1 name:", true));
            if (input.GetUserInt(1, 2, "Select color \n 1) X \n 2) O ") == 1) {
                Player1.setToken('X');
            } else {
                Player1.setToken('O');
            }
        } else if(Player1.getHuman() == false){
            Player1.setToken('X');
        }
        if (Player2.getHuman() == true) {
            Player2.setName(input.GetUserStr("Input Player 2 name:", true));
            if (Player1.getToken() == 'O') {
                Player2.setToken('X');
            } else {
                Player2.setToken('O');
            }
        } else if (!Player2.getHuman() == false){
            Player2.setToken('O');
        }
        //plays game
        PlayGame(input, Player1, Player2);
        System.out.println("!!! Pop - GamePlay::StartGame()");
    }

    public void PlayGame(MyInput input, AbsPlayer Pla1, AbsPlayer Pla2) {
        System.out.println("*** Push - GamePlay::PlayGame()");
        //Newer variables to keep track of whats happening
        boolean win = false;
        Random random = new Random();
        board.ResetGameBoard();
        int turnNum = random.nextInt(2)+1;
        //While loop for the game unless the win is
        while (!win) {
            board.ShowGameBoard();
            int column = 0;
            int row = 5;
            switch (turnNum) {
                case 1:
                    if (Pla1.isHuman()){
                        column = input.GetUserInt(1, 7,Pla1.getName() + "'s Turn. Input a column:");
                        row = Droptoken(column, Pla1);
                    } else {
                        row = Droptoken(random.nextInt(6)+1, Pla1);
                    }
                    turnNum = 2;
                    if(CheckWin(row, column-1, Pla1) == true){
                        board.ShowGameBoard();
                        input.StringOutput(Pla1.getName() + " you win!");
                        win = true;

                    }
                        break;
                case 2:
                    if (Pla2.isHuman()){
                        column = input.GetUserInt(1, 7,Pla2.getName() + "'s Turn. Input a column:");
                        row = Droptoken(column, Pla2);
                    } else {
                        row = Droptoken(random.nextInt(6)+1, Pla2);
                    }
                    turnNum = 1;
                    if(CheckWin(row, column-1, Pla2) == true){
                        board.ShowGameBoard();
                        input.StringOutput(Pla2.getName() + " you win!");
                        win = true;
                    }
                    break;
            }
        }
        System.out.println("!!!Pop - GamePlay::PlayGame()");
    }

    //droptoken in a certain row and column
    private int Droptoken(int col, AbsPlayer Player) {
        System.out.println("*** Push - GamePlay::Droptoken()");
        boolean bReturn = false;
        int row = (board.getRows()-1);
        while (!bReturn && row >= 0) {
            if ((bReturn == false) && (board.getToken(row, col-1) == ' ')) {
                board.setToken(row, col-1, Player.getToken());
                bReturn = true;
            }
            else{
                row -= 1;
            }
        }
        System.out.println("!!!Pop - GamePlay::Droptoken()");
        return row;
    }

    //test the cells to see if they are empty
    private boolean TestCell(int x, int y, AbsPlayer player) {
        System.out.println("*** Push - GamePlay::TestCell()");
        if ((x < 0) || (x >= board.getRows())) {
            return false;
        }
        if((y < 0) || y >= board.getCols()){
            return false;
        }
        if (board.getToken(x, y) == ' ') {
            return false;
        }
        if (board.getToken(x, y) == player.getToken()) {
            return true;
        }
        System.out.println("!!! Pop - GamePlay::TestCell()");
        return false;
    }

    //look right
    private int LookRight(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::LookRight()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos, yPos+count, player) == true){
                counter++;
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::LookRight()");
        return counter;
    }
    //look left
    private int LookLeft(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::LookLeft()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos, yPos-count, player) == true){
                counter++;

                //look a direction n use count to change pos
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::LookLeft()");
        return counter;
    }
    //look up
    private int LookUp(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::LookUp()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos-count, yPos, player) == true){
                counter++;

                //look a direction n use count to change pos
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::LookUp()");
        return counter;
    }
    //look down
    private int LookDown(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::LookDown()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos+count, yPos, player) == true){
                counter++;

                //look a direction n use count to change pos
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::LookDown()");
        return counter;
    }

    //look right up
    private int RightUp(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::RightUp()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos-count, yPos+count, player) == true){
                counter++;

                //look a direction n use count to change pos
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::RightUp()");
        return counter;
    }

    //look right down
    private int RightDown(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::RightDown()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos+count, yPos+count, player) == true){
                counter++;

                //look a direction n use count to change pos
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::RightDown()");
        return counter;
    }

    //look left down
    private int LeftDown(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::LeftDown()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos+count, yPos-count, player) == true){
                counter++;
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::LeftDown()");
        return counter;
    }

    //look left up
    private int LeftUp(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::LeftUp()");
        int counter = 0;
        for (int count = 0; count <= 4; count++){
            if(TestCell(xPos-count, yPos-count, player) == true){
                counter++;
            } else {
                return counter;
            }
        }
        System.out.println("!!! Pop - GamePlay::LeftUp()");
        return counter;
    }


    //checks all wins in different directions
    private boolean CheckWin(int xPos, int yPos, AbsPlayer player){
        System.out.println("*** Push - GamePlay::CheckWin()");
        if(LookLeft(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if(LookRight(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if(LookUp(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if (LookDown(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if (RightUp(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if(RightDown(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if (LeftDown(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        if (LeftUp(xPos, yPos, player) >= 4){
            System.out.println("!!!Pop - GamePlay::CheckWin()");
            return true;
        }
        System.out.println("!!!Pop - GamePlay::CheckWin()");
        return false;
    }

}



