package Controller;

import Model.Computer;
import Model.Person;
import View.MyInput;

public class DoWork {
    private MyInput get = new MyInput();
    private GamePlay game = new GamePlay();
    //Work space for menu
    public void workArea(){
        System.out.println("*** Push - DoWork::workArea()");
        int options = -1;
        while (options != 4){
            switch (options = get.GetUserInt(1, 4, "Connect four:\n1. Human vs. Human\n2. Human vs. Computer\n3. Computer vs. Computer\n4. Exit")){
                case 1:
                    //Person vs. Person
                    PersonPerson();
                    break;
                case 2:
                    //Person vs. Computer
                    PersonComputer();
                    break;
                case 3:
                    //Computer vs. Computer
                    CompComp();
                    break;
            }
        }
        System.out.println("!!! Pop - DoWork::workArea()");
    }
    //Person vs Person method with a input with get, and new instantations of person are called inside them.
    public void PersonPerson(){
        System.out.println("*** Push - DoWork::PersonPerson()");
        game.StartGame(get, new Person(null, true, ' '), new Person(null, true,' '));
        System.out.println("!!! Pop - DoWork::PersonPerson()");
    }
    //Person vs Computer method with a input with get, and new instantations of person and computer are called inside them.
    public void PersonComputer(){
        System.out.println("*** Push - DoWork::PersonComputer()");
        game.StartGame(get, new Person(null, true, ' '), new Computer("Computer", false, ' '));
        System.out.println("!!! Pop - DoWork::PersonComputer()");
    }
    //Computer vs Computer method with a input with get, and new instantations of computer are called inside them.
    public void CompComp(){
        System.out.println("*** Push - DoWork::CompComp()");
        game.StartGame(get, new Computer("Comp1", false, ' '), new Computer("Comp2", false, ' '));
        System.out.println("!!! Pop - DoWork::CompComp()");
    }
}
