package Model;

public class ChipToken {
    //just gets the token and stuff
    //variables in the class
    protected char token;

    //getters and setters
    public char getToken() {return token;}
    public void setToken(char token) {this.token = token;}

    //to string
    @Override
    public String toString() {
        System.out.println("*** Push - ChipToken::toString");
        System.out.println("!!! Pop - ChipToken::toString");
        return token+"";
    }
}
