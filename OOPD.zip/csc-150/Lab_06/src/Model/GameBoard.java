package Model;
import java.util.Arrays;

public class GameBoard {
    //new chiptoken chip and new game board in char array
    public ChipToken chip = new ChipToken();
    public static char gameBoard[][] = new char[6][7];

    //sets the token on the game board
    public void setToken(int xPos, int yPos, char token){
        System.out.println("*** Push - GameBoard::setToken");
        gameBoard[xPos][yPos] = token;
        System.out.println("!!! Pop - GameBoard::setToken");
    }

    //gets the token in the x and y pos of the gameboard
    public char getToken(int xPos, int yPos){
        System.out.println("*** Push - GameBoard::getToken");
        System.out.println("!!! Pop - GameBoard::getToken");
        return gameBoard[xPos][yPos];
    }

    //gets the columns in the gameboard
    public int getCols(){
        System.out.println("*** Push - GameBoard::getCols");
        System.out.println("!!! Pop - GameBoard::getCols");
        return gameBoard[0].length;
    }
    //grabs the rows in the gameboard
    public int getRows(){
        System.out.println("*** Push - GameBoard::getRows");
        int count = 0;
        for (int countRows = 0; countRows < gameBoard.length; countRows++){
            count++;
        }
        System.out.println("!!! Pop - GameBoard::getRows");
        return count;
    }

    //shows the gameboard
    public void ShowGameBoard(){
        System.out.println("*** Push - GameBoard::ShowGameBoard");
        displayArray(gameBoard);
        System.out.println("!!! Pop - GameBoard::ShowGameBoard");
    }
    public void ResetGameBoard(){
        System.out.println("*** Push - GameBoard::ResetGameBoard");
        chip.token = ' ';
        for(int fill = 0; fill < gameBoard.length; fill++){
            for (int i = 0; i < gameBoard[fill].length; i++){
                gameBoard[fill][i] = chip.token;
            }
        }
        System.out.println("!!! Pop - GameBoard::ResetGameBoard");
    }

    //ik I'm supposed to not put any sout in this, but I needed to display the board somehow.
    public void displayArray(char[][] array){
        System.out.println("*** Push - GameBoard::displayArray");
        for (int count = 0; count < array.length; count++){
            for (int value = 0; value < array[count].length; value++){
                System.out.print("| " + array[count][value] + " |");
            }
            System.out.print("\n");
        }
        System.out.println("!!! Pop - GameBoard::displayArray");
    }

    //toString
    @Override
    public String toString() {
        System.out.println("*** Push - GameBoard::toString");
        System.out.println("!!! Pop - GameBoard::toString");
        return "GameBoard{" +
                "token=" + chip.token +
                ", gameBoard=" + Arrays.toString(gameBoard) +
                '}';
    }
}
