package Model;

public class Person extends AbsPlayer{
    //Constructors for stuff drawn from the super class
    public Person(){}
    public Person(String name, Boolean human, char token){super(name, human ,token);}

    //Overrides the human, and token stuff from the AbsPlayer
    @Override
    public void setHuman(boolean human) {this.human = true;}
    @Override
    public void setToken(char token) {chip.token = token;}

    //ToString method
    @Override
    public String toString() {
        System.out.println("*** Push - Person::toString");
        System.out.println("!!! Pop - Person::toString");
        return "Person{" +
                "name='" + name + '\'' +
                ", human=" + human +
                ", token=" + chip.token +
                '}';
    }
}
