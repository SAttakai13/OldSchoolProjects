package Model;

public abstract class AbsPlayer {
    //functions
    protected String name;
    protected boolean human;
    protected ChipToken chip = new ChipToken();

    //Constructors
    public AbsPlayer(){}
    public AbsPlayer(String name, boolean human, char token){
        setName(name);
        setHuman(human);
        chip.setToken(token);
    }

    //getters and setters
    public boolean isHuman() {
        return human;
    }

    public void setName(String name) {this.name = name;}
    //Abstract method
    public abstract void setHuman(boolean human);
    public abstract void setToken(char token);

    //getters and setters
    public String getName() {return name;}
    public boolean getHuman() {return human;}
    public char getToken() {return chip.token;}

    //toString
    @Override
    public String toString() {
        System.out.println("*** Push - AbsPlayer::toString");
        System.out.println("!!! Pull - AbsPlayer::toString");
        return "AbsPlayer{" +
                "name='" + name + '\'' +
                ", human=" + human +
                ", token=" + chip.getToken() +
                '}';
    }
}
