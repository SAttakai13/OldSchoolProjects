package Model;

public class Computer extends AbsPlayer{
    //Constructors for stuff drawn from the super class
    public Computer(){}
    public Computer(String name, Boolean human ,char token){
        super(name, human, token);
    }

    //Overrides the human, and token stuff from the AbsPlayer
    @Override
    public void setHuman(boolean human) {
        this.human = false;
    }
    @Override
    public void setToken(char token) {chip.token = token;}

    //ToString method
    @Override
    public String toString() {
        System.out.println("*** Push - Computer::toString");
        System.out.println("!!! Pop - Computer::toString");
        return "Computer{" +
                "name='" + name + '\'' +
                ", human=" + human +
                ", chip=" + chip.token +
                '}';
    }
}
