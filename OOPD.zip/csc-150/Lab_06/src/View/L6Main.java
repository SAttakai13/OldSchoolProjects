package View;

import Controller.DoWork;

public class L6Main {
    public static void main(String[] args) {
        //creates work area
        System.out.println("*** Push - L6Main::main()");
        DoWork work = new DoWork();
        work.workArea();
        System.out.println("Good-bye");
        System.out.println("!!! Pop - L6Main::main()");
    }
}
