package View;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MyInput {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));

    //gets user string input
    public String GetUserStr(String prompt, boolean check) {
        System.out.println("*** Push - MyInput::GetUserStr()");
        String sReturn = "";
        boolean bLoop = true;
        while (bLoop == true){
            if (prompt != null)
                System.out.println(prompt);
            try {
                sReturn = bread.readLine();
                bLoop = (check && (sReturn.length() < 1));
            } catch (Exception ex) {
                sReturn = ex.getMessage();
                System.out.println("Error - " + ex.getMessage());
            }
        }
        System.out.println("!!! Pop - MyInput::GetUserStr()");
        return sReturn;
    }
    public int GetUserInt(){
        System.out.println("*** Push - MyInput::GetUserInt()");
        System.out.println("!!! Pop - MyInput::GetUserInt()");
        return GetUserInt(null);
    }

    //turns user input into an int
    public int GetUserInt(int min, int max, String prompt) {
        System.out.println("*** Push - MyInput::GetUserInt()");
        boolean bLoop = true;
        int iReturn = 0;
        while (bLoop == true) {
            iReturn = GetUserInt(prompt);
            if ((iReturn >= min) && (iReturn <= max))
                bLoop = false;
            else
                System.out.println("Input value between " + min + " and " + max);
        }
        System.out.println("!!! Pop - MyInput::GetUserInt()");
        return iReturn;
    }

    //get user int from a string prompt
    public int GetUserInt(String prompt) {
        System.out.println("*** Push - MyInput::GetUserInt()");
        boolean bLoop = true;
        int iReturn = 0;
        while (bLoop == true){
            try {
                iReturn = Integer.parseInt(GetUserStr(prompt, true));
                bLoop = false;
            } catch (Exception ex) {
                System.out.println("Invalid value, enter a positive integer.... Hehe dumbass, get shit on");
            }
        }
        System.out.println("!!! Pop - MyInput::GetUserInt()");
        return iReturn;
    }
    //string prompt to display winner
    public String StringOutput(String prompt){
        System.out.println("*** Push - MyInput::StringOutput()");
        System.out.println(prompt);
        String mes = "";
        try{
            mes = bread.readLine();
        }catch (Exception ex){
            mes = ex.getMessage();
        }
        System.out.println("!!! Pop - MyInput::StringOutput()");
        return mes;
    }

}

