public class Snek extends Reptile{
    private int length;
    private String biteybitey;

    public int getLength() {return length;}
    public void setLength(int length) {this.length = length;}

    public String getBiteybitey() {return biteybitey;}
    public void setBiteybitey(String biteybitey) {this.biteybitey = biteybitey;}

    public void thisIsMySnek(){
        super.setName("Bob");
        super.setAge(42);
    }
    public void TakeCareOfMySnek(){
        super.eat();
    }
}
