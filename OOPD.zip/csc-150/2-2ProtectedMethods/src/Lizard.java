public class Lizard extends Reptile{
    private String type;
    private String agg;

    public String getType() {return type;}
    public void setType(String type) {this.type = type;}

    public String getAgg() {return agg;}
    public void setAgg(String agg) {this.agg = agg;}

    public void thisIsMyLizard(){
        super.setName("Godzilla");
        super.setAge(10);
    }
    public void TakeCareOfMyLizard(){
        super.eat();
    }


}
