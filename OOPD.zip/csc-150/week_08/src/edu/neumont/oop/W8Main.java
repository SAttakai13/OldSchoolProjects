package edu.neumont.oop;

import edu.neumont.oop.Controller.DoWork;

public class W8Main {
    public static void main(String[] args) {
        DoWork work = new DoWork();
        work.StartArea();
    }
}
