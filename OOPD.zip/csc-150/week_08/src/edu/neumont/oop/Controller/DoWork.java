package edu.neumont.oop.Controller;
import edu.neumont.csc150.openmedia.MovieDetail;
import edu.neumont.csc150.openmedia.OpenMediaClient;
import edu.neumont.oop.View.DisplayDetails;

public class DoWork {
    private DisplayDetails details = new DisplayDetails();

    public void StartArea(){
        MovieDetail movie;
        edu.neumont.csc150.openmedia.OpenMediaClient media = new OpenMediaClient("d4c350b4");
        movie = media.getMovieByImdbId("tt3896198");
        details.Display("title: ", movie.getTitle());
        details.Display("actors: ", movie.getActors());
        details.Display("Summary: ", movie.getPlot());

    }
}
