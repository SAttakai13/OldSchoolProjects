package edu.neumont.oop.View;

public class DisplayDetails {
    public void Display(String title, String content){
        System.out.println(title + "::" + content);
    }

}
