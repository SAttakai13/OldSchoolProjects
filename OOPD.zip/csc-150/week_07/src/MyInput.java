package src;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MyInput {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));
    public String GetUserStr(String prompt, boolean check) {
        System.out.println("*** Push - MyInput::GetUserStr()");
        String sReturn = "";
        boolean bLoop = true;
        while (bLoop == true){
            if (prompt != null)
                System.out.println(prompt);
            try {
                sReturn = bread.readLine();
                bLoop = (check && (sReturn.length() < 1));
            } catch (Exception ex) {
                sReturn = ex.getMessage();
                System.out.println("Error - " + ex.getMessage());
            }
        }
        System.out.println("!!! Pop - MyInput::GetUserStr()");
        return sReturn;
    }
}
