package src;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;


public class W7Main {
    public static void main(String[] args) {
//        try {
//            File myObj = new File("file.txt");
//            if (myObj.createNewFile()){
//                System.out.println("File created: " + myObj.getName());
//            } else {
//                System.out.println("File already exists.");
//            }
//        } catch (IOException e) {
//            System.out.println("An error occurred.");
//            e.printStackTrace();
//        }
//        try {
//            FileWriter myWriter = new FileWriter("file.txt");
//            myWriter.write("Hello my name is Sheridan, wow it worked");
//            myWriter.close();
//            System.out.println("Successfully written");
//        } catch (IOException e) {
//            System.out.println("An error occurred.");
//            e.printStackTrace();
//        }
//        try {
//            File myObj = new File("file.txt");
//            Scanner reader = new Scanner(myObj);
//            while (reader.hasNextLine()){
//                String data = reader.nextLine();
//                System.out.println(data);
//            }
//        } catch (FileNotFoundException e) {
//            System.out.println("An error occurred");
//        }

//        File myObj = new File("file.txt");
//        if (myObj.exists()){
//            System.out.println("File name: " + myObj.getName());
//            System.out.println("Absolute path: " + myObj.getAbsolutePath());
//            System.out.println("Writeable: " + myObj.canWrite());
//            System.out.println("Readable: " + myObj.canRead());
//            System.out.println("File size in bytes " + myObj.length());
//        } else {
//            System.out.println("The file does not exist.");
//        }
   }
}