public interface IBrakable {
    void Brake();
}
