public class W5Main {
    public static void main(String[] args) {
        DoWork work = new DoWork();
        work.workArea();
    }
}
