import java.util.Random;

public class Car implements IVehicle{
    int Speed = 0;

    public int random(int min, int max) {
        Random random = new Random();
        Integer randInt = random.nextInt((max - min) + 1) + min;
        return randInt;
    }

    @Override
    public void Brake() {
        setSpeed(this.Speed -= random(5,20));
    }

    @Override
    public void Accelerate() {
        setSpeed(this.Speed += random(5,20));
    }

    @Override
    public void setSpeed(int speed) {
        this.Speed = speed;
        if (this.Speed < 0){
            this.Speed = 0;
        }
        if(this.Speed > 120){
            this.Speed = 120;
        }
    }

    @Override
    public String toString() {
        return "Car " + "\nSpeed = " + Speed;
    }
}
