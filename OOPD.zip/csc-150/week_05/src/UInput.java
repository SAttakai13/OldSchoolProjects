import java.io.BufferedReader;
import java.io.InputStreamReader;

public class UInput {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));

    //gets user string input
    public String UserString(String prompt) {
        System.out.println(prompt);
        String sReturn = "";
        try {
            sReturn = bread.readLine();
        } catch (Exception ex) {
            sReturn = ex.getMessage();
        }
        return sReturn;
    }
    //turns user input into a int
    public int UserInt(String prompt) {
        int iReturn = -1;
        while ((iReturn < 0))
            try {
                iReturn = Integer.parseInt(UserString(prompt));
            } catch (Exception ex) {
                // TODO
                System.out.println("Invalid value, re-enter value.");
            }
        return iReturn;
    }
}
