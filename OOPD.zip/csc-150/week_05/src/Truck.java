import java.util.Random;

public class Truck implements IVehicle{
    int Speed = 0;
    public int random(int min, int max) {
        Random random = new Random();
        Integer randInt = random.nextInt((max - min) + 1) + min;
        return randInt;
    }
    //make random generator to do different speeds

    @Override
    public void Brake() {
        setSpeed(this.Speed - random(5, 20));
        // slow down vehicle
        //Validate not less than 0

    }

    @Override
    public void Accelerate() {
        setSpeed(this.Speed + random(5, 20));
        // increase speed
        //validate max speed
    }


    @Override
    public void setSpeed(int speed) {
        this.Speed = speed;
        if (this.Speed < 0){
            this.Speed = 0;
        }
        if(this.Speed > 120){
            this.Speed = 120;
        }
    }

    @Override
    public String toString() {
        return "Truck" + "\nSpeed = " + Speed;
    }
}
