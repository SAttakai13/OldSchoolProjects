public interface IVehicle extends IBrakable, IAcceleratable {

    void setSpeed (int Speed);
}
