import java.util.ArrayList;

public class DoWork {
    UInput get = new UInput();
    int option = 0;
    ArrayList<IVehicle> vList = new ArrayList<IVehicle>();


    public void workArea(){
        while (option != 8){
            printList();
            option = get.UserInt("Choose vehicle to add:\n1. Add Truck\n2. Add Car\n3. Add SUV\n4. Add Motorcycle\n5. Speed up\n6. Slow down\n7. Set speed all\n8. Exit");
            switch (option){
                case 1:
                    vList.add(new Truck());
                    break;
                case 2:
                    vList.add(new Car());
                    break;
                case 3:
                    vList.add(new SUV());
                    break;
                case 4:
                    vList.add(new Motorcycle());
                    break;
                case 5:
                    SpeedUP();
                    break;
                case 6:
                    BrakeAll();
                    break;
                case 7:
                    setSpeedall(get.UserInt("What is your desired speed?\n"));
                    break;
            }
            System.out.println("See ya! Vroom vroom\n");
        }
    }

    public void SpeedUP(){
        for (int num = 0; num < vList.size(); num++){
            vList.get(num).Accelerate();
        }
    }
    public void BrakeAll(){
        for (int num =0; num < vList.size(); num++){
            vList.get(num).Brake();
        }
    }
    public void setSpeedall(int speed){
        for (int num = 0; num < vList.size(); num++){
            vList.get(num).setSpeed(speed);
        }
    }
    public void printList(){
        for (int num = 0; num < vList.size(); num++){
            System.out.println(num + ". " + vList.get(num).toString() + "\n");
        }
    }

}
