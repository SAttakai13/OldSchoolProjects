public interface IAcceleratable {
    void Accelerate();
}
