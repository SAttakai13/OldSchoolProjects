public class Dog extends Animal{
    public String breed;
    public void Fetch(){
        this.breed = "";
        super.age = 5;
        //super.Feed();

    }
}
