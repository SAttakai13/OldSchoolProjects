public class SomethingClass {
    public void WashAnimal(Animal animal){
        //Do stuff

    }
}
