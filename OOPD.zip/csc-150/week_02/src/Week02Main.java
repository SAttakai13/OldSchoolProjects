import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Week02Main {
    public static void main(String[] args) {
//        Dog dog = new Dog();
//        dog.age = 15;
//        SomethingClass something = new SomethingClass();
//
//        something.WashAnimal(dog);

        Date dob = new Date();
        System.out.println("Date value = " + dob.getTime());

        Calendar cal = Calendar.getInstance();
        cal.set(2022, 1, 13);

        Calendar gCal = new GregorianCalendar(1970, 12, 25);
        System.out.println("Year = " + gCal.get(Calendar.YEAR));

        LocalDate id = LocalDate.now();
        LocalDate id2 = LocalDate.of(2001, 2, 2);

        LocalTime lt = LocalTime.now();


    }
}
