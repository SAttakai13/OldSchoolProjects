public class Animal{
    public String name;
    public int age;

    protected void Feed(){

    }
}
