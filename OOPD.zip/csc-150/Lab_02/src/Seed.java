import java.util.ArrayList;

public class Seed {
    ArrayList<Course> courseName = new ArrayList<Course>();
    ArrayList<Student>students = new ArrayList<Student>();
    ArrayList<Staff>advocates = new ArrayList<Staff>();
    ArrayList<Faculty>newTeachers = new ArrayList<Faculty>();
    ArrayList<String> officeHrs = new ArrayList<String>();
    public void genData(College col){
        String officeHrs1 = "MTWHF 8 am - 5 pm";
        String officeHrs2 = "TWHF 8 am - 5 pm";
        String officeHrs3 = "MTHF 8 am - 5 pm";
        String officeHrs4 = "MTWF 8 am - 5 pm";
        String officeHrs5 = "MTWH 8 am - 5 pm";

        Course course1 = new Course("Networking I", "ITH-215");
        Course course2 = new Course("Intro to CS", "CSC-105");
        Course course3 = new Course("Modern Operating Systems", "CSC-150");
        Course course4 = new Course("Intro to TM", "TM-201");
        Course course5 = new Course("Intro to Web","CSC-210");

        Staff advocate1 = new Staff("Danelle Afton", 28, "Advocate");
        Staff advocate2 = new Staff("John Smith", 29, "Advocate");

        Student student1 = new Student("Danni Spoon", 21, 2.89);
        Student student2 = new Student("Sarah Bell", 20, 3.9);
        Student student3 = new Student("Felix Cat", 16, 3.98);
        Student student4 = new Student("Kyle Lyle", 27, 2.5);

        Faculty teacher1 = new Faculty("Thomas Engine", 45, 312,true, 90000);
        Faculty teacher2 = new Faculty("Charles Xavier", 37, 313, false, 80000);
        Faculty teacher3 = new Faculty("Wade Wilson", 60, 314, true, 90000);


        //Adding values to the arraylists
        officeHrs.add(officeHrs1);
        officeHrs.add(officeHrs2);
        officeHrs.add(officeHrs3);
        officeHrs.add(officeHrs4);
        officeHrs.add(officeHrs5);

        courseName.add(course1);
        courseName.add(course2);
        courseName.add(course3);
        courseName.add(course4);
        courseName.add(course5);

        advocates.add(advocate1);
        advocates.add(advocate2);

        students.add(student1);
        students.add(student2);
        students.add(student3);
        students.add(student4);

        newTeachers.add(teacher1);
        newTeachers.add(teacher2);
        newTeachers.add(teacher3);

        col.setFaculty(newTeachers);
        col.setClasses(courseName);
        col.setStudents(students);
        col.setStaff(advocates);

        //Add courses to students
        student1.AddCourse(course1);
        student1.AddCourse(course4);
        student2.AddCourse(course2);
        student2.AddCourse(course5);
        student3.AddCourse(course4);
        student3.AddCourse(course3);
        student4.AddCourse(course1);
        student4.AddCourse(course4);
        student4.RemoveCourse(course4);
        student4.AddCourse(course3);

        //Set advocates to students
        student1.setAdvocate(advocate1);
        student2.setAdvocate(advocate2);
        student3.setAdvocate(advocate2);
        student4.setAdvocate(advocate1);

        //Add courses to faculty
        teacher1.AddCourse(course1);
        teacher1.AddCourse(course4);
        teacher2.AddCourse(course2);
        teacher2.AddCourse(course5);
        teacher3.AddCourse(course3);
        teacher3.AddCourse(course4);

        //Office hours to advocate
        advocate1.AddOfficeHrs(officeHrs1);
        advocate2.AddOfficeHrs(officeHrs1);

        //Office hours to staff
        teacher1.AddOfficeHrs(officeHrs2);
        teacher2.AddOfficeHrs(officeHrs3);
        teacher3.AddOfficeHrs(officeHrs4);

    }
}
