public class Main {
    public static void main(String[] args) {
        Seed seed = new Seed();
        College col = new College();
        seed.genData(col);
        System.out.println(col);
    }
}
