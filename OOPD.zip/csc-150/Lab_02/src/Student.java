import java.util.ArrayList;

public class Student extends Person{
    private double GPA;
    private Staff advocate;
    private ArrayList<Course> courseLoad = new ArrayList<Course>();

    public Student(String name, int age, double GPA){
        super(name, age);
        setGPA(GPA);
        setAdvocate(advocate);
    }

    public void AddCourse(Course course){this.courseLoad.add(course);}
    public void RemoveCourse(Course course){this.courseLoad.remove(course);}

    public double getGPA() {return GPA;}
    public void setGPA(double GPA) {this.GPA = GPA;}

    public ArrayList<Course> getCourseLoad() {return courseLoad;}
    public void setCourseLoad(ArrayList<Course> courseLoad) {this.courseLoad = courseLoad;}

    public Staff getAdvocate() {return advocate;}
    public void setAdvocate(Staff advocate) {this.advocate = advocate;}

    @Override
    public String toString() {
        return "\nStudent{" + " Name= '" + name + '\'' + "\nAge= " + age + "\nGPA= " + GPA + "\nAdvocate= " + advocate + "\nClasses= " + courseLoad + '}' + "\n";
    }
}
