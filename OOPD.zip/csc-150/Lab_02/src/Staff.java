import java.util.ArrayList;

public class Staff extends Person{
    private String jobTitle;
    private ArrayList<String> officeHrs = new ArrayList<String>();

    public Staff(String name, int age, String job){
        super(name, age);
        this.jobTitle = job;
    }

    public Staff(String name, int age) {
        super(name, age);
    }

    public void AddOfficeHrs(String officeHrs){this.officeHrs.add(officeHrs);}
    public void RemoveOfficeHrs(String officeHrs){this.officeHrs.remove(officeHrs);}


    @Override
    public String toString() {
        return "\nStaff {" + " Name= '" + name + '\'' + "\nAge= " + age + "\nJob Title= '" + jobTitle + '\'' + "\nOffice Hours= " + officeHrs + '}' + "\n";
    }
}
