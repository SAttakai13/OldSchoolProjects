import java.util.ArrayList;

public class College {
    private ArrayList<Student> Students;
    private ArrayList<Faculty> faculty;
    private ArrayList<Staff> staff;
    private ArrayList<Course> classes;

    public ArrayList<Course> getClasses() {return classes;}
    public void setClasses(ArrayList<Course> classes) {this.classes = classes;}

    public ArrayList<Student> getStudents() {return Students;}
    public void setStudents(ArrayList<Student> students) {Students = students;}

    public ArrayList<Faculty> getFaculty() {return faculty;}
    public void setFaculty(ArrayList<Faculty> faculty) {this.faculty = faculty;}

    public ArrayList<Staff> getStaff() {return staff;}
    public void setStaff(ArrayList<Staff> staff) {this.staff = staff;}


    @Override
    public String toString() {
        return "College {" + "Students=" + Students + "\nFaculty=" + faculty + "\nStaff=" + staff + "\nClasses=" + classes + '}';
    }
}

