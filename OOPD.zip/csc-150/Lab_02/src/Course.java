public class Course {
    private String courseName;
    private String courseNum;

    public Course(String courseName, String courseNum){
        this.courseName = courseName;
        this.courseNum = courseNum;
    }

    @Override
    public String toString() {
        return "\nCourse{" + "Course = '" + courseName + '\'' + "\nCourse Number = '" + courseNum + '\'' + '}' + "\n";
    }
}
