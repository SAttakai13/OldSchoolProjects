import java.util.ArrayList;

public class Faculty extends Person{
    private int officeNum;
    private ArrayList<String> officeHrs = new ArrayList<String>();
    private ArrayList<Course> classTeach = new ArrayList<Course>();
    private boolean fulltime;
    private int salary;

    public Faculty(String name, int age, int officeNum, boolean fulltime, int salary) {
        super(name, age);
        this.officeNum = officeNum;
        this.fulltime = fulltime;
        this.salary = salary;
    }

    public void AddOfficeHrs(String officeHrs){this.officeHrs.add(officeHrs);}
    public void RemoveOfficeHrs(String officeHrs){this.officeHrs.remove(officeHrs);}

    public void AddCourse(Course course){this.classTeach.add(course);}
    public void RemoveCourse(Course course){this.classTeach.remove(course);}

    public int getOfficeNum() {return officeNum;}
    public void setOfficeNum(int officeNum) {this.officeNum = officeNum;}

    public ArrayList<Course> getClassTeach() {return classTeach;}
    public void setClassTeach(ArrayList<Course> classTeach) {this.classTeach = classTeach;}

    public boolean isFulltime() {return fulltime;}
    public void setFulltime(boolean fulltime) {this.fulltime = fulltime;}

    public int getSalary() {return salary;}
    public void setSalary(int salary) {this.salary = salary;}

    @Override
    public String toString() {
        return "\nTeacher {" + " Name = '" + name + '\'' + "\nBirthdate = '" + age + '\'' + "\nOffice Number = " + officeNum +
                "\nOffice Hours = " + officeHrs + "\nCourse Teach = " + classTeach + "\nFull-time = " + fulltime + "\nSalary = " + salary + '}' + "\n";
    }
}
