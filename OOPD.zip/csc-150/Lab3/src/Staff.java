import java.util.ArrayList;

public class Staff extends Person{
    //properties
    private String jobTitle;
    private ArrayList<String> officeHrs = new ArrayList<String>();

    //Constructors and overloaded constructors (ahhhhh! My brain go melty melty)
    public Staff(){

    }
    public Staff(String name, int age, String job){
        super(name, age);
        this.jobTitle = job;
    }

    public Staff(String name, int age) {
        super(name, age);
    }


    //getters and setters
    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    //adding and removing stuff
    public void AddOfficeHrs(String officeHrs){this.officeHrs.add(officeHrs);}
    public void RemoveOfficeHrs(String officeHrs){this.officeHrs.remove(officeHrs);}

    //toString method
    @Override
    public String toString() {
        return "\nStaff {" + " Name= '" + name + '\'' + "\nAge= " + age + "\nJob Title= '" + jobTitle + '\'' + "\nOffice Hours= " + officeHrs + '}' + "\n";
    }
}
