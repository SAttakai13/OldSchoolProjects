public class Person {
    //properties
    protected String name;
    protected int age;

    //constructors and overloaded constructors (oh boi, ahhhh.... So time consuming. *sigh* I need to keep going
    public Person(){

    }
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    //getters and setters
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}

    public int getAge() {return age;}
    public void setAge(int age) {this.age = age;}
}
