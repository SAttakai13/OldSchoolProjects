import java.util.ArrayList;

public class MenuManager {
    private ArrayList<College> school = new ArrayList<>();
    UInput get = new UInput();

    public void WorkArea(){
        int UserNum = 0;
        while (UserNum != 4){
            //Menu loop
            System.out.println("College:\n1. Add College\n2. Remove College\n3. Edit College\n4. Exit");
            UserNum = get.UserInt("Insert number according to your goal, if you want nothing then exit.");
            //Select option
            switch(UserNum){
                case 1:
                    addSchool();
                    break;
                case 2:
                    removeSchool();
                    break;
                case 3:
                    editSchool();
                    break;
            }
        }

    }
    public void doStudent(College newCollege, int UserNum){
        //Creates a new student for adding a college
        for (int i = 0; i < UserNum; i++){
            Student student = new Student();
            student.setName(get.UserString("Name your student: "));
            student.setAge(get.UserInt("Age: "));
            student.setGPA(get.UserDouble("GPA: "));
            newCollege.getStudents().add(student);
        }
    }
    public void doFaculty(College newCollege, int UserNum){
        //Creates a new teacher for adding a college
        for (int i = 0; i < UserNum; i++){
            Faculty teachers = new Faculty();
            teachers.setName(get.UserString("Teachers name: "));
            teachers.setAge(get.UserInt("Age: "));
            teachers.setOfficeNum(get.UserInt("Office number: "));
            teachers.setFulltime(get.UserString("Full-time or Part-time: "));
            teachers.setSalary(get.UserInt("Salary: "));
            newCollege.getFaculty().add(teachers);
        }
    }
    public void doStaff(College newCollege, int UserNum){
        //Creates a new staff for adding a college
        for (int i = 0; i < UserNum; i++){
            Staff advocates = new Staff();
            advocates.setName(get.UserString("Name: "));
            advocates.setAge(get.UserInt("Age: "));
            advocates.setJobTitle(get.UserString("Job: "));
            newCollege.getStaff().add(advocates);
        }
    }
    public void doCourses(College newCollege, int UserNum){
        //Creates a new course for adding a college
        for (int i = 0; i < UserNum; i++){
            Course classes = new Course();
            classes.setCourseName(get.UserString("Course name: "));
            classes.setCourseNum(get.UserString("Course number: "));
            newCollege.getClasses().add(classes);
        }
    }
    public void addSchool(){
        int select = get.UserInt("1. Add College\n2. Exit");
        if (select == 1){
            //Generate add college menu
            // Name
            College newCollege = new College();
            newCollege.setName(get.UserString("College name: "));
            // Add students
            select = get.UserInt("Number of Students you want to add: ");
            doStudent(newCollege, select);
            // Add faculty
            select = get.UserInt("Number of teachers you want to add: ");
            doFaculty(newCollege, select);
            // Add staff
            select = get.UserInt("Number of advocates you want to add: ");
            doStaff(newCollege, select);
            // Add course
            select = get.UserInt("Number of courses you want to add: ");
            doCourses(newCollege, select);

            school.add(newCollege);
        } else if (select == 2){
            return;
        }
    }

    public void removeSchool(){
        int select = get.UserInt("1. Delete college\n2. Exit");
        if (select == 1){
            // List college Arraylist
            for (int i = 0; i < school.size(); i++) {
                System.out.println(i + ". " +school.get(i).getName());
            }
            // Type in number of college
            select = get.UserInt("Choose College to delete: ");
            // Prompt user : "are you sure you want to remove (college name)? Y/N"
            String choice = get.UserString("Sure you want to delete?\n Y\\N ");
            if (choice.equals("Y")){
                school.remove(select);
            } else if (choice.equals("N")){
                return;
            } else {
                removeSchool();
            }
        } else if  (select == 2) {
            return;
        }

    }
    public void editSchool(){
        // List college Arraylist
        // Type in number of college
        int select = get.UserInt("1. Edit College\n2. Exit");
        if (select == 1){
            //Select College you want to edit
            for (int i = 0; i < school.size(); i++) {
                System.out.println(i + ". " + school.get(i).getName());
                select = get.UserInt( "\nWhich college would you like to edit? ");
            }
            //Select what subcatagory you want to edit
            College college = school.get(select);
            System.out.println(college.getName() + ":\n1. Students\n2. Faculty\n3. Staff\n4. Courses\n5. Exit");
            select = get.UserInt("Enter a number");
            while (select != 5) {
                switch (select){
                    case 1:
                        students(college);
                        break;
                    case 2:
                        faculty(college);
                        break;
                    case 3:
                        staff(college);
                        break;
                    case 4:
                        course(college);
                        break;
                }
            }
        } else if (select == 2){
            return;
        }



    }
    //Students list
    public void students(College college){
        //Options select
        int select = 0;
        while (select != 4){
            System.out.println("1. Add students\n2. Delete students\n3. Edit students\n4. exit");
            select = get.UserInt("Enter number");
            switch (select){
                case 1:
                    //Add student
                    Student newStudent = new Student();
                    newStudent.setName(get.UserString("Enter student name: "));
                    newStudent.setAge(get.UserInt("Enter age: "));
                    newStudent.setGPA(get.UserDouble("Enter GPA: "));
                    college.getStudents().add(newStudent);
                    break;
                case 2:
                    //Delete Student
                    for (int i = 0; i < college.getStudents().size(); i++){
                        System.out.println(i + ". " + college.getStudents().get(i).getName());
                    }
                    college.getStudents().remove(get.UserInt("Enter student number: "));
                break;
                case 3:
                    //Edit Student
                    for (int i = 0; i < college.getStudents().size(); i++){
                        System.out.println(i + ". " + college.getStudents().get(i).getName());
                    }
                    Student student = college.getStudents().get(get.UserInt("Student you want to edit: "));
                    student.setName(get.UserString("Rename: "));
                    student.setAge(get.UserInt("Age: "));
                    student.setGPA(get.UserDouble("GPA: "));
                    break;
            }
        }
    }
    //Faculty list
    public void faculty(College college){
        //selecting options
        int select = 0;
        while (select != 4){
            System.out.println("1. Add faculty\n2. Delete faculty\n3. Edit faculty\n4. exit");
            select = get.UserInt("Enter number");
            switch (select){
                case 1:
                    //Add teachers
                    Faculty newTeacher = new Faculty();
                    newTeacher.setName(get.UserString("Enter student name: "));
                    newTeacher.setAge(get.UserInt("Enter age: "));
                    newTeacher.setOfficeNum(get.UserInt("Office number: "));
                    newTeacher.setFulltime(get.UserString("Are they full-time or part-time? "));
                    newTeacher.setSalary(get.UserInt("Enter salary value (Do be generous, teachers work very hard): "));
                    college.getFaculty().add(newTeacher);
                    break;
                case 2:
                    //Delete teachers
                    for (int i = 0; i < college.getFaculty().size(); i++){
                        System.out.println(i + ". " + college.getFaculty().get(i).getName());
                    }
                    college.getFaculty().remove(get.UserInt("Enter teacher number: "));
                    break;
                case 3:
                    //Edit teachers
                    for (int i = 0; i < college.getFaculty().size(); i++){
                        System.out.println(i + ". " + college.getFaculty().get(i).getName());
                    }
                    Faculty teacher = college.getFaculty().get(get.UserInt("Teacher you want to edit: "));
                    teacher.setName(get.UserString("Rename: "));
                    teacher.setAge(get.UserInt("Age: "));
                    teacher.setOfficeNum(get.UserInt("Office number: "));
                    teacher.setFulltime(get.UserString("Are they full-time or part-time? "));
                    teacher.setSalary(get.UserInt("Enter salary value (Do be generous, teachers work very hard): "));
                    break;
            }
        }
    }
    //Staff list
    public void staff(College college){
        //Options select
        int select = 0;
        while (select != 4){
            System.out.println("1. Add staff\n2. Delete staff\n3. Edit staff\n4. exit");
            select = get.UserInt("Enter number");
            switch (select){
                case 1:
                    //Add staff
                    Staff newStaff = new Staff();
                    newStaff.setName(get.UserString("Enter staff name: "));
                    newStaff.setAge(get.UserInt("Enter age: "));
                    newStaff.setJobTitle(get.UserString("Enter Job title: "));
                    college.getStaff().add(newStaff);
                    break;
                case 2:
                    //Delete Staff
                    for (int i = 0; i < college.getStaff().size(); i++){
                        System.out.println(i + ". " + college.getStaff().get(i).getName());
                    }
                    college.getStaff().remove(get.UserInt("Enter staff number: "));
                    break;
                case 3:
                    //Edit Staff
                    for (int i = 0; i < college.getStaff().size(); i++){
                        System.out.println(i + ". " + college.getStaff().get(i).getName());
                    }
                    Staff staff = college.getStaff().get(get.UserInt("Staff you want to edit: "));
                    staff.setName(get.UserString("Enter staff name: "));
                    staff.setAge(get.UserInt("Enter age: "));
                    staff.setJobTitle(get.UserString("Enter Job title: "));
                    break;
            }
        }
    }
    //Course list
    public void course(College college){
        //Options select
        int select = 0;
        while (select != 4){
            System.out.println("1. Add course\n2. Delete course\n3. Edit course\n4. exit");
            select = get.UserInt("Enter number");
            switch (select){
                case 1:
                    //Add course
                    Course newCourse = new Course();
                    newCourse.setCourseName(get.UserString("Course name"));
                    newCourse.setCourseNum(get.UserString("Course number: "));
                    college.getClasses().add(newCourse);
                    break;
                case 2:
                    //Delete Course
                    for (int i = 0; i < college.getClasses().size(); i++){
                        System.out.println(i + ". " + college.getClasses().get(i).getCourseName());
                    }
                    college.getClasses().remove(get.UserInt("Enter Course number: "));
                    break;
                case 3:
                    //Edit course
                    for (int i = 0; i < college.getClasses().size(); i++){
                        System.out.println(i + ". " + college.getClasses().get(i).getCourseName());
                    }
                    Course course = college.getClasses().get(get.UserInt("Course you want to edit: "));
                    course.setCourseName(get.UserString("Course name"));
                    course.setCourseNum(get.UserString("Course number: "));
                    break;
            }
        }
    }


}