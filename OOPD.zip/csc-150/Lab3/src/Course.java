public class Course {
    // F%#K!!!!!!!!!!! .... properties
    private String courseName;
    private String courseNum;

    //Constructors and overloaded constructors (Welp there goes my sanity)
    public Course(){

    }
    public Course(String courseName, String courseNum){
        this.courseName = courseName;
        this.courseNum = courseNum;
    }

    //Getters n setters
    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseNum() {
        return courseNum;
    }

    public void setCourseNum(String courseNum) {
        this.courseNum = courseNum;
    }

    //toString
    @Override
    public String toString() {
        return "\nCourse{" + "Course = '" + courseName + '\'' + "\nCourse Number = '" + courseNum + '\'' + '}' + "\n";
    }
    //Congrats!!! *drumroll* You earned the loss of sanity trophy! You can't feel anything anymore heheheheh... Alright, I'm done.
}
