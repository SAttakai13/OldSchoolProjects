public class Main {
    public static void main(String[] args) {
        //New instance of menu
        MenuManager menu = new MenuManager();
        //creates work area
        menu.WorkArea();
    }
}
