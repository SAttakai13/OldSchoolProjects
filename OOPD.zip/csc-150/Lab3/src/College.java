import java.util.ArrayList;

public class College {
    //properties and arraylists
    private String name;
    private ArrayList<Student> Students = new ArrayList<>();
    private ArrayList<Faculty> faculty = new ArrayList<>();
    private ArrayList<Staff> staff = new ArrayList<>();
    private ArrayList<Course> classes = new ArrayList<>();


    //getter and setters (ahhhh!!!!!! I'm tired T-T)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Course> getClasses() {return classes;}
    public void setClasses(ArrayList<Course> classes) {this.classes = classes;}

    public ArrayList<Student> getStudents() {return Students;}
    public void setStudents(ArrayList<Student> students) {Students = students;}

    public ArrayList<Faculty> getFaculty() {return faculty;}
    public void setFaculty(ArrayList<Faculty> faculty) {this.faculty = faculty;}

    public ArrayList<Staff> getStaff() {return staff;}
    public void setStaff(ArrayList<Staff> staff) {this.staff = staff;}

    //toStringMethod
    @Override
    public String toString() {
        return "College{" +
                "name='" + name + '\'' +
                ", Students=" + Students +
                ", faculty=" + faculty +
                ", staff=" + staff +
                ", classes=" + classes +
                '}';
    }
}
