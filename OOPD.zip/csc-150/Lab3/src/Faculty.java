import java.util.ArrayList;

public class Faculty extends Person{
    //properties... Is this the last one?!
    private int officeNum;
    private ArrayList<String> officeHrs = new ArrayList<String>();
    private ArrayList<Course> classTeach = new ArrayList<Course>();
    private String fulltime;
    private int salary;

    //Constructors and overloaded constructors (ahhhhh! My brain go melty melty, we are almost done)
    public Faculty(){

    }
    public Faculty(String name, int age, int officeNum, String fulltime, int salary) {
        super(name, age);
        this.officeNum = officeNum;
        this.fulltime = fulltime;
        this.salary = salary;
    }

    //adding and removing stuff
    public void AddOfficeHrs(String officeHrs){this.officeHrs.add(officeHrs);}
    public void RemoveOfficeHrs(String officeHrs){this.officeHrs.remove(officeHrs);}

    public void AddCourse(Course course){this.classTeach.add(course);}
    public void RemoveCourse(Course course){this.classTeach.remove(course);}

    //getters and setters
    public int getOfficeNum() {return officeNum;}
    public void setOfficeNum(int officeNum) {this.officeNum = officeNum;}

    public ArrayList<Course> getClassTeach() {return classTeach;}
    public void setClassTeach(ArrayList<Course> classTeach) {this.classTeach = classTeach;}

    public String getFulltime() {return fulltime;}
    public void setFulltime(String fulltime) {this.fulltime = fulltime;}

    public int getSalary() {return salary;}
    public void setSalary(int salary) {this.salary = salary;}

    //toString method
    @Override
    public String toString() {
        return "\nTeacher {" + " Name = '" + name + '\'' + "\nBirthdate = '" + age + '\'' + "\nOffice Number = " + officeNum +
                "\nOffice Hours = " + officeHrs + "\nCourse Teach = " + classTeach + "\nFull-time = " + fulltime + "\nSalary = " + salary + '}' + "\n";
    }
}
