public class Dog extends Animal {
    //protected variables
    protected String someString;
    protected String breed;
    protected boolean neutered;


    //constructors
    public Dog(){}
    public Dog(String someString, String name, String breed, int aveSize, boolean neutered){
        super(aveSize);
        super.name = name;
        setSomeString(someString);
        setBreed(breed);
        setNeutered(neutered);
    }

    // it overrides the AveSize from the parent class
    @Override
    public void setAveSize(int aveSize){
        if (aveSize < 5) {
            super.aveSize = 5;
        }
        if (aveSize < 20) {
            super.setAveSize(20);
        }
    }

    //getters and setters :D
    public boolean isNeutered() {return neutered;}
    public void setNeutered(boolean neutered) {this.neutered = neutered;}

    public String getSomeString() {return someString;}
    public void setSomeString(String someString) {this.someString = someString;}

    public String getBreed() {return breed;}
    public void setBreed(String breed) {this.breed = breed;}


    //overriding and loading methods
    @Override
    public void myMethod(){super.myMethod();}

    @Override
    public String toString() {
        return "Dog{" +
                "someString='" + someString + " Its name is " + name +
                ", breed='" + breed + '\'' +
                ", neutered=" + neutered +
                '}';
    }
}