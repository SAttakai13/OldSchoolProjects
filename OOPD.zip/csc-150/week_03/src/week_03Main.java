public class week_03Main {
    public static void main(String[] args) {

        //Instances
        Animal animal = new Animal("Talson", 4, 4);
        Dog spot = new Dog("This a woofer, ","Toby","Labrador", 7, true);
        Dog rover = new Dog("This is a doggo, ","Jack", "German Shepard", 4, true);

        System.out.println(spot);
        System.out.println(rover);

        System.out.println(animal);
    }
}
