import java.util.Calendar;
import java.util.GregorianCalendar;

public class Animal {

    //protected variables
    protected String name;
    protected Calendar dob;
    protected int aveSize;
    protected int legs;

    //Constructors
    public Animal(){}
    public Animal(int aveSize){this.aveSize = aveSize;}
    public Animal(String name, int aveSize, int legs){
        this.legs = legs;
        this.aveSize = aveSize;
        this.name = name;
    }

    public void myMethod(){}

    //setter for aveSize
    public void setAveSize(int aveSize) {this.aveSize = aveSize;}

    //toString override
    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                ", dob=" + dob +
                ", aveSize=" + aveSize +
                ", legs=" + legs +
                '}';
    }
}
