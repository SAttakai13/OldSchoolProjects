package lib;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

public class ConsoleIO {

	/**
	 * Generates a prompt that allows the user to enter any response and returns the String.
	 * This method does not allow empty or blank input when allowBlank is false.
	 * This method never accepts null.
	 * @param prompt - the prompt to be displayed to the user.
	 * @param allowBlank - determines whether empty or blank inputs are valid.
	 * @return the input from the user as a String
	 */
	public static String promptForString(String prompt, boolean allowBlank) {
		if(prompt == null || prompt.isEmpty()){
			throw new IllegalArgumentException("The prompt cannot be null, empty, or white space. prompt=" + prompt);
		}

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String input = null;
		boolean inputIsInvalid = true;

		do{
			System.out.print(prompt);
			try {
				input = br.readLine();
				inputIsInvalid = input == null || (!allowBlank && input.isEmpty());

				if(inputIsInvalid){
					System.out.println("Your input was invalid. Please, try again.");
				}
			} catch(IOException ioe){
				System.out.println("There was a problem and your input was not received. Please, try again.");
			}

		} while(inputIsInvalid);

		return input;
	}
	
	/**
	 * Generates a prompt that expects a numeric input representing an int value.
	 * This method loops until valid input is given.
	 * @param prompt - the prompt to be displayed to the user
	 * @param min - the inclusive minimum boundary
	 * @param max - the inclusive maximum boundary
	 * @return the int value
	 */
	public static int promptForInt(String prompt, int min, int max){
		if(min > max){
			throw new IllegalArgumentException("The min cannot be greater than the max. min=" + min + "; max=" + max);
		}

		int num = -1;
		boolean numIsInvalid = true;

		do{
			String input = promptForString(prompt, false);
			try{
				num = Integer.parseInt(input);
				numIsInvalid = num < min || num > max;
			} catch(NumberFormatException nfe){
				//No need to do anything here
			}

			if(numIsInvalid){
				System.out.println("You must enter a whole number between " + min + " and " + max + ". Please, try again.");
			}
		}while(numIsInvalid);

		return num;
	}
	
	/**
	 * Generates a prompt that expects the user to enter one of two responses that will equate
	 * to a boolean value. The trueString represents the case insensitive response that will equate to true. 
	 * The falseString acts similarly, but for a false boolean value.
	 * 		Example: Assume this method is called with a trueString argument of "yes" and a falseString argument of
	 * 		"no". If the enters "YES", the method returns true. If the user enters "no", the method returns false.
	 * 		All other inputs are considered invalid, the user will be informed, and the prompt will repeat.
	 * @param prompt - the prompt to be displayed to the user
	 * @param trueString - the case insensitive value that will evaluate to true
	 * @param falseString - the case insensitive value that will evaluate to false
	 * @return the boolean value
	 */
	public static boolean promptForBoolean(String prompt, String trueString, String falseString){
		boolean bValue = false;
		boolean booleanIsInvalid = true;
		do{
			String input = promptForString(prompt + "\nAnswer: " + trueString +" | "+ falseString, false);
			if (input.toLowerCase(Locale.ROOT).equals(trueString)){
				bValue = true;
				booleanIsInvalid = false;
			} else if (input.toLowerCase(Locale.ROOT).equals(falseString)){
				bValue = false;
				booleanIsInvalid = false;
			}
		} while (booleanIsInvalid);

		return bValue;
	}

	/**
	 * Generates a console-based menu using the Strings in options as the menu items.
	 * Reserves the number 0 for the "quit" option when withQuit is true.
	 * @param options - Strings representing the menu options
	 * @param withQuit - adds option 0 for "quit" when true
	 * @return the int of the selection made by the user
	 */
	public static int promptForMenuSelection(String[] options, boolean withQuit){
		for (int i = 0; i < options.length; i++){
			System.out.println(i + ".) " + options[i]);
		}
		if (withQuit){
			System.out.println(options.length + ".) exit");
			return promptForInt("Choose an option", 0, options.length);
		}
		return promptForInt("Choose an option", 0, (options.length)-1);
	}

}
