package controllers;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class GuessingGame {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));

    // ///////////////////////////////////////////////
    public void play() {
        // *** Initialize
        boolean win = false;
        Random rng = new Random();
        int num1 = 10; // Set default value
        int num2 = 0;
        int maxNum = -1;
        String myValue;
        int iCount = 10;

        // Get difficulty
        while(maxNum < 0) {
            System.out.print("Select difficulty: Easy, Medium, Hard: ");
            // *** Set up
            // Get value from user
            myValue = GetString();
            if (myValue.equalsIgnoreCase("Easy") == true) {
                maxNum = 10;
            }
            if (myValue.equalsIgnoreCase("Medium") == true) {
                maxNum = 50;
            }
            if (myValue.equalsIgnoreCase("Hard") == true) {
                maxNum = 100;
            }
        }
        num1 = rng.nextInt(maxNum) + 1;
        System.out.println("num1 = " + num1); // For testing

        // *** Play loop
        while((win == false) && (iCount > 0)) {
            System.out.println("Guess a number between 1 and " + maxNum);
            num2 = GetInt();
            if(num2 > num1){
                System.out.println("Too high. \n");
            } else if(num2 < num1){
                System.out.println("Too low. \n");
            } else if(num2 == num1){
                System.out.println("You win!");
                win = true;
            }
            iCount--;
            System.out.println("Guesses remaining: " + iCount);
        }
        if (!win) {
            System.out.println("Tries exceeded - You lose!");
        }

    }
    // ///////////////////////////////////////
    private String GetString() {
        try {
            return bread.readLine();
        }
        catch (Exception ex) {
            // TODO something
        }
        return null;
    }
    // ///////////////////////////////////////
    private int GetInt() {
        try {
            return Integer.parseInt(GetString());
        }
        catch (Exception ex) {
            // TODO something
        }
        // Failed
        return -1;
    }

}