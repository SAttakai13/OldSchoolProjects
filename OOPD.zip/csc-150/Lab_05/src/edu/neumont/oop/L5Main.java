package edu.neumont.oop;

import edu.neumont.oop.Controller.*;

public class L5Main {
    public static void main(String[] args) {
        //workspace for do work
        DoWork work = new DoWork();
        work.work();
    }
}
