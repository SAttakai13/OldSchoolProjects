package edu.neumont.oop.View;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MyInput {
    private final BufferedReader bread = new BufferedReader(new InputStreamReader(System.in));

    //gets user string input
    public String GetUserStr(String prompt) {
        System.out.println(prompt);
        String sReturn = "";
        try {
            sReturn = bread.readLine();
        } catch (Exception ex) {
            sReturn = ex.getMessage();
            System.out.println("What are you doing? Put in a word >:|");
        }
        return sReturn;
    }
    //turns user input into an int
    public int GetUserInt(String prompt) {
        int iReturn = -1;
        while ((iReturn < 0))
            try {
                iReturn = Integer.parseInt(GetUserStr(prompt));
            } catch (Exception ex) {
                // TODO
                System.out.println("Invalid value, re-enter value.");
            }
        return iReturn;
    }
}
