package edu.neumont.oop.Controller;

public interface IStringEncryptable {
    //for encryption and decryption
    String encrypt(String phraseToEncrypt);
    String decrypt(String phraseToDecrypt);





}
