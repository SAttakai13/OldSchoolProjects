package edu.neumont.oop.Controller;

import edu.neumont.oop.View.MyInput;
import java.util.ArrayList;

public class DoWork {
    Doubler repeater = new Doubler();
    Cutter cut = new Cutter();
    VowelReplacer replacer = new VowelReplacer();
    CasearCipher cipher = new CasearCipher();
    MyInput get = new MyInput();

    String encvalue;
    String decvalue;

    ArrayList<IStringEncryptable> encryptList = new ArrayList<>();

    int option = 0;
    public void work() {
        while (option != 9) {
            switch (option = get.GetUserInt("Encrypt n Decrypt:\n1. Double\n2. Cut\n3. Replace vowels\n4. Cipher\n5. Encrypt\n6. Decrypt\n7. View List\n8. Clear List\n9. Exit")) {
                case 1:
                    //Add double
                    AddDouble();
                    break;
                case 2:
                    //Add cutter
                    AddCutter();
                    break;
                case 3:
                    //Add vowel replacer
                    AddVowelReplacer();
                    break;
                case 4:
                    //Add casear cipher
                    AddCipher();
                    break;
                case 5:
                    //Encrypt
                    encvalue = Encrypt();
                    break;
                case 6:
                    //Decrypt
                    decvalue = Decrypt(encvalue);
                    break;
                case 7:
                    //View list of encrypters
                    viewList();
                    break;
                case 8:
                    //Clear the list of encrypters
                    encryptList.clear();
                    break;
            }
            //case 9 for exiting
            System.out.println("Going so soon? Okie bye bye ^^");
        }
    }

    public void AddDouble(){
        //repeats the word and adds to the list
        encryptList.add(repeater);
    }
    public void AddCutter(){
        //slices the word in half and rounds down ands to the list
        encryptList.add(cut);
    }
    public void AddVowelReplacer(){
        //vowels are replaced and added to the list
        encryptList.add(replacer);
    }
    public void AddCipher(){
        //shifts letters by three and adds to the list
        encryptList.add(cipher);
    }

    public String Encrypt(){
        //Encrypts a word
        String userinput = get.GetUserStr("Encrypt String:\n");
        for (int encnum = 0; encnum < encryptList.size(); encnum++){
            userinput = encryptList.get(encnum).encrypt(userinput);
        }
        System.out.println(userinput);
        return userinput;
    }

    public String Decrypt(String val){
        //Decrypts the word that was encrypted
        for (int encnum = encryptList.size() - 1; encnum >= 0; encnum--){
            val = encryptList.get(encnum).decrypt(val);
        }
        System.out.println(val);
        return val;
    }

    public void viewList(){
        //view the list of encryptions
        for(int i = 0; i < encryptList.size(); i++){
            System.out.println(i + ". " + encryptList.get(i));
        }
    }



}
