package edu.neumont.oop.Controller;

public class Cutter implements IStringEncryptable{
    @Override
    public String encrypt(String phraseToEncrypt) {
        //slices the word into two and rounds off
        String str1;
        String str2;

        str1 = phraseToEncrypt.substring(phraseToEncrypt.length()/2);
        str2 = phraseToEncrypt.substring(0, (phraseToEncrypt.length()/2));
        phraseToEncrypt = str1 + str2;
        return phraseToEncrypt;
    }

    @Override
    public String decrypt(String phraseToDecrypt) {
        //rearranges the word in its original state
        String str1;
        String str2;

        if (phraseToDecrypt.length()%2 == 1){
            str1 = phraseToDecrypt.substring((phraseToDecrypt.length()/2) + 1);
            str2 = phraseToDecrypt.substring(0, (phraseToDecrypt.length()/2) + 1);
        } else {
            str1 = phraseToDecrypt.substring((phraseToDecrypt.length()/2));
            str2 = phraseToDecrypt.substring(0, (phraseToDecrypt.length()/2));
        }

        phraseToDecrypt = str1 + str2;
        return phraseToDecrypt;
    }

    //toString
    @Override
    public String toString() {
        return "Cutter";
    }
}
