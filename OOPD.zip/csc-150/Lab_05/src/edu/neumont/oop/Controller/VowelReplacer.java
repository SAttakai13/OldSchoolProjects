package edu.neumont.oop.Controller;

import java.util.Locale;

public class VowelReplacer implements IStringEncryptable{
    @Override
    public String encrypt(String phraseToEncrypt) {
        //replaces the vowels
        String temp = "";
        char myChar = ' ';
        for (int i = 0; i < phraseToEncrypt.length(); i++){
            myChar = phraseToEncrypt.charAt(i);
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'a'){
                myChar = 'e';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'e'){
                myChar = 'i';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'i'){
                myChar = 'o';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'o'){
                myChar = 'u';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'u'){
                myChar = 'a';
            }
            temp += myChar;
        }
        return temp;
    }


    @Override
    public String decrypt(String phraseToDecrypt) {
        //replaces the vowels back to its original state
        String temp = "";
        char tempChar;

        for (int i = 0; i < phraseToDecrypt.length(); i++){
            tempChar = phraseToDecrypt.charAt(i);
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'e'){
                tempChar = 'a';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'i'){
                tempChar = 'e';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'o'){
                tempChar = 'i';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'u'){
                tempChar = 'o';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'a'){
                tempChar = 'u';
            }
            temp += tempChar;
        }
        return temp;
    }
    

    //toString
    @Override
    public String toString() {
        return "Vowel Replacer";
    }
}
