package edu.neumont.oop.Controller;

public class Doubler implements IStringEncryptable{

    @Override
    public String encrypt(String phraseToEncrypt) {
        //repeats the word
        phraseToEncrypt += phraseToEncrypt;
        return phraseToEncrypt;
    }

    @Override
    public String decrypt(String phraseToDecrypt) {
        //brings it back to one word
        return phraseToDecrypt.substring(phraseToDecrypt.length()/2);
    }
    //toString
    @Override
    public String toString() {
        return "Doubler";
    }
}
