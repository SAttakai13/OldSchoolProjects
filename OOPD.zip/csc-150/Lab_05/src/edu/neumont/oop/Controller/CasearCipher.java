package edu.neumont.oop.Controller;

import java.util.Locale;

public class CasearCipher implements IStringEncryptable{
    @Override
    public String encrypt(String phraseToEncrypt) {
        //shifts the letter 3 places ahead
        String wordCipher = "";
        char wordChar;

        for (int i = 0; i < phraseToEncrypt.length(); i++) {
            wordChar = phraseToEncrypt.charAt(i);
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'a') {
                wordChar = 'd';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'b') {
                wordChar = 'e';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'c') {
                wordChar = 'f';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'd') {
                wordChar = 'g';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'e') {
                wordChar = 'h';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'f') {
                wordChar = 'i';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'g') {
                wordChar = 'j';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'h') {
                wordChar = 'k';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'i') {
                wordChar = 'l';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'j') {
                wordChar = 'm';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'k') {
                wordChar = 'n';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'l') {
                wordChar = 'o';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'm') {
                wordChar = 'p';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'n') {
                wordChar = 'q';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'o') {
                wordChar = 'r';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'p') {
                wordChar = 's';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'q') {
                wordChar = 't';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'r') {
                wordChar = 'u';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 's') {
                wordChar = 'v';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 't') {
                wordChar = 'w';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'u') {
                wordChar = 'x';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'v') {
                wordChar = 'y';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'w') {
                wordChar = 'z';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'x') {
                wordChar = 'a';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'y') {
                wordChar = 'b';
            }
            if (phraseToEncrypt.toLowerCase(Locale.ROOT).charAt(i) == 'z') {
                wordChar = 'c';
            }
            wordCipher += wordChar;
        }return wordCipher;
    }

    @Override
    public String decrypt(String phraseToDecrypt){
        //shifts the letters back 3 places
        String wordCipher = "";
        char wordChar = ' ';

        for (int i = 0; i < phraseToDecrypt.length(); i++) {
            wordChar = phraseToDecrypt.charAt(i);
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'd') {
                wordChar = 'a';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'e') {
                wordChar = 'b';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'f') {
                wordChar = 'c';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'g') {
                wordChar = 'd';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'h') {
                wordChar = 'e';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'i') {
                wordChar = 'f';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'j') {
                wordChar = 'g';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'k') {
                wordChar = 'h';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'l') {
                wordChar = 'i';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'm') {
                wordChar = 'j';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'n') {
                wordChar = 'k';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'o') {
                wordChar = 'l';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'p') {
                wordChar = 'm';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'q') {
                wordChar = 'n';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'r') {
                wordChar = 'o';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 's') {
                wordChar = 'p';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 't') {
                wordChar = 'q';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'u') {
                wordChar = 'r';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'v') {
                wordChar = 's';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'w') {
                wordChar = 't';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'x') {
                wordChar = 'u';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'y') {
                wordChar = 'v';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'z') {
                wordChar = 'w';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'a') {
                wordChar = 'x';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'b') {
                wordChar = 'y';
            }
            if (phraseToDecrypt.toLowerCase(Locale.ROOT).charAt(i) == 'c') {
                wordChar = 'z';
            }
            wordCipher += wordChar;
        }return wordCipher;
    }

    //toString
    @Override
    public String toString() {
        return "Casaer Cipher";
    }
}
