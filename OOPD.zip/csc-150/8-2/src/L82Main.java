public class L82Main {
    public static void main(String[] args) {
        Stuff workin = new Stuff();
        workin.startArea();
    }
}
