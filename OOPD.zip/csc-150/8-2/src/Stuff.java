import lib.ConsoleIO;

public class Stuff {
    ConsoleIO console = new ConsoleIO();
    public void startArea(){
        console.promptForString("Put in something: ", false);
        console.promptForInt("Put in a number: ", 1, 10);
        console.promptForBoolean("Is russia a country? ", "yes", "no");
        console.promptForMenuSelection(new String[]{"\n1.) yes\n2.)maybe\n3.) No"}, true);
    }
}
