import javax.sound.midi.Soundbank;

public class Person {
    private String name;
    private int age;
    private String prefix;
    private String suffix;
    int myAge = 17;



    ///Age :p
    public int getAge() {
        return age;
    }
    public void setAge(int age){
        if (age < 0){
            this.age = 0;
        } else {
            this.age = age;
        }

    }
    public void compAge(int age){
        if (age > myAge){
            System.out.println("Is older");
        } else if (age < myAge){
            System.out.println("Is younger");
        } else {
            System.out.println("Is the same age");
        }
    }

    public void setSuffix(String suffix) {this.suffix = suffix;}
    public String getSuffix() {return suffix;}

    public void setPrefix(String prefix) {this.prefix = prefix;}
    public String getPrefix() {return prefix;}

    public void setName(String name) {
        if (!name.isEmpty()){
            this.name = name;
        }
    }

    public String getName() {return name;}

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", prefix='" + prefix + '\'' +
                ", suffix='" + suffix + '\'' +
                '}';
    }
}
