package com.example.proejct.Controller.DatabaseConnect;

import com.example.proejct.Model.TransactionModel;
import com.mongodb.MongoException;
import com.mongodb.client.*;

import com.mongodb.client.result.DeleteResult;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.data.mongodb.core.aggregation.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;


import static com.mongodb.client.model.Filters.eq;

public class DatabaseTransactionsConnector {

    String uri = "mongodb+srv://CalebC:CalebC@web-based-bookstore.f7vxoh8.mongodb.net/test";
    public void create(TransactionModel transaction){
        try (MongoClient mongoClient = MongoClients.create(uri)){
            MongoDatabase database = mongoClient.getDatabase("BookstoreData");
            MongoCollection<Document> collection = database.getCollection("Transactions");

            Document newTrans = new Document()
                    .append("ID", transaction.getId())
                    .append("Date", transaction.getDate())
                    .append("Total", transaction.getTotal())
                    .append("Items", transaction.getItems().toString())
                    .append("StoreNum", transaction.getStoreNum());
            collection.insertOne(newTrans);
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    public ArrayList<TransactionModel> findAllTransactions() throws Exception{
        MongoCursor<Document> iterDoc = null;
        try (MongoClient mongoClient = MongoClients.create(uri)){
            MongoDatabase database = mongoClient.getDatabase("BookstoreData");
            MongoCollection<Document> collection = database.getCollection("Transactions");
            iterDoc = collection.find().iterator();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return turnToArrayList(iterDoc);
    }

    public ArrayList<TransactionModel> turnToArrayList(MongoCursor<Document> cursor){
        ArrayList<TransactionModel> tml = new ArrayList<>();
        try {
            while(cursor.hasNext()){
                TransactionModel transaction = new TransactionModel();
                Document bookDoc = cursor.next();
                transaction.setId(bookDoc.getInteger("ID"));
                transaction.setDate(bookDoc.getString("Date"));
                transaction.setTotal(bookDoc.getDouble("Total"));
                transaction.setItems(bookDoc.getString("Items"));
                transaction.setStoreNum(bookDoc.getInteger("StoreNum"));
                tml.add(transaction);
                System.out.println(tml);
            }
        } catch (Exception ex) {
            ex.getMessage();
        }
        return tml;
    }

    public TransactionModel findTransaction(int id) throws ParseException {
        Document doc = null;
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("BookstoreData");
            MongoCollection<Document> collection = database.getCollection("Transactions");
            doc = collection.find(eq("ID", id)).first();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return turnToTransaction(doc);
    }
    public TransactionModel turnToTransaction(Document cursor){
        TransactionModel tm = new TransactionModel();
        DatabaseBookConnector dbc = new DatabaseBookConnector();

        tm.setId(cursor.getInteger("ID"));
        tm.setDate(cursor.getString("Date"));
        tm.setTotal(cursor.getDouble("Total"));
        tm.setItems(cursor.getString("Items"));
        tm.setStoreNum(cursor.getInteger("StoreNum"));
        return tm;
    }

    public void deleteTransaction(int id) {
        try (MongoClient mongoClient = MongoClients.create(uri)){
            MongoDatabase database = mongoClient.getDatabase("BookstoreData");
            MongoCollection<Document> collection = database.getCollection("Transactions");

            Bson query = eq("ID", id);
            try {
                DeleteResult result = collection.deleteOne(query);
                System.out.println("Delete document count: " + result.getDeletedCount());
            } catch (MongoException me){
                System.err.println("Unable to delete due to an error " + me);
            }
        }
    }

    public String CountBooksSoldByStoreId(int StoreId) {
        String reports = "";
        try (MongoClient mongoClient = MongoClients.create(uri)){
            MongoDatabase database = mongoClient.getDatabase("BookstoreData");
            MongoCollection<Document> collection = database.getCollection("Transactions");


            AggregateIterable<Document> documents = collection.aggregate(Arrays.asList(
                    new Document("$project", new Document("StoreId", 1).append("Items", 1).append("Transactions", new Document("$Transactions", "Transaction_Date"))),
                    new Document("$match", new Document("StoreId", eq(StoreId))),
                    new Document("$group", new Document("_id", "$StoreId").append("Items_Sold", new Document("$sum", ArrayOperators.Size.lengthOfArray("Items"))))
            ));

            for (Document document : documents) {
                reports = document.toString();
            }
        }
        return reports;
    }
}
